#!/usr/bin/env python3
"""Run the unchanged 68-case harnesses against the pinned released module closure.

A new execution is always separately preserved. Historical flags are never
rewritten. Prior adjudication applies only to exactly repeated case payloads.
"""
import argparse
import datetime
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import zipfile
from pathlib import Path
sys.dont_write_bytecode = True
from verify_pack import MODULES, TOOLKIT, digest, read_json, require, verify_pack

ROOT = Path(__file__).resolve().parent

def save(path, value):
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

def closure_check(runtime):
    for name, expected in MODULES.items():
        path = runtime / name
        require(not path.is_symlink() and path.is_file(), 'Missing regular runtime module')
        require(digest(path.read_bytes()) == expected, 'Runtime module drift')

def run_frozen_harness(label, runtime, output, env):
    command = [sys.executable, '-B', str(ROOT / 'suites' / label / 'run_harness.py'),
               '--candidate', str(runtime / 'scripts/verify-reconciliation.mjs'),
               '--candidate-sha256', MODULES['scripts/verify-reconciliation.mjs'],
               '--output', str(output / (label + '-raw'))]
    with (output / (label + '.harness.stdout.bin')).open('xb') as stdout, (output / (label + '.harness.stderr.bin')).open('xb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=env, cwd=output, start_new_session=True)
        try:
            rc = process.wait(timeout=1200)
        except BaseException as error:
            # The harness owns a fresh session. Stop that entire session before
            # freezing any partial evidence, including on keyboard interruption.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            save(output / (label + '.harness.receipt.json'),
                 {'exit_code': process.returncode, 'timeout': isinstance(error, subprocess.TimeoutExpired),
                  'interrupted': True, 'error_type': type(error).__name__})
            raise
    save(output / (label + '.harness.receipt.json'), {'exit_code': rc, 'timeout': False})
    return rc

def compare_results(output):
    adjudication = read_json(ROOT / 'recorded/ADJUDICATION.json')
    approved = {r['case']: r for r in adjudication['reapplied_cases']}
    cases_out = []
    harness_consistent = True
    for label in ('original60', 'order8'):
        current = output / (label + '-raw')
        historical = ROOT / 'recorded' / (label + '-raw')
        expected = read_json(ROOT / 'suites' / label / 'cases.json')['cases']
        result = read_json(current / 'RESULT.json')
        result_by_id = {r['case']: r for r in result['results']}
        require(len(result_by_id) == len(expected), 'Incomplete harness case result list')
        expected_harness_rc = 1 if result['failed'] else 0
        harness_consistent &= read_json(output / (label + '.harness.receipt.json'))['exit_code'] == expected_harness_rc
        for case in expected:
            folder = current / case['id']
            receipt = read_json(folder / 'receipt.json')
            require(receipt == result_by_id[case['id']], 'Receipt and summary disagreement')
            exact = all((folder / name).read_bytes() == (historical / case['id'] / name).read_bytes()
                        for name in ('stdout.bin', 'stderr.bin', 'receipt.json'))
            status_exit = receipt['observed_status'] == case['status'] and receipt['exit_code'] == case['exit_code']
            prior = approved.get(case['id'])
            carried = bool(not receipt['passed'] and exact and prior and receipt['errors'] == prior['unchanged_original_flags'])
            cases_out.append({'suite': label, 'case': case['id'], 'raw_passed': receipt['passed'],
                              'raw_flags': receipt['errors'], 'status_and_exit_match': status_exit,
                              'exact_historical_case_payloads': exact, 'prior_adjudication_carried_forward': carried,
                              'unresolved': not status_exit or not exact or (not receipt['passed'] and not carried)})
    summary = {'schema': 'n170.public-source-challenge-new-run.v1', 'case_count': len(cases_out),
               'raw_passed': sum(c['raw_passed'] for c in cases_out),
               'raw_flagged': sum(not c['raw_passed'] for c in cases_out),
               'status_and_exit_matches': sum(c['status_and_exit_match'] for c in cases_out),
               'exact_historical_case_payload_matches': sum(c['exact_historical_case_payloads'] for c in cases_out),
               'prior_adjudication_carried_forward': sum(c['prior_adjudication_carried_forward'] for c in cases_out),
               'unresolved_cases': sum(c['unresolved'] for c in cases_out),
               'harness_process_status_consistent': harness_consistent, 'cases': cases_out,
               'claim': 'Raw harness flags remain unchanged. This is a separate released-code execution of the existing bounded cases.'}
    summary['matches_accepted_history'] = bool(summary['case_count'] == 68 and summary['raw_passed'] == 51 and
        summary['raw_flagged'] == 17 and summary['status_and_exit_matches'] == 68 and
        summary['exact_historical_case_payload_matches'] == 68 and summary['prior_adjudication_carried_forward'] == 17 and
        summary['unresolved_cases'] == 0 and harness_consistent)
    save(output / 'SUMMARY.json', summary)
    return summary

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolkit-zip', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    require(os.name == 'posix', 'Unchanged harness currently supports POSIX hosts only')
    require(sys.version_info >= (3, 9), 'Python 3.9 or newer required')
    verification = verify_pack(ROOT, args.manifest_sha256)
    archive = Path(args.toolkit_zip)
    require(not archive.is_symlink() and archive.is_file(), 'Toolkit ZIP must be regular')
    require(digest(archive.read_bytes()) == TOOLKIT, 'Released toolkit ZIP hash mismatch')
    node = shutil.which('node')
    require(node is not None, 'Node is unavailable')
    env = {k: v for k, v in os.environ.items() if k not in ('NODE_OPTIONS', 'NODE_PATH')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    version_result = subprocess.run([node, '--version'], capture_output=True, env=env, timeout=10)
    require(version_result.returncode == 0, 'Node version check failed')
    match = re.fullmatch(rb'v(\d+)\.(\d+)\.(\d+)\s*', version_result.stdout)
    require(match is not None, 'Unrecognized Node version')
    version = tuple(map(int, match.groups()))
    require((version[0] == 20 and version >= (20, 19, 0)) or version >= (22, 12, 0), 'Unsupported Node version')
    output = Path(args.output)
    require(output.is_absolute() and not output.exists() and not output.is_symlink(), 'New absolute output directory required')
    require(ROOT.resolve() not in output.resolve().parents, 'Keep run artifacts outside immutable pack')
    output.mkdir()
    save(output / 'STARTED.json', {'schema': 'n170.public-source-challenge-run-start.v1',
         'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'pack_manifest_sha256': args.manifest_sha256, 'toolkit_archive_sha256': TOOLKIT,
         'module_sha256': MODULES, 'node_version': version_result.stdout.decode().strip(),
         'python_version': sys.version.split()[0], 'pack_data_verification': verification,
         'scope': 'New rerun of the original 68 frozen cases; no new financial cases.'})
    try:
        runtime = output / 'released-toolkit'
        with zipfile.ZipFile(archive) as z:
            require(len(z.namelist()) == len(set(z.namelist())), 'Duplicate toolkit ZIP members')
            for name, expected in MODULES.items():
                data = z.read(name)
                require(digest(data) == expected, 'Released module mismatch')
                path = runtime / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        closure_check(runtime)
        for label in ('original60', 'order8'):
            run_frozen_harness(label, runtime, output, env)
            closure_check(runtime)
        verify_pack(ROOT, args.manifest_sha256)
        summary = compare_results(output)
        print(json.dumps({k: v for k, v in summary.items() if k != 'cases'}, indent=2))
        return 0 if summary['matches_accepted_history'] else 1
    except BaseException as error:
        save(output / 'INTERRUPTED.json', {'error_type': type(error).__name__,
             'message': str(error), 'artifacts_preserved': True,
             'instruction': 'Retain this first attempt. Use a different output directory for any later attempt.'})
        raise
    finally:
        files = [{'path': p.relative_to(output).as_posix(), 'bytes': p.stat().st_size,
                  'sha256': digest(p.read_bytes())} for p in sorted(output.rglob('*')) if p.is_file()]
        save(output / 'RUN_MANIFEST.json', {'schema': 'n170.public-source-challenge-run-freeze.v1', 'files': files})

if __name__ == '__main__':
    raise SystemExit(main())
