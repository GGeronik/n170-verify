# N170 private-source challenge pack — public subset candidate

This is a newly assembled, separately identified public-subset candidate for the existing 68 synthetic source-checker cases. It is not a copy of either complete historical suite or the private validation archive. Preparation and data-only checks do not constitute a new checker execution or publication approval.

The cases comprise 31 conditional positive cases, 16 mismatches, 13 not-assessable cases and 8 invalid inputs. `CASE_MAP.tsv` lists every case, unchanged input location, input hash, event hash and expected status/exit pair. The authoritative expectations remain the two unchanged `suites/*/cases.json` files. `PROVENANCE.json` maps every copied payload to the corresponding original frozen file identity; `MANIFEST.json` describes this new pack only.

The recorded accepted execution is **51 raw harness passes and 17 flags**: original60 reports 43/17 and order8 reports 8/0. All 68 expected status/exit pairs matched. The accepted adjudication covers 15 broad `PRIVATE_` substring false positives and five permitted diagnostic-name variants, with three overlapping cases. Those are 17 flagged cases, not 68 raw passes. The unedited raw stdout/stderr, receipts, aggregate results and adjudication remain in `recorded/`. Its source-version identity is the accepted v2 CLI, the same entry-script bytes released in the pinned toolkit. Recorded evidence is historical; a replay writes a separate execution.

## Requirements and trust boundary

Use a POSIX host (Linux or macOS), separately installed Python 3.9 or newer, and Node matching `^20.19.0 || >=22.12.0`. The frozen harness uses POSIX pipe selectors; Windows replay is not certified. No npm installation, network access, financial engine or producer helper is needed. The runnable closure consists of four exact JavaScript modules listed in `SOURCE_PINS.json` plus Python standard-library harness code. The complete toolkit's unrelated components are never imported or executed.

JSON and HTML fixtures are input data. Do not render fixture HTML or execute its script text. The HTML test intentionally contains a script that throws `MUST_NOT_RUN`; the checker reads the document as data. Synthetic `PRIVATE_*_f5a7` canaries deliberately resemble private identifiers and remain unchanged. Their fixed public test key/signatures do not establish owner or publisher identity. Fixture builders and the helper with a publicly known mathematical private scalar are excluded. Do not rebuild or re-sign these cases.

The three files in `provenance/` are unchanged historical full-package manifests. They describe larger original inventories; they do not claim all those files are present here. Historical `public_release_eligible: false` remains intact. The new `suites/*/MANIFEST.json` files explicitly identify selected subsets and allow the unchanged original harnesses to check only the included frozen payloads.

## Verify and extract

Obtain the pack ZIP, the detached `verify_pack.py`, and separately reviewed archive/manifest/verifier SHA-256 values. Compare the detached verifier's hash using a trusted local SHA-256 tool before running it. A checksum establishes byte identity relative to that expected value; it does not authenticate the publisher by itself.

Use the detached verifier to check the archive and extract only regular, bounded, nonduplicated safe paths into a new absolute directory:

```sh
python3 -B verify_pack.py --archive challenge-pack.zip \
  --archive-sha256 "$PACK_ARCHIVE_SHA256" \
  --manifest-sha256 "$PACK_MANIFEST_SHA256" \
  --destination "$PWD/challenge-pack"
```

The verifier checks the exact file inventory, all payload hashes, the three original freeze pins, every unchanged copied-file mapping, both subset manifests, all 68 case input references and the four module pins. It parses data only and does not invoke the checker. For an already extracted directory:

```sh
python3 -B challenge-pack/verify_pack.py --pack-dir "$PWD/challenge-pack" \
  --manifest-sha256 "$PACK_MANIFEST_SHA256"
```

## Replay the exact released toolkit

Obtain the standalone offline toolkit ZIP whose SHA-256 is `24ad3cc8f88c3b01b076d99b33017f9b090259dffa18e0cb500130d87bf37863`. `--toolkit-zip` accepts that exact archive regardless of its local filename. The runner checks the archive before extracting only the four pinned `scripts/*.mjs` members into the new run directory. Manual whole-toolkit extraction is unnecessary.

```sh
python3 -B challenge-pack/run_challenge.py \
  --toolkit-zip accepted-offline-toolkit.zip \
  --manifest-sha256 "$PACK_MANIFEST_SHA256" \
  --output "$PWD/challenge-run-001"
```

The accepted combined source archive has SHA-256 `b234e3f7d250f3819071030eeaa7de0a62c84343dc939a72d0cb61babba1648a`. For source inspection, its corresponding modules are under `app/scripts/`; compare those four files with `SOURCE_PINS.json`. Replay uses the separately pinned standalone toolkit so that no build or dependency installation is required. The root source-acceptance manifest pin is recorded as provenance; that private audit package is not included or published by this candidate.

Every replay requires a new absolute output directory outside the pack. Existing directories are rejected. The unchanged harnesses preserve observed stdout/stderr, case receipts and raw flags. The outer runner records start metadata, both harness process exit codes, all four module hashes, a comparison summary and a final run manifest. On interruption or timeout it terminates and waits for its owned harness process group before freezing the partial attempt. Retain failed and interrupted attempt directories; never overwrite them with a later success.

A successful exact replay reports `raw_passed: 51`, `raw_flagged: 17`, `status_and_exit_matches: 68`, `exact_historical_case_payload_matches: 68`, and `prior_adjudication_carried_forward: 17`. The original60 harness's process exit code 1 remains recorded because it reports 17 raw flags. The outer runner returns 0 only when the exact accepted historical pattern is reproduced. Any changed stdout, stderr or receipt is unresolved, even if its broad status still matches; this is a strict release replay, not a general equivalence test. New case output is never silently granted a broader exception.

This finite challenge pack does not establish broker authenticity, account completeness, profitability, an outside human review or correctness for every possible input. Conditional positives remain conditional on supplied material and unsigned owner assertions. The included first-party `LICENSE` and `NOTICE` are unchanged from the accepted toolkit.
