# Preservation and portable runner review plan

Frozen harness delta: **zero bytes**. Original60 `run_harness.py` and order8 `run_harness.py` remain separately pinned unchanged payloads. The historical ordering supplement differs from original60 only by choosing the active source for currency evidence; that existing historical difference is retained. No fixture, expected value, signature, event selection, schema, input byte or raw historical result is regenerated or edited.

The only suite-level adaptation is a new, explicitly named public-subset manifest in each suite directory. It uses the original harness's `files` interface and maps each selected payload to its original freeze entry. Full original manifests remain under `provenance/`; each public subset expressly denies identity with the original full suite. The new top-level manifest and provenance map freeze the adaptation itself.

The new outer runner performs these operations in order:

1. Verify this pack's caller-pinned manifest, exact inventory, original freeze provenance and all selected suite bytes.
2. Check the exact standalone toolkit archive and a supported Node version. Create a new run directory and a start receipt.
3. Read only the four fixed archive members, check their frozen hashes and write them into the run's isolated module directory. No arbitrary archive extraction or engine execution occurs.
4. Execute each original harness once against the released CLI using existing cases. Clear `NODE_OPTIONS`/`NODE_PATH`; disable Python bytecode writes. Record outer stdout/stderr and process exit codes. Preserve case raw outputs and receipts written by the harnesses.
5. Recheck module closure after each harness and the whole input pack afterwards. Terminate and wait for the owned process group on every exceptional wait exit before recording interruption/freeze evidence.
6. Compare every new stdout/stderr/receipt byte with its historical counterpart. Preserve raw flags. Carry forward an existing flagged-case adjudication only when all three payloads match exactly and the same error list appears in the frozen adjudication. Mark any changed result unresolved.
7. Write a separate summary and run manifest. Any failed or interrupted run keeps its directory and is never overwritten by a retry.

The archive verifier is a separate data-only Python standard-library tool. It accepts explicit expected archive and manifest hashes, enforces a bounded regular-file archive with no duplicate, traversal, encrypted or symlink entries, extracts only to a new absolute directory, and verifies selected-payload mapping against the three pinned original manifests. The detached copy permits review before extracting the pack.

The original harness's 15-second per-case and 65,536-byte per-stream bounds remain unchanged. Its raw `PRIVATE_` substring test and exact diagnostic-name expectations also remain unchanged. The wrapper's 1,200-second per-harness limit adds a termination bound; it does not alter case expectations or manufacture complete output when an attempt was interrupted.

Review stages remain separate: preparation and syntax/data checks; root review of runner and preservation plan; one new replay from fresh extraction; independent review of the frozen new evidence; distribution preparation. This candidate has not yet crossed the replay or publication gates.
