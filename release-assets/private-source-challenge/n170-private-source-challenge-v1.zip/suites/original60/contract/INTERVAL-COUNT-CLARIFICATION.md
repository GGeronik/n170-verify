# Source interval count and private schedule expansion

2026-09-19, before independent financial candidate execution. Original freezes remain unchanged.

`counts.observations` reports independently reconstructed source observations (at most 500). `counts.intervals` reports independently calculated adjacent source/signed intervals (observations minus one, at most 499), or zero when calculation is unavailable. It does not count the private requested-schedule expansion.

The private input schema separately admits up to 5,500 intervals, preserving inserted missing boundaries and unresolved intervals. More than 499 private expanded intervals is not by itself an invalid input. These remain represented in the input and cause assessment/refusal according to missingness and the existing schedule bounds, without truncation or fictional source observations. No raw schedule dates enter the summary.

The accompanying result schema adds this field description only. All required fields, types, enums and numeric/array limits are unchanged from the earlier frozen result schema. No financial, transport or arithmetic rule changes.
