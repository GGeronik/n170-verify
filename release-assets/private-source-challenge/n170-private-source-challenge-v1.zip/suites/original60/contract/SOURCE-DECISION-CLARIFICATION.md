# Missing source-decision reason

2026-09-19, before independent financial candidate execution. Original freezes and candidate v1 remain unchanged.

A structurally admitted `excluded` or `superseded` source whose reason has fewer than three ECMAScript-trimmed characters, including empty or whitespace-only text, yields NOT_ASSESSABLE with fixed `SOURCE_DECISION_REASON_REQUIRED`. The source remains in `source_decisions`, with `reason_present: false`; it is not silently accepted or removed. `active` and `unresolved` entries do not require an exclusion reason, but unresolved entries still block assessment.

The accepted v1 private exporter always supplies a string `reason`. Therefore its current input schema requires that field and string type: missing or wrong-type values (including null in this schema) are INVALID_INPUT. If a future admitted export shape permits null reasons, null means absent and cannot authorize exclusion. This note does not expand the current input schema.

Candidate v1 already implements this status distinction. No source, output schema, arithmetic or expectation change is made by this clarification.
