# Calculation 2.0.0 bound wording

2026-09-19, before financial candidate acceptance execution. Original freezes remain unchanged.

The original contract's statement that interval gross is at most 10,000 refers to the **encoded, rounded e8 gross** under accepted calculation 2.0.0. Let `U = 100000000`, opening NAV be `O`, adjusted closing NAV be `A > 0`, and `r = round((A - O) * U / O)` with ties toward positive infinity. Enforce `0 < U + r <= 10000 * U`, along with the independent exact quantization-error gate `abs((U+r)*O-A*U) * 10000000 <= A*U`. No extra unrounded `A/O <= 10000` gate is introduced.

This matches the accepted calculator's encoded-return validation and the unchanged independent signed-record verifier. Cumulative wealth uses the encoded factors and retains its existing bounds. A signed profile violating its own encoded bounds is INVALID_INPUT; valid signed evidence with unsupported source bounds is NOT_ASSESSABLE, with independently established contradictions taking precedence as previously frozen.

This is an explicit resolution of contract wording against existing calculation rules, not a calculation or signed-wire change. No financial expected fixture informed it.
