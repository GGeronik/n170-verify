#!/usr/bin/env python3
"""Frozen independent wire harness; never imports candidate or producer modules.

Run only after candidate handoff is frozen. Requires explicit script hash and a
new result directory. Reads fixtures unchanged and invokes the documented CLI.
The result vocabulary's fixed-code origin also requires static reviewer audit;
regex conformance alone does not prove privacy.
"""
import argparse, hashlib, json, os, re, selectors, shutil, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def save(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def unique_object(pairs):
    out={}
    for key,value in pairs:
        if key in out: raise ValueError('duplicate output property')
        out[key]=value
    return out
def schema_errors(value,schema,where='$'):
    errors=[]
    if 'oneOf' in schema:
        if sum(not schema_errors(value,s,where) for s in schema['oneOf'])!=1:errors.append(where+': oneOf')
        return errors
    if 'const' in schema and value!=schema['const']:errors.append(where+': const')
    if 'enum' in schema and value not in schema['enum']:errors.append(where+': enum')
    kind=schema.get('type')
    good={'null':value is None,'object':type(value) is dict,'array':type(value) is list,'string':type(value) is str,'integer':type(value) is int,'boolean':type(value) is bool}.get(kind,True)
    if not good:return errors+[where+': type']
    if kind=='object':
        props=schema.get('properties',{})
        if any(k not in value for k in schema.get('required',[])):errors.append(where+': missing property')
        if schema.get('additionalProperties') is False and set(value)-set(props):errors.append(where+': extra property')
        for k,v in value.items():
            if k in props:errors+=schema_errors(v,props[k],where+'.'+k)
    elif kind=='array':
        if len(value)>schema.get('maxItems',len(value)):errors.append(where+': length')
        if schema.get('uniqueItems') and len({json.dumps(x,sort_keys=True) for x in value})!=len(value):errors.append(where+': duplicate item')
        for i,v in enumerate(value):errors+=schema_errors(v,schema.get('items',{}),where+'[]')
    elif kind=='string':
        if len(value)>schema.get('maxLength',len(value)):errors.append(where+': length')
        if schema.get('pattern') and not re.fullmatch(schema['pattern'],value):errors.append(where+': pattern')
    elif kind=='integer':
        if value<schema.get('minimum',value) or value>schema.get('maximum',value):errors.append(where+': range')
    return errors

def invoke(command,cwd):
    # Bound both streams and elapsed time without accepting arbitrarily large
    # diagnostics. Preserve exactly the observed bytes, including on failure.
    env={k:v for k,v in os.environ.items() if k not in ['NODE_OPTIONS','NODE_PATH']}
    process=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    sel=selectors.DefaultSelector();sel.register(process.stdout,selectors.EVENT_READ,'stdout');sel.register(process.stderr,selectors.EVENT_READ,'stderr')
    output={'stdout':bytearray(),'stderr':bytearray()};deadline=time.monotonic()+15;failure=None
    while sel.get_map():
        if time.monotonic()>deadline:failure='TIMEOUT';process.kill();break
        for key,_ in sel.select(timeout=.1):
            part=os.read(key.fileobj.fileno(),4096)
            if not part:sel.unregister(key.fileobj);continue
            output[key.data].extend(part)
            if len(output[key.data])>65536:failure='OUTPUT_LIMIT';process.kill();break
        if failure:break
    process.wait();sel.close()
    return process.returncode,bytes(output['stdout']),bytes(output['stderr']),failure

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',required=True);ap.add_argument('--candidate-sha256',required=True);ap.add_argument('--output',required=True)
    args=ap.parse_args();candidate=Path(args.candidate)
    if not candidate.is_absolute() or candidate.is_symlink() or not candidate.is_file():raise SystemExit('Explicit regular candidate path required')
    if sha(candidate.read_bytes())!=args.candidate_sha256:raise SystemExit('Candidate hash mismatch')
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for f in manifest['files']:
        b=(ROOT/f['path']).read_bytes()
        if len(b)!=f['bytes'] or sha(b)!=f['sha256']:raise SystemExit('Frozen suite input drift')
    baseline_hash=sha((ROOT/'baseline/verify-record.mjs').read_bytes())
    if sha((candidate.parent/'verify-record.mjs').read_bytes())!=baseline_hash:raise SystemExit('Independent signed-record verifier drift')
    out=Path(args.output)
    if not out.is_absolute():raise SystemExit('Absolute new output directory required')
    out.mkdir(exist_ok=False)
    cases=json.loads((ROOT/'cases.json').read_text());schema=json.loads((ROOT/'contract/RESULT.schema.json').read_text())
    node=shutil.which('node')
    if not node:raise SystemExit('Node is unavailable')
    result=[];all_codes=set()
    for c in cases['cases']:
        folder=out/c['id'];folder.mkdir()
        command=[node,str(candidate),'--record',str(ROOT/c['record']),'--event-sha256',c['event_sha256'],'--reconciliation',str(ROOT/c['reconciliation'])]
        rc,stdout,stderr,process_failure=invoke(command,folder)
        (folder/'stdout.bin').write_bytes(stdout);(folder/'stderr.bin').write_bytes(stderr)
        errors=[]
        if process_failure:errors.append(process_failure)
        if rc!=c['exit_code']:errors.append('EXIT_CODE')
        if stderr:errors.append('STDERR_NOT_EMPTY')
        observed=None
        try:
            observed=json.loads(stdout.decode('utf-8'),object_pairs_hook=unique_object,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite')))
            errors+=schema_errors(observed,schema)
        except (ValueError,UnicodeError):errors.append('OUTPUT_NOT_SINGLE_STRICT_JSON')
        # Any printed hash/date/path/canary is a privacy violation even if a
        # malicious string happens to fit the reason identifier grammar.
        decoded=(stdout+b'\n'+stderr).decode('utf-8',errors='replace')
        for token in ['PRIVATE_','f5a7','/Users/','/private/','reconciliation.json','record.json','record.html']:
            if token in decoded:errors.append('PRIVATE_ECHO')
        if re.search(r'(?i)[a-f0-9]{64}',decoded) or re.search(r'\d{4}-\d{2}-\d{2}',decoded):errors.append('HASH_OR_DATE_ECHO')
        if isinstance(observed,dict) and not schema_errors(observed,schema):
            all_codes.update(observed['reasons'])
            if observed['status']!=c['status']:errors.append('STATUS')
            if c['required_reason'] and c['required_reason'] not in observed['reasons']:errors.append('REQUIRED_REASON')
            if c['status']!='VERIFIED_UNDER_OWNER_ASSERTIONS' and not observed['reasons']:errors.append('REFUSAL_REASON_REQUIRED')
            if c['status']!='INVALID_INPUT':
                selected=c['expected_selected'];expected=dict(sequence=selected['sequence'],event_type=selected['type'],superseded=selected['superseded'])
                if observed['selected_event']!=expected:errors.append('SELECTED_EVENT')
                if not observed['checks']['signed_profile']:errors.append('VALID_PROFILE_FLAG')
            if c['status']=='VERIFIED_UNDER_OWNER_ASSERTIONS':
                private=json.loads((ROOT/c['reconciliation']).read_text())['reconciliation'];sources=private['source_inventory']
                if observed['counts']!={'retained_sources':len(sources),'observations':len(private['review']['rows']),'intervals':len(private['review']['rows'])-1}:errors.append('SUCCESS_COUNTS')
                if len(observed['source_decisions'])!=len(sources):errors.append('SOURCE_INVENTORY_OMISSION')
                for n,(s,d) in enumerate(zip(sources,observed['source_decisions']),1):
                    available=s['source_bytes_available'];decode='unavailable' if not available else 'invalid_utf8' if s['text'] is None else 'valid_utf8'
                    expected=dict(ordinal=n,disposition=s['disposition'],bytes_available=available,byte_binding='matched' if available else 'unavailable',text_decoding=decode,reason_present=len(s['reason'].strip())>=3)
                    if d!=expected:errors.append('SOURCE_DECISION')
                for field,value in observed['checks'].items():
                    expect=all(s['source_bytes_available'] for s in sources) if field=='source_bytes' else True
                    if value!=expect:errors.append('SUCCESS_CHECK_'+field.upper())
                active=next(source for source in sources if source['disposition']=='active')
                currency='source' if active['currencies'] else 'owner_assertion'
                if observed['currency_evidence']!=currency:errors.append('CURRENCY_EVIDENCE')
                mandatory={'ACCOUNT_ALIAS_AND_ACCOUNT_ID_LINK_NOT_ESTABLISHED','FLOW_TIMING_IS_OWNER_ASSERTION','HIDDEN_FLOW_REVIEW_IS_OWNER_ASSERTION','SCHEDULE_IS_OWNER_ASSERTION','EXCLUSIONS_AND_SUPERSESSION_ARE_OWNER_ASSERTIONS','SOURCE_AUTHENTICITY_NOT_ESTABLISHED','ACCOUNT_COMPLETENESS_NOT_ESTABLISHED','IDENTITY_NOT_ESTABLISHED','INDEPENDENT_PUBLICATION_NOT_ESTABLISHED'}
                if currency=='owner_assertion':mandatory.add('CURRENCY_IS_OWNER_ASSERTION')
                if any(not s['source_bytes_available'] for s in sources):mandatory.add('RETAINED_SOURCE_BYTES_UNAVAILABLE')
                if any(s['source_bytes_available'] and s['text'] is None for s in sources):mandatory.add('RETAINED_SOURCE_UTF8_UNDECODABLE')
                if not mandatory.issubset(observed['limitations']):errors.append('MISSING_LIMITATION')
            if c.get('expected_source_intervals') is not None:
                # Count clarification permits zero when calculation is
                # unavailable; expanded private intervals must never replace
                # the source count or force structural rejection by themselves.
                count=observed['counts']['intervals'];expected=c['expected_source_intervals']
                if count not in [0,expected] or (observed['checks']['signed_returns'] and count!=expected):errors.append('EXPANDED_SCHEDULE_COUNT')
        receipt={'case':c['id'],'passed':not errors,'expected_status':c['status'],'observed_status':observed.get('status') if isinstance(observed,dict) else None,'exit_code':rc,'errors':list(dict.fromkeys(errors)),'stdout_bytes':len(stdout),'stdout_sha256':sha(stdout),'stderr_bytes':len(stderr),'stderr_sha256':sha(stderr)}
        save(folder/'receipt.json',receipt);result.append(receipt)
    if sha(candidate.read_bytes())!=args.candidate_sha256:raise SystemExit('Candidate changed during run')
    for f in manifest['files']:
        if sha((ROOT/f['path']).read_bytes())!=f['sha256']:raise SystemExit('Suite input changed during run')
    summary={'schema':'n170.private-source-independent-run.v1','candidate_sha256':args.candidate_sha256,'suite_manifest_sha256':sha((ROOT/'MANIFEST.json').read_bytes()),'case_count':len(result),'passed':sum(r['passed'] for r in result),'failed':sum(not r['passed'] for r in result),'fixed_reason_code_static_review_required':True,'observed_reason_codes':sorted(all_codes),'results':result}
    save(out/'RESULT.json',summary)
    save(out/'MANIFEST.json',{'files':[{'path':str(f.relative_to(out)),'bytes':len(f.read_bytes()),'sha256':sha(f.read_bytes())} for f in sorted(out.rglob('*')) if f.is_file()]})
    print(json.dumps({'case_count':len(result),'passed':summary['passed'],'failed':summary['failed'],'static_reason_audit_still_required':True}))
    return 0 if not summary['failed'] else 1
if __name__=='__main__':raise SystemExit(main())
