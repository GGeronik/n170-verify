# Privacy review of the minimal unchanged challenge inputs

Decision: no actual personal account data, credentials, private-key material, or personal filesystem paths were observed in the selected frozen cases, referenced fixture inputs, exact harness/schema/verifier files, accepted raw run files, adjudication files, or source manifests. One proposed supporting evidence file must be excluded unchanged: `PRIOR_LITERAL_EVIDENCE.json`.

Scope and method: 359 selected files were read as inert data. These comprise two case indexes, 136 case-referenced record/reconciliation files, the two suites’ harness/schema/verifier files and source manifests, five proposed historical reference files, and 208 accepted raw-run files. JSON strings and HTML embedded JSON were parsed as data. All 79 non-null embedded base64 strings were examined: 78 strict decodes, plus the intentionally noncanonical P05 value decoded permissively for privacy inspection only. There are 28 distinct decoded payloads. No fixture, harness, verifier, builder, signer, or candidate code was executed. The source inputs were not modified.

| File group | Finding | Inclusion decision |
| --- | --- | --- |
| Both `cases.json` files | Relative fixture paths, expected statuses, hashes and case identifiers. | Include unchanged. |
| 136 case-referenced record/reconciliation inputs | All parsed display names are “Independent synthetic fixture”; source-kind values are `synthetic_demo`. Source bytes contain small synthetic CSV examples and deliberate boundary values, rather than observed personal records. Alias/account/filename/reason values use deliberate canaries. | Include unchanged with a clear synthetic-fixture explanation. |
| Both `run_harness.py` files | Generic local-path substrings are privacy test sentinels, not personal paths. No credential or private-key material found. | Include unchanged. |
| Both `contract/RESULT.schema.json` files | Fixed result structure; the only URL is the public JSON Schema specification. | Include unchanged. |
| Both `baseline/verify-record.mjs` files | Generic verification code; public-key construction only. No embedded signing secret found. | Include unchanged. |
| All 68 historical `receipt.json` files | Counts, fixed diagnostic flags, statuses and output hashes; no local paths or fixture canaries. | Include unchanged. |
| All 68 historical `stdout.bin` files | Fixed JSON results; `PRIVATE_*` reason identifiers are diagnostic vocabulary, not exposed fixture canaries. No personal paths, raw account identifiers, credentials or synthetic canary suffixes observed. | Include unchanged. |
| All 68 historical `stderr.bin` files | Empty. | Include unchanged. |
| Historical `original60-raw/RESULT.json`, `order8-raw/RESULT.json` and both raw manifests | Aggregated receipts and relative file references; no personal paths. | Include unchanged. |
| `ADJUDICATION.json`, `PRIOR_APPROVED_ADJUDICATION.json`, `REVIEW.md` | Fixed-code adjudication, claims, hashes and relative references; no personal paths. | Include unchanged as historical evidence. |
| `PRIOR_LITERAL_EVIDENCE.json` | Eleven `lines[*].source` properties expose personal absolute home-directory paths, at lines 5, 14, 23, 32, 41, 50, 59, 68, 77, 86 and 95. | Exclude the entire file. Do not redact it or imply it is present. Its historical hash may be retained for provenance. |
| Original60 suite, order8 suite and successor review `MANIFEST.json` | Relative filenames, sizes, digests and freeze metadata; no personal paths. | May be included unchanged as clearly labelled source-reference manifests. They describe larger historical packages, not the minimal public payload. |

Synthetic canaries include `PRIVATE_ALIAS_f5a7`, `PRIVATE_ACCOUNT_f5a7`, `PRIVATE_IBKR_ALIAS_f5a7`, `PRIVATE_SOURCE_f5a7.csv`, `PRIVATE_RETAINED_f5a7`, `PRIVATE_UNREAD_f5a7`, `PRIVATE_REASON_f5a7`, `PRIVATE_CORRECTION_REASON_f5a7`, `PRIVATE_CHANGED_TEXT_f5a7`, `PRIVATE_REJECTED_f5a7`, `PRIVATE_BINARY_f5a7` and `PRIVATE_HTML_f5a7`. These are intentional leakage traps and should retain their exact bytes.

The binary fixture contains invalid UTF-8 bytes plus the synthetic binary canary. The HTML fixture contains an inert test script that throws `MUST_NOT_RUN`; its markup was inspected as text, never rendered or executed. The noncanonical base64 fixture contains excess padding but decodes to the same synthetic two-row CSV example; preserve the invalid encoding because it is the challenged input.

The frozen reconciliation disclosure text says private/unencrypted because it describes the format’s capabilities; this does not establish that these synthetic contents are actual personal financial records. Conversely, synthetic labels alone were not accepted as proof: decoded source bytes and relevant scalar fields were inspected.

The successor source manifest retains `private_synthetic_evidence: true` and `public_release_eligible: false`. Those historical flags must remain unchanged and must not be presented as publication approval. This review assesses observed payload privacy only; it does not authorize publication or claim that the historical source manifests enumerate the new minimal payload.

The detailed local scan inventory contains personal source paths and is private review evidence. It must not be copied into a public package.
