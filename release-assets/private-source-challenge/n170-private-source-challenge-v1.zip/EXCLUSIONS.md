# Explicit exclusions and source history

Every omitted original payload is listed below with its original hash. Omission never changes an included fixture or expectation. Original full manifests remain unchanged as references. This new public subset is not the original full archive.

The source-review `INPUT_IDENTITIES.json` and `PRIOR_LITERAL_EVIDENCE.json` contain personal absolute paths and are excluded whole. Their hashes remain here. `candidate-preflight/INPUT_VALIDATION.json` is unnecessary private preparation context and is excluded.

Fixture builders, draft case lists, payload-construction intermediates and signing helper are not needed to replay the frozen inputs. In particular, `sign_fixtures.mjs` contains a publicly known mathematical test scalar and is excluded; no replacement fixture or signature is generated. Public signatures and public JWKs in the immutable records remain synthetic test evidence.

| Source freeze | Excluded original path | SHA-256 |
| --- | --- | --- |
| original60 | `CONTRACT_REVIEW.md` | `627df348a8e8c1a623fd285badefa4427042c33d0fd5b5760d55044a16f95ef6` |
| original60 | `build_fixtures.py` | `cf5106d4cbf2949a592af8577ccc76064d5dae164f0af23b053de36858b9046f` |
| original60 | `cases-draft.json` | `c01c05db939b629e9a4828856db7a0ff4bd7cc909c66bef7ba38a825d36784d5` |
| original60 | `contract/BASELINE.json` | `63c1eac047152179145fc571a0ef1ac9920ca6a1a053b7b2a6d244d9fe19894e` |
| original60 | `contract/RESULT.initial.schema.json` | `ca6fbcccc97624f2ca733a8480cafdd7461646ae8b44e34bfeb05f275943c9ae` |
| original60 | `contract/nav-source-checker-contract-clarification-v1-manifest.json` | `68d1a4dc757300d74efe492a4d0157f34bada9281d315b7c1725261875a4afe9` |
| original60 | `contract/nav-source-checker-contract-v1-manifest.json` | `73f03fbe3d32dfcb2172be99605c9693962882dcb5af292ef808c8fd9d63698d` |
| original60 | `contract/nav-source-checker-count-clarification-v1-manifest.json` | `1436556fb692b7b9e541e3fa229231fcc1f2c349369ff38b0f498d492ba032f8` |
| original60 | `contract/nav-source-checker-decision-clarification-v1-manifest.json` | `1faf4c0b01add016900060cc223c5d363cb4e77c1abeed2612f7ec3435da37d7` |
| original60 | `contract/nav-source-checker-numerical-clarification-v1-manifest.json` | `e8bed04a320841358413afce9a3b44666139273004e8e977a3f52235f4b94480` |
| original60 | `fixture-record-validation.json` | `8b270ead910160a41148b720fecdfbdd80a0cdd1743d358a22ad0d6d762a0ed0` |
| original60 | `fixtures/A01-quantization/payloads.json` | `175ddea1edec2cf94f5edff3f3d2239efda2c9859f5000594d83f1ad86bc0790` |
| original60 | `fixtures/A02-invalid-signed-wealth/payloads.json` | `a7c1c3f4e79ee804beba147f3f8a53f5ebed08b05c6f4bfdf1ac4837e37848ba` |
| original60 | `fixtures/A03-source-magnitude/payloads.json` | `cb95d1176692f6b923181f756d75640f2fcb8f63ffd54b008c40fd6868ef4f25` |
| original60 | `fixtures/A04-exact-gross-above-rounded-limit/payloads.json` | `d24e9d012879df3760b83b3f9eae86bd15f29bd9f8a6a0d4f392fd87b43b8350` |
| original60 | `fixtures/A05-rounded-gross-above-limit/payloads.json` | `5498c806c289669639a822defb05d252437b1772240cdd2d62be833a5922a6b3` |
| original60 | `fixtures/A06-positive-nav-nonpositive-adjusted/payloads.json` | `ced26380a4e07fcd27ad85730ed9efb7f14a1f0fdea9cc17953b0aadd3adfd86` |
| original60 | `fixtures/A07-wealth-lower-inclusive/payloads.json` | `ace28af299ab91fbabdcc32d3c24630e2933c69d175256acf1640f1bdc508d6b` |
| original60 | `fixtures/A08-wealth-upper-inclusive/payloads.json` | `bc2cfab1cd12982e8c4c4922bb71ed4b85f8204ee9f0ebf161f3907a31957c63` |
| original60 | `fixtures/C01-select-superseded/payloads.json` | `38f08c89677f5b06b42dd15ae88a88b23affd1476270c80db14cc8757d851f43` |
| original60 | `fixtures/C02-select-correction/payloads.json` | `38f08c89677f5b06b42dd15ae88a88b23affd1476270c80db14cc8757d851f43` |
| original60 | `fixtures/H01-inert-html/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/I01/payloads.json` | `b4a141f0f934f9b84bb84b4c6f8756209ab411558b9cfdd9d56849f7bc7a15b0` |
| original60 | `fixtures/I02-owner-currency/payloads.json` | `3e300fbba5decbbe0f9acac555efa1c7c31d918f2c376754d124a1d5b8a5b344` |
| original60 | `fixtures/I03-ignored-twr/payloads.json` | `9ea48e97e4a6e3b91cd2a0adb77bed8cfbdfe3ae9240a79be4266cb177fe6b1a` |
| original60 | `fixtures/I04-unsupported-asset-transfer/payloads.json` | `3564d75949e0c382bce47ed5df8e2f03468f768ed862c141702aebbcc3cfb3a1` |
| original60 | `fixtures/M01-source-digest/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M02-source-text/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M03-normalized-string/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M04-private-interval/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M05-signed-scope/payloads.json` | `3c19df2552a0478f5b0fb52ab1e32fcea51271007cb490f2254f87e0859be4c1` |
| original60 | `fixtures/M06-signed-returns/payloads.json` | `1e04028dc7205dd39ddd15e4bb0288e9c09ba7f3df2dd507869bee8e61d68902` |
| original60 | `fixtures/M07-rescaled-same-return/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M08-private-normalized-hash/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M09-import-review-hash/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M10-active-review-source-hash/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/M11-signed-normalized-hash/payloads.json` | `7e31e15b298e4017bad1086f11c6a3ffbe8d8092664a3eb78c2e4024e39f801d` |
| original60 | `fixtures/M12-signed-mapping/payloads.json` | `07cb995d52461295fad5011a520db3af5ee2712540a7e67560f9e958a073d7d4` |
| original60 | `fixtures/M13-signed-frequency/payloads.json` | `4a6d5ad13733ad2543a0df59195d4c62446d656b710453ed21694dc938c795a3` |
| original60 | `fixtures/M14-signed-flow-coverage/payloads.json` | `5e95ab80b6d8e996d88d47c8d677903044c2d7640bedf77e48b2498138d4b9a9` |
| original60 | `fixtures/M15-source-row-dependency/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/N01/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/N02/payloads.json` | `ed9cfaae8ce48377222ecc5dbdba43b4705d24dc7ac8f55ddfdf482c58da255e` |
| original60 | `fixtures/N03/payloads.json` | `200e4d9b60dc251d3b118dff33dded89071d915f34e59fabb704c65a47cedf9a` |
| original60 | `fixtures/N04/payloads.json` | `fd67d908706f3d39ae47b0e62f259ac721f087795f570df4756378a0049e2bf0` |
| original60 | `fixtures/N05/payloads.json` | `e8ea12accb79e18ed88d0d51fd8517174e0ce81e9696974ee31bb8cddf6e8b67` |
| original60 | `fixtures/N06/payloads.json` | `048c04d62ec22e3d638391ca316ab90867a063ece817ed7f169a10ce18df5450` |
| original60 | `fixtures/N07/payloads.json` | `b186e7f9e4ba273559d5c4acc51c87315588645d80aeaa880497e72ff9194ccd` |
| original60 | `fixtures/N08/payloads.json` | `eff00e54a16c2e1d3a6d3d5a51235feb908ba1e99de77ba61fee196db9aa2137` |
| original60 | `fixtures/N09/payloads.json` | `b4d5b01b4d70e38595a744c1a96bc2fbdd4d27049630e2d64643944712cf5350` |
| original60 | `fixtures/N10-bom-crlf/payloads.json` | `0dd4d558f2292283d6714ff93829eea01f9f161e543feb938c76c7b4223a6ce7` |
| original60 | `fixtures/N11-quoted-semicolon/payloads.json` | `5a5aeb626dfb86a3b2f217966f76ded03e592e1a510c3d72557b7c12323da7a3` |
| original60 | `fixtures/N12-trimmed-alias/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/P01-mismatch-before-unsupported/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/P02-invalid-signature-before-mismatch/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/P03-duplicate-json/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/P04-missing-event/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/P05-noncanonical-base64/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S01-excluded/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S02-excluded-unread/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S03-excluded-binary/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S04-unresolved/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S05-exclusion-missing-reason/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/S06-superseded-binary/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/U01-preparation-correction/payloads.json` | `bf9becb4265c4a7ef0d843aa8cb5c09a7a2305962fdb22b7420ee9684a8253de` |
| original60 | `fixtures/U02-manual/payloads.json` | `cadbc08f359bc7746c88ea48d1867031ac3eb0a1ffeb6be15ef6ca8a10302f78` |
| original60 | `fixtures/U03-offsetting/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/U04-unknown-timing/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/U05-calendar-gap/payloads.json` | `a99ace86a414182590ef26039536ae1fe734b0b89a401b73b177c4f5647fa220` |
| original60 | `fixtures/U06-rejected-ledger/payloads.json` | `1a3a9b361c2b92490ec95eba4199e7ece1a46d3baa4db53fd43f0b198e6ff609` |
| original60 | `fixtures/U07-expanded-501-intervals/payloads.json` | `7466dffbca4d797e090e3bc20e3365db313344d5293d391f0fb4b8e5f8608434` |
| original60 | `hand-basis/MANIFEST.json` | `044cecbd1fea2d3e870921855d5663ab29d6f44f77ab890f5fbf410122ef993d` |
| original60 | `hand-basis/REQUIREMENTS.md` | `f2f3d7932210a2a6795dc5b836478aed2cab665f9c169697a52adc59fae87d9e` |
| original60 | `hand-basis/arithmetic-cases.json` | `7290a7b48af5838962aaff01c6dd9ab4df6a40c04c907c0c026289eafb1d9956` |
| original60 | `hand-basis/source-pins.json` | `98617729eb2951da4bf676c7e6da8dc3274d9bb88d0dec10518a520ebba83215` |
| original60 | `harness-selfcheck.json` | `cb1f5a7233191f0c5b8f578d8457202c8cc5b76efa6ef50f85fbc0901214aba8` |
| original60 | `input-pins.json` | `6bc6d588d870c76f2aaa495fe1416b0789dda68616304fc6d1bfa459807f282d` |
| original60 | `sign_fixtures.mjs` | `4f3ab77d3444b8b4fd6ab24f3d943af3ddc579829fb24ab55f115e5988ba9dfc` |
| order8 | `BINDING_PRESERVATION.json` | `09dc605c82aae4f7f008702695d6c481370086f9f352fab8c1dc0a4a65cd132a` |
| order8 | `HARNESS_DELTA.json` | `7ee9717fd9a5353a032462eaa4bcba26988633498b2fcd2d183c7ef4d319754f` |
| order8 | `README.md` | `a8be93a1d6cadc15df56b2eed1003bda5d1cd23e9c50d069060538eeeb3a97e4` |
| order8 | `SIGNED_FIXTURE_PRECONDITIONS.json` | `60429daec1848945eccd320b9ea6c69c629eb53c74844d73580e878982b113ea` |
| order8 | `build_supplement.py` | `189be1822331163ceffd6190e046698c796d2e7db0306181fa9cdc16a397012e` |
| accepted-history | `INPUT_IDENTITIES.json` | `577f5f745e1f47b19378127f139b2c6e45ed09f2ccef395bc9a368a14f1b141b` |
| accepted-history | `PRIOR_LITERAL_EVIDENCE.json` | `de00a47d84b6a783ee0d94185563cc7b5e3f48262c4292258ee640724b4355f7` |
| accepted-history | `candidate-preflight/INPUT_VALIDATION.json` | `f7282a3b90f2ea78645a34270e32824d0941d2c99c746f353f1e9a9df8cb5e77` |
