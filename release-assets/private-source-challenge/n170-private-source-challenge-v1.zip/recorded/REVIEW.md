# Independent successor acceptance

The frozen v2 candidate matches all68 bounded status and exit-code expectations:
31 conditional verifications,16 mismatches,13 not-assessable results and8 invalid
inputs. All eight independent source-order cases pass the unmodified supplement
expectations. The active source is accepted in later inventory positions while
source decision ordinals remain faithful to input order; zero/multiple active
sources are refused. The IBKR case with the active source last retains its explicit
currency evidence. The six positive permutation cases also pass every checked
binding flag, source decision, count and limitation assertion.

Raw results remain51 passed and17 flagged: the unchanged original suite reports
43/17, and the supplement reports8/0. Every original-case stdout, stderr and receipt
is byte-for-byte identical to the v1 run (180 matching payloads). Consequently the
only adjudication applied is the previously root-approved treatment of fifteen
broad-prefix privacy false positives and five fixed diagnostic-name variants,
with three cases overlapping. No new exception, financial expectation change or
retroactive receipt edit was introduced. The raw records were frozen before this
adjudication. Both suite invocations ran once.

`ADJUDICATION.json` retains each carried-forward decision. `original60-raw/` and
`order8-raw/` preserve complete observed output streams and receipts.
`ORIGINAL60_BYTE_COMPARISON.json` gives the exact equality proof. The prior approval
basis and literal-source evidence are copied unchanged and hash-pinned. All335
candidate payload identities (9,732,987 bytes) were independently checked before
execution. Both frozen fixture manifests and the unchanged independent signed-record
verifier were enforced by the harnesses.

No unresolved failure was demonstrated by this finite acceptance set. Broader
source review and release integration remain separate. These synthetic cases do
not establish real broker authenticity, account completeness, real identity,
independent publication or financial correctness for all possible inputs. A
conditional verification remains conditional on the supplied private material
and unsigned owner assertions. All artifacts here are private and excluded from
public release inventories. No shared source, candidate or frozen expectation was
changed during this review.
