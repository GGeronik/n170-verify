# Exact minimal content mapping

`PROVENANCE.json` is the machine-readable mapping; `CASE_MAP.tsv` enumerates all 68 cases. Each included original payload is byte-identical to its source freeze, as independently checked by the new data-only verifier.

| Group | Included unchanged files | Bytes |
| --- | ---: | ---: |
| original60 | 130 | 2204644 |
| order8 | 21 | 166403 |
| accepted-history | 213 | 289960 |
| Toolkit licence and notice | 2 | 11480 |

Original60 runtime subset: 120 case input files, unchanged cases, harness, schema and signed-record verifier, plus five contract clarification documents. Order8 runtime subset: 16 case input files, unchanged cases, harness, schema and signed-record verifier. The new per-suite subset manifest is additional and separately identified.

Historical evidence: 204 case stdout/stderr/receipt files; four aggregate result/raw-manifest files; exact accepted adjudication, prior approved adjudication, historical review and original60 byte-comparison proof. Three separate full original manifests bind source provenance.

New files supply runner, data-only archive verifier, pack/subset manifests, provenance/case maps, source pins, explicit exclusions, privacy/static review and user instructions. None replace frozen evidence.

The accepted-history full original manifest retains `public_release_eligible: false`. This candidate is a proposed separately reviewed public subset, not an assertion that the historical private archive was publishable.
