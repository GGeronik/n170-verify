# N170 Verify portable challenge kit

Run the original wave-1 and wave-2 engineering challenges against the exact
accepted app/toolkit source. The kit includes 175 frozen expected cases, their
harnesses and committed synthetic inputs, a separate six-case calculation probe,
and standard-library archive verification. It also includes unchanged fresh
receipts from eight actual local engine executions of four original synthetic
controls, with their prior acquisition plan. Historical private reports, logs
and receipts are excluded. No source is fetched, published or connected to a
broker by the default commands.

This is separately authored **agent engineering validation**, not an external
security audit, outside-user study, financial study or aggregate comparison.
Expected fixtures are original synthetic controls. Hashes identify bytes; they
do not authenticate a publisher, broker, account, execution or earlier timestamp.

## Verify, extract and run

Requirements: Python 3.11 or newer and Node.js 22.12 or newer already installed.
This kit is tested with Python 3.14.6 and Node 24.18.0 on macOS arm64. The default
module challenges use only standard libraries. They require no npm, pip, Docker,
Go, third-party dependency installation or network access. They execute the
explicitly accepted candidate's local code, not untrusted-code sandboxes.

Obtain the standalone `verify_archive.py` and expected ZIP SHA-256 through a
channel you trust. A verifier extracted from an untrusted ZIP is not itself a
trust anchor. In an empty working directory, with the supplied archive, trusted
verifier and separately retained digest:

```sh
python3 -B verify_archive.py public-challenge-kit.zip \
  --expected-sha256 YOUR_SEPARATELY_RETAINED_KIT_SHA256 \
  --extract challenge-kit
cd challenge-kit
python3 -B prepare_source.py --output ../accepted-source
python3 -B run_challenges.py --source ../accepted-source --output ../challenge-results
```

Replace only the digest placeholder. The output and extraction directories must
not already exist. All relative paths in the last two commands are interpreted
from `challenge-kit`. `prepare_source.py` verifies the unchanged bundled
`payload/accepted-source.zip` against SHA-256
`efa705edb9782568aba7561cea448f4e824f1a58cb745930471fb6cee39fe3e5`
and its exact 161-file inventory before publishing a new extraction. Both app
modules and `verify_toolkit` are under `accepted-source/app/`.

`run_challenges.py` verifies the extracted candidate against those exact bytes
before invoking it and checks source identities afterward. Reports and captured
outputs go in your new results directory. Preserve the original archive, its
trusted digest, every run's results and any failures. Do not run a challenge
against a modified source directory while claiming the accepted source identity.

The source candidate includes the accepted wave-2 app/toolkit. The separately
reviewed device-continuity feature is **not** part of this pinned public archive.
Ordinary app builds have their own dependencies and workflow inside the accepted
source's `RELEASE.md`; no app build is required for these module challenges.

## What a receipt-free run means

Parser, signed-record, viewer/mock, reconciliation and local harness checks can
run immediately. Receipt-dependent cases and their six historical Python harness
tests report `NOT_RUN` when no explicitly pinned receipt input is supplied.
Actual engine execution and the planted-sentinel public-build challenge also
remain `NOT_RUN` in this module runner. These are not passing cases.

`UNSUPPORTED` is different: it means the original expected case or the tested
surface expressly lacks a capability, such as discovering a wholly unknown
omitted attempt, broker authentication, actual TEE verification, missing
intraperiod valuations or a comparison operation absent from the browser module.
Unsupported cases are excluded from false-acceptance and false-rejection
denominators. `NOT_RUN` means a prerequisite was unavailable or a separate
execution was not requested. Read every dimension and reason independently;
there is no combined pass percentage or comparative winner score.

`PARTIAL` preserves a case with both passing supported operations and unsupported
operations. It is never promoted to a complete pass. Exit codes
are `0` for complete coverage without failures, `1` for failed checks and `2`
for incomplete coverage without scored failures. Both documented workflows
currently return `2`: the separate engine and public-build challenges are unrun.
Inspect `report.json`; do not replace exit `2` with a claim of full success.

## Check the bundled actual synthetic receipts

From the extracted kit root, explicitly select the retained receipts and the
freeze pin recorded before this package was assembled:

```sh
python3 -B run_challenges.py --source ../accepted-source \
  --receipts receipts \
  --receipt-freeze-sha256 f510104c165d61705472197ad5b21a765d180071410b4392a1ca430b81707ec7 \
  --output ../receipt-challenge-results
```

Both receipt arguments are required together. The wrapper does not trust a
self-declared or automatically calculated receipt pin. You may supply another
directory with its independently retained pin using the same arguments. See
[receipt input contract](RECEIPTS.md) for exact layout and limitations. Passing
these checks verifies supplied relationships and frozen challenge expectations;
it does not prove a producer actually executed an engine. Actual engine controls
remain a separate dimension even when real retained receipts are provided.
The bundled biased control reports a future-dependent `future_close` indicator,
with zero biased entry and exit signals. These are four synthetic controls and
repeats, not eight independent accuracy cases or evidence of profitable trading.

## Self-tests and original inputs

From the extracted kit root:

```sh
python3 -B -m unittest discover -s tests -v
```

The default challenge run separately exercises the original portable Python and
Node harness self-tests. Tests create disposable original synthetic inputs;
they never turn those into claims of actual engine execution. Use `-B` as shown
to keep Python bytecode out of explicitly inventoried source directories.

- [EXPECTED_CASES.json](EXPECTED_CASES.json) indexes all eight original oracle
  files and 175 case IDs, with separate SHA-256 commitments and rationale in the
  unchanged files under `original/verify_benchmarks/`.
- [INPUTS.json](INPUTS.json) records every copied original file and source pin.
- [PUBLIC_POLICY.json](PUBLIC_POLICY.json) states the distribution boundary.
- [comparison/README.md](comparison/README.md) explains the original six-case
  N170 probe and the separately supplied, explicitly unexecuted Go recipe.
- [VALIDATION.md](VALIDATION.md) distinguishes what was run for this candidate
  from omitted prerequisites, unsupported dimensions and untested environments.

The original `wave2/run_review.py` is preserved byte-for-byte, including its
historical receipt pin and private default. Do not invoke its private default.
The portable wrapper uses a disclosed adapter with an explicit caller-supplied
pin; it retains the historical pin separately and records the actual pin used.
Historical reports and original result-summary documentation were omitted rather
than republished as current recipient results.

## Archive and extraction boundary

`public-inventory.json` explicitly lists every shipped payload file except
itself. The standalone archive verifier requires exactly that membership,
checks every size and hash, rejects ambiguous or unsafe paths, duplicate names,
symlinks, special files and oversized expansion, and validates the captured ZIP
bytes before extraction. A separately held outer ZIP digest also binds the
inventory. Without it, successful verification establishes only internal
consistency, not externally anchored identity.

Extraction stages checked bytes beside the requested destination and publishes
using an atomic operation that will not replace an existing destination.
Verification is portable Python standard-library code. Atomic extraction uses
available OS APIs and fails closed on unsupported platforms; macOS is the
executed platform for this kit's validation. No overwrite or partial final
extraction is treated as success.
