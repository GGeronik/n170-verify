#!/usr/bin/env python3
"""Build an explicit-inventory-only reproducible ZIP; never add discovered files.

All members are stored without compression in sorted order, with the DOS epoch,
fixed regular-file permissions and no platform-dependent metadata. The source
tree must contain exactly the root-authored inventory and its listed files.
Run with python3 -B to suppress any interpreter bytecode artifacts.
"""

import sys
sys.dont_write_bytecode = True

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import zipfile

from verify_archive import (ArchiveError, INVENTORY, MAX_ARCHIVE, MAX_FILE,
                            MAX_INVENTORY, parse_inventory, publish_no_replace,
                            require, verify_bytes, source_file_names,
                            capture_source_file)


def build_bytes(root):
    root = Path(root).resolve(strict=True)
    require(root.is_dir(), "Source root must be a directory")
    inventory_bytes = capture_source_file(root, INVENTORY, MAX_INVENTORY)
    inventory = parse_inventory(inventory_bytes)
    expected = {entry["path"] for entry in inventory["files"]} | {INVENTORY}
    require(set(source_file_names(root)) == expected, "Source tree contains unlisted files or omits listed files")
    members = {INVENTORY: inventory_bytes}
    for entry in inventory["files"]:
        data = capture_source_file(root, entry["path"], min(MAX_FILE, entry["size"]))
        require(len(data) == entry["size"] and hashlib.sha256(data).hexdigest() == entry["sha256"], "Source inventory mismatch: " + entry["path"])
        members[entry["path"]] = data
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
        for name in sorted(members):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, members[name])
    result = output.getvalue()
    require(len(result) <= MAX_ARCHIVE, "Built ZIP exceeds archive byte limit")
    verify_bytes(result)
    return result


def build_archive(root, destination):
    destination = Path(destination)
    parent = destination.parent.resolve(strict=True)
    destination = parent / destination.name
    require(not os.path.lexists(destination), "Build output already exists")
    resolved_root = Path(root).resolve(strict=True)
    require(not destination.is_relative_to(resolved_root), "Build output must be outside the source root")
    data = build_bytes(resolved_root)
    descriptor, temporary = tempfile.mkstemp(prefix=".n170-build-", dir=parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        publish_no_replace(temporary, destination)
    finally:
        if os.path.lexists(temporary):
            os.unlink(temporary)
    return hashlib.sha256(data).hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args(argv)
    try:
        digest = build_archive(args.root, args.output)
        print(json.dumps({"archive": str(args.output), "sha256": digest, "inventory": INVENTORY}, sort_keys=True))
        return 0
    except (ArchiveError, OSError) as exc:
        print("Archive build failed: %s" % exc, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
