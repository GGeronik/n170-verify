"""Explicit fresh-receipt adapter for the unchanged historical wave-2 harness.

No receipt path or trust pin has a default. The caller must retain the freeze
hash separately. Hash agreement establishes bytes, not execution authenticity.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

from verify_archive import capture_source_file, source_file_names, validate_path_set

HISTORICAL_RECEIPT_SHA256 = '0ab643e5509671753cc59318cda484b8f5e72ddd6e0f7e2bfd269cf312308151'
PURPOSE = ('Apply the unchanged historical expectations and mutations to explicit '
           'fresh caller-pinned receipts; replace only the in-memory receipt freeze '
           'pin during this call, restoring it afterward. Use a byte-identical '
           'temporary writable copy so mutation tests work with read-only receipts. '
           'No historical source or supplied receipt files change.')
RECEIPT_NAMES = {'rerun-a', 'rerun-b', 'mixed-controls'}
MAX_FREEZE_BYTES = 1024 * 1024
MAX_RECEIPT_FILES = 1024
MAX_RECEIPT_FILE_BYTES = 16 * 1024 * 1024
MAX_RECEIPT_TOTAL_BYTES = 64 * 1024 * 1024


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_json(raw):
    def pairs(entries):
        obj = {}
        for key, value in entries:
            if key in obj:
                raise ValueError('Duplicate JSON field: ' + key)
            obj[key] = value
        return obj
    def constant(value):
        raise ValueError('Nonfinite JSON number: ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def require_pin(value):
    if not isinstance(value, str) or re.fullmatch(r'[0-9a-f]{64}', value) is None:
        raise ValueError('Receipt freeze pin must be exactly 64 lowercase hexadecimal characters')
    return value


def no_symlink_path(path):
    path = Path(path).absolute()
    for part in [path, *path.parents]:
        if part.is_symlink():
            raise ValueError('Symlink in explicit input path: ' + str(part))
    return path


def capture_receipts(receipts, freeze_sha256):
    """Capture bounded bytes; check the caller pin BEFORE parsing the freeze."""
    require_pin(freeze_sha256)
    root = no_symlink_path(receipts).resolve()
    if not root.is_dir():
        raise ValueError('Explicit receipt root must be a regular directory')
    raw = capture_source_file(root, 'receipt-freeze.json', MAX_FREEZE_BYTES)
    if sha256(raw) != freeze_sha256:
        raise ValueError('Receipt freeze differs from caller-supplied retained pin')
    captured = {'receipt-freeze.json': raw}
    freeze = strict_json(raw)
    if not isinstance(freeze, dict) or not isinstance(freeze.get('files'), list):
        raise ValueError('Receipt freeze must declare a files array')
    if not 0 < len(freeze['files']) <= MAX_RECEIPT_FILES:
        raise ValueError('Receipt freeze file count exceeds its bound')
    pins = freeze.get('receipt_manifest_pins')
    if not isinstance(pins, dict) or set(pins) != RECEIPT_NAMES:
        raise ValueError('Receipt freeze must pin rerun-a, rerun-b, and mixed-controls')
    for pin in pins.values():
        require_pin(pin)
    declared = {}
    for entry in freeze['files']:
        if not isinstance(entry, dict) or set(entry) != {'path', 'size', 'sha256'}:
            raise ValueError('Receipt file descriptors require path, size, sha256')
        name = entry['path']
        if (not isinstance(name, str) or '\\' in name or ':' in name or '\x00' in name
                or any(p in {'', '.', '..'} for p in name.split('/'))):
            raise ValueError('Unsafe receipt inventory path')
        parts = name.split('/')
        if len(parts) < 2 or parts[0] not in RECEIPT_NAMES or name in declared:
            raise ValueError('Duplicate or unexpected receipt inventory path')
        if type(entry['size']) is not int or not 0 <= entry['size'] <= MAX_RECEIPT_FILE_BYTES:
            raise ValueError('Receipt byte length exceeds its bound or is not a nonnegative integer')
        require_pin(entry['sha256'])
        declared[name] = entry
    if sum(entry['size'] for entry in declared.values()) > MAX_RECEIPT_TOTAL_BYTES:
        raise ValueError('Receipt inventory exceeds total byte bound')
    validate_path_set(declared)
    actual = set(source_file_names(root)) - {'receipt-freeze.json'}
    if actual - set(declared):
        raise ValueError('Unlisted supplied receipt file: ' + sorted(actual - set(declared))[0])
    if actual != set(declared):
        raise ValueError('Missing supplied receipt files')
    for name in sorted(declared):
        entry = declared[name]
        try:
            # fstat checks the pinned size limit before allocation; component
            # no-follow and nonblocking reads reject link/FIFO substitutions.
            content = capture_source_file(root, name, entry['size'])
        except ValueError as exc:
            raise ValueError('Supplied receipt byte identity mismatch: ' + name + ': ' + str(exc)) from exc
        if len(content) != entry['size'] or sha256(content) != entry['sha256']:
            raise ValueError('Supplied receipt byte identity mismatch: ' + name)
        captured[name] = content
    for name, pin in pins.items():
        descriptor = declared.get(name + '/manifest.json')
        if descriptor is None or descriptor['sha256'] != pin:
            raise ValueError('Supplied receipt manifest pin mismatch: ' + name)
    return ({'freeze_sha256': freeze_sha256, 'files': [declared[k] for k in sorted(declared)],
             'receipt_manifest_pins': pins}, captured)


def validate_receipts(receipts, freeze_sha256):
    """Return identity metadata only; never replace a caller's pin with our hash."""
    return capture_receipts(receipts, freeze_sha256)[0]


def metadata(freeze_sha256, *, staged=False):
    return {'schema': 'n170.public-challenge.receipt-adapter.v1',
            'historical_default_receipt_freeze_sha256': HISTORICAL_RECEIPT_SHA256,
            'caller_supplied_receipt_freeze_sha256': freeze_sha256,
            'purpose': PURPOSE, 'original_source_modified': False,
            'receipt_staging': ('Byte-identical temporary copy; only copy permissions become owner-writable'
                                if staged else 'Not used by this adapter call'),
            'engine_execution_performed': False}


@contextmanager
def explicit_receipt_pin(module, freeze_sha256):
    """A process-local, nonconcurrent adapter; historical module stays unchanged."""
    require_pin(freeze_sha256)
    original = module.RECEIPT_SHA
    if original != HISTORICAL_RECEIPT_SHA256:
        raise ValueError('Unexpected original historical receipt pin')
    module.RECEIPT_SHA = freeze_sha256
    try:
        yield
    finally:
        module.RECEIPT_SHA = original


def run_with_receipts(toolkit, app, receipts, *, freeze_sha256):
    before, captured = capture_receipts(receipts, freeze_sha256)
    module = importlib.import_module('verify_benchmarks.wave2.run_review')
    # Real finalized receipts may have read-only directories. The original
    # harness copies modes before replacing an artifact with a symlink; stage
    # writable copies rather than changing either the harness or input modes.
    with tempfile.TemporaryDirectory(prefix='n170-public-receipt-adapter-') as temporary:
        staged = Path(temporary).resolve() / 'receipts'
        staged.mkdir(mode=0o700)
        for name, raw in captured.items():
            path = staged / name
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with path.open('xb') as file:
                file.write(raw)
            path.chmod(0o600)
        if validate_receipts(staged, freeze_sha256) != before:
            raise ValueError('Staged receipt bytes differ from supplied receipts')
        with explicit_receipt_pin(module, freeze_sha256):
            report = module.run(toolkit, app, staged)
        if validate_receipts(staged, freeze_sha256) != before:
            raise ValueError('Staged receipt bytes changed during challenges')
    if validate_receipts(receipts, freeze_sha256) != before:
        raise ValueError('Supplied receipts changed during challenges')
    report['public_kit_adapter'] = metadata(freeze_sha256, staged=True)
    return report


def test_with_receipts(receipts, *, freeze_sha256):
    """Run the six original tests with only their hardcoded loader redirected."""
    before = validate_receipts(receipts, freeze_sha256)
    module = importlib.import_module('verify_benchmarks.wave2.run_review')
    tests = importlib.import_module('verify_benchmarks.wave2.test_run_review_harness')
    original_loader = tests.receipt_envelopes
    try:
        with explicit_receipt_pin(module, freeze_sha256):
            tests.receipt_envelopes = lambda _historical_path: module.receipt_envelopes(Path(receipts))
            suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
            result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run(suite)
    finally:
        tests.receipt_envelopes = original_loader
    if validate_receipts(receipts, freeze_sha256) != before:
        raise ValueError('Supplied receipts changed during harness tests')
    return {'schema': 'n170.public-challenge.harness-result.v1', 'tests_run': result.testsRun,
            'failures': len(result.failures), 'errors': len(result.errors),
            'skipped': len(result.skipped), 'successful': result.wasSuccessful(),
            'public_kit_adapter': metadata(freeze_sha256)}
