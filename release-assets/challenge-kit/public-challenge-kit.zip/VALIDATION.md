# Candidate validation and limits

These results describe local AI agent engineering validation on macOS arm64,
Python 3.14.6 and Node 24.18.0. They are not external audit results. The commands
in README produce each recipient's own reports; this package does not relabel
historical private reports as new results.

The executed pinned-receipt workflow checks the accepted source archive
`efa705edb9782568aba7561cea448f4e824f1a58cb745930471fb6cee39fe3e5`
and the fresh receipt freeze
`f510104c165d61705472197ad5b21a765d180071410b4392a1ca430b81707ec7`.
It records the following coverage across the 175 original expected cases:

| Original specification | PASS | PARTIAL | UNSUPPORTED | NOT_RUN |
| --- | ---: | ---: | ---: | ---: |
| Wave 1 toolkit | 18 | 0 | 4 | 0 |
| Wave 1 signed account | 25 | 0 | 6 | 0 |
| Wave 1 viewer | 30 | 0 | 5 | 0 |
| Wave 1 AuditZK mock | 21 | 0 | 1 | 0 |
| Wave 1 receipt challenges | 9 | 0 | 1 | 0 |
| Wave 1 engine execution | 0 | 0 | 0 | 5 |
| Wave 2 expected | 29 | 8 | 6 | 1 |
| Wave 2 supplemental | 6 | 0 | 0 | 0 |

No scored case failed. The eight partial cases preserve a passing Python
operation and an unsupported browser operation. Wave 2 receipt operations have
23/23 supported Python checks and 15/15 supported browser checks, with eight
browser operations unsupported. Those surface counts overlap case IDs and must
not be added to the 175-case total. Overall status is `INCOMPLETE`, exit `2`.

All 49 original harness self-tests pass with explicitly pinned receipts:
17 Python base tests, 26 Node tests and six receipt-dependent Python tests.
The six-case N170 calculation probe also passes independently of the 175-case
ledger. Its two module identities are checked. The Go recipe is `NOT_RUN`.

Without receipt arguments, the wrapper runs 43 original harness tests and marks
the six receipt-dependent self-tests `NOT_RUN`. The wave-1 receipt cases and
receipt-dependent wave-2 operations remain unrun. Engine and sentinel public
build challenges remain `NOT_RUN` in either workflow. Missing intraperiod data,
unknown omitted attempts, identity or TEE claims are not treated as successes.

All 77 kit self-tests and 12 separately authored wrapper probes pass. The tests
cover archive membership and commitments, ambiguous and
unsafe names, malformed ZIP structures, special files, bounded reads, source
substitution, output containment, atomic no-replace extraction, receipt pins,
unsupported/partial aggregation and preservation of input bytes and permissions.
Atomic extraction has been exercised on macOS; Linux and Windows-specific API
paths and older supported Python/Node versions are unexecuted in this validation.

Development failures were preserved separately. Initial archive tests exposed
test-harness defects. A first full receipt run failed when the historical
mutation harness inherited read-only directory modes. The adapter now stages
bounded verified bytes in a disposable writable directory. Independent probes
also found and verified fixes for parent-directory output containment, FIFO
archive admission and unbounded receipt reads. Corrected tests and full runs
were repeated; original source, fixtures and receipt bytes remained unchanged.

The fresh receipt acquisition retained every selected attempt, including the
never-triggered and failed controls. The future-dependent indicator control
reports `future_close`, with ten checked signals and zero biased entry or exit
signals. Eight executions of four controls do not establish detection accuracy,
biased trading decisions or real-market performance. A separate AI review of
that acquisition accepted its frozen synthetic-control scope; this is not an
authenticated engine-execution attestation or independent human audit.

Final ZIP identity, exact extraction checks and recipient rerun outputs are
retained in the separate candidate handoff. Archive verification establishes
byte identity to an externally retained digest, not authenticity of its author.
