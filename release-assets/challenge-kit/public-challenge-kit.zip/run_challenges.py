#!/usr/bin/env python3
"""Run frozen public challenges against an explicitly prepared accepted source.

Python 3.10+ stdlib; Node.js is needed for JavaScript surfaces. No install,
network, Docker, or actual engine execution is performed. Exit 0 = complete,
1 = failed check/execution/preflight, 2 = incomplete coverage (NOT_RUN or
UNSUPPORTED). Original detailed reports remain authoritative per dimension.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import unittest

sys.dont_write_bytecode = True
KIT = Path(__file__).resolve().parent
ORIGINAL = KIT / 'original' / 'verify_benchmarks'
SCHEMA = 'n170.public-challenge.run.v1'
RECEIPT_CONTROL_STATUS = 'FINDINGS_REPORTED'
RECEIPT_CONTROL_RATIONALE = ('Frozen before candidate observations: rerun-a contains '
    'the synthetic N170Clean and intentionally future-dependent N170Biased controls; '
    'their assessable receipt must report FINDINGS_REPORTED. This is an offline '
    'receipt expectation, not proof that this runner executed an engine.')
SPECIFICATIONS = {
    'wave1.toolkit': 'fixtures/toolkit-cases.json',
    'wave1.account': 'account/cases.json',
    'wave1.viewer': 'viewer/cases.json',
    'wave1.auditzk-mock': 'viewer/auditzk-mock-cases.json',
    'wave1.receipts': 'fixtures/receipt-cases.json',
    'wave1.engine': 'fixtures/engine-cases.json',
    'wave2.expected': 'wave2/expected-cases.json',
    'wave2.supplemental': 'wave2/supplemental-cases.json',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def adapter():
    if str(KIT) not in sys.path:
        sys.path.insert(0, str(KIT))
    return importlib.import_module('adapters.wave2_run_review')


def read_json(path):
    return adapter().strict_json(Path(path).read_bytes())


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as output:
        json.dump(value, output, sort_keys=True, indent=2, allow_nan=False)
        output.write('\n')


def inventory(root):
    root = adapter().no_symlink_path(root)
    if not root.is_dir():
        raise ValueError('Input inventory root is not a directory: ' + str(root))
    verifier = importlib.import_module('verify_archive')
    files, total = [], 0
    for name in sorted(verifier.source_file_names(root)):
        raw = verifier.capture_source_file(root, name, verifier.MAX_FILE)
        total += len(raw)
        if total > verifier.MAX_TOTAL:
            raise ValueError('Input tree exceeds its total byte bound')
        files.append({'path': name, 'size': len(raw), 'sha256': sha(raw)})
    canonical = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
    return {'sha256': sha(canonical), 'files': files}


def check_originals():
    inputs = read_json(KIT / 'INPUTS.json')
    declared = {entry['path']: entry for entry in inputs['copied_original_files']}
    for name, entry in declared.items():
        raw = adapter().capture_source_file(KIT, name, entry['size'])
        if len(raw) != entry['size'] or sha(raw) != entry['sha256']:
            raise ValueError('Original benchmark input identity changed: ' + name)
    actual = inventory(ORIGINAL)
    wanted = {name.removeprefix('original/verify_benchmarks/') for name in declared
              if name.startswith('original/verify_benchmarks/')}
    if {entry['path'] for entry in actual['files']} != wanted:
        raise ValueError('Original benchmark tree contains missing or unlisted files')
    return actual


def specifications():
    result = {}
    for name, relative in SPECIFICATIONS.items():
        path = ORIGINAL / relative
        raw = path.read_bytes()
        pin = path.with_suffix('.sha256').read_text().split()[0]
        if sha(raw) != pin:
            raise ValueError('Frozen case specification changed: ' + relative)
        doc = adapter().strict_json(raw)
        if not isinstance(doc.get('cases'), list):
            raise ValueError('Missing frozen cases: ' + relative)
        ids = [case['id'] for case in doc['cases']]
        if len(ids) != len(set(ids)):
            raise ValueError('Duplicate frozen case IDs: ' + relative)
        result[name] = {'path': relative, 'sha256': pin, 'cases': doc['cases']}
    return result


def validate_options(source, output, receipts=None, freeze_sha256=None):
    if (receipts is None) != (freeze_sha256 is None):
        raise ValueError('--receipts and --receipt-freeze-sha256 must be supplied together')
    if freeze_sha256 is not None:
        adapter().require_pin(freeze_sha256)
    # Reject symlinks first, then collapse dot segments before comparing ancestry.
    source = adapter().no_symlink_path(source).resolve()
    output = adapter().no_symlink_path(output).resolve(strict=False)
    if not source.is_dir():
        raise ValueError('--source must be an extracted accepted source directory')
    if output.exists():
        raise ValueError('--output must name a new directory; existing output is never overwritten')
    if not output.parent.is_dir():
        raise ValueError('--output parent directory must already exist')
    receipts = adapter().no_symlink_path(receipts).resolve() if receipts is not None else None
    for immutable in [source, KIT, *([receipts] if receipts else [])]:
        if output == immutable or immutable in output.parents or output in immutable.parents:
            raise ValueError('--output must be separate from source, the public kit, and receipts')
    return source, output, receipts


def verify_source(source):
    """Use the separate archive checker before importing any candidate code."""
    if str(KIT) not in sys.path:
        sys.path.insert(0, str(KIT))
    prepare = importlib.import_module('prepare_source')
    verifier = importlib.import_module('verify_archive')
    files = prepare.read_verified_source()
    verifier.verify_extracted_files(files, source)
    return inventory(source)


def worker(action, params):
    """Internal isolated subprocess entry point; no private receipt defaults."""
    sys.path.insert(0, str(KIT / 'original'))
    sys.path.insert(0, str(KIT))
    if action == 'toolkit':
        report = importlib.import_module('verify_benchmarks.toolkit').run(params['app'])
    elif action == 'receipts':
        checked = adapter().validate_receipts(params['receipts'], params['freeze_sha256'])
        module = importlib.import_module('verify_benchmarks.receipts')
        report = module.run(params['app'], Path(params['receipts']) / 'rerun-a',
                            RECEIPT_CONTROL_STATUS, checked['receipt_manifest_pins']['rerun-a'])
        report['public_kit_adapter'] = adapter().metadata(params['freeze_sha256'])
        report['control_expectation_rationale'] = RECEIPT_CONTROL_RATIONALE
        if adapter().validate_receipts(params['receipts'], params['freeze_sha256']) != checked:
            raise ValueError('Supplied receipts changed during wave-1 checks')
    elif action == 'wave2-run-review':
        report = adapter().run_with_receipts(params['app'], params['app'], params['receipts'],
                                            freeze_sha256=params['freeze_sha256'])
    elif action == 'wave2-receipt-harness':
        report = adapter().test_with_receipts(params['receipts'], freeze_sha256=params['freeze_sha256'])
    elif action == 'python-harness':
        suite = unittest.TestSuite()
        for name in ['test_toolkit_benchmark', 'test_engine_receipt_challenges']:
            module = importlib.import_module('verify_benchmarks.tests.' + name)
            suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
        result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run(suite)
        report = {'schema': 'n170.public-challenge.harness-result.v1',
                  'tests_run': result.testsRun, 'failures': len(result.failures),
                  'errors': len(result.errors), 'skipped': len(result.skipped),
                  'successful': result.wasSuccessful()}
    else:
        raise ValueError('Unknown worker action')
    write_json(params['report'], report)
    return 1 if report_has_failures(report) else 0


def report_has_failures(report):
    summary = report.get('summary', {})
    repeat = report.get('reproducibility', {})
    return bool(summary.get('failures') or summary.get('all_failures')
                or repeat.get('failures') or repeat.get('identical') is False
                or (repeat.get('denominator') is not None
                    and repeat.get('equal_cases') is not None
                    and repeat['equal_cases'] != repeat['denominator'])
                or report.get('candidate_unchanged') is False
                or report.get('successful') is False)


def run_command(name, command, output, *, report_name=None, stdout_json=False, timeout=600):
    started = time.monotonic()
    stdout_path, stderr_path = output / (name + '.stdout.log'), output / (name + '.stderr.log')
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    # Prevent inherited Node startup hooks from changing the checked candidate.
    for key in ['NODE_OPTIONS', 'NODE_PATH', 'PYTHONPATH', 'PYTHONHOME']:
        env.pop(key, None)
    outcome = {'id': name, 'command': command, 'stdout': stdout_path.name, 'stderr': stderr_path.name}
    try:
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            completed = subprocess.run(command, cwd=output, env=env, stdout=stdout, stderr=stderr,
                                       timeout=timeout, check=False)
        outcome.update(returncode=completed.returncode,
                       status='COMPLETED' if completed.returncode == 0 else 'FAILED')
        if stdout_json:
            observation = read_json(stdout_path)
            outcome.update(observation=stdout_path.name, observation_sha256=sha(stdout_path.read_bytes()),
                           observed_case_count=len(observation.get('results', [])))
        elif report_name:
            path = output / report_name
            if not path.is_file():
                outcome.update(status='ERROR', reason='Harness did not produce its required detailed report')
            else:
                report = read_json(path)
                outcome.update(report=report_name, report_sha256=sha(path.read_bytes()))
                if report_has_failures(report):
                    outcome['status'] = 'FAILED'
                if 'tests_run' in report:
                    outcome['harness_tests'] = {k: report[k] for k in ['tests_run', 'failures', 'errors', 'skipped']}
        else:
            tap = stdout_path.read_text(errors='replace')
            counts = dict(re.findall(r'^# (tests|pass|fail|skipped) (\d+)$', tap, re.MULTILINE))
            outcome['harness_tests'] = {key: int(value) for key, value in counts.items()}
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        outcome.update(status='ERROR', reason=type(exc).__name__ + ': ' + str(exc))
    outcome['duration_seconds'] = round(time.monotonic() - started, 3)
    return outcome


def not_run(name, reason):
    return {'id': name, 'status': 'NOT_RUN', 'reason': reason}


def python_command(action, app, output, name, receipts, freeze_sha256):
    params = {'app': str(app), 'report': str(output / (name + '.json'))}
    if receipts is not None:
        params.update(receipts=str(receipts), freeze_sha256=freeze_sha256)
    return [sys.executable, '-I', '-S', '-B', str(KIT / 'run_challenges.py'),
            '--_worker', action, json.dumps(params)]


def case_status(case):
    outcome = case.get('outcome', case.get('classification'))
    if case.get('failures'):
        return 'FAIL'
    if outcome == 'unsupported':
        return 'UNSUPPORTED'
    if outcome in {'pass', 'true_acceptance', 'true_rejection'}:
        if any(result.get('outcome') == 'unsupported' for result in case.get('surface_results', {}).values()):
            return 'PARTIAL'
        return 'PASS'
    return 'FAIL'


def coverage_ledger(specs, suites, output):
    indexed, suite_by_id = {}, {suite['id']: suite for suite in suites}
    for suite in suites:
        if 'report' not in suite:
            continue
        for case in read_json(output / suite['report']).get('cases', []):
            if case['id'] in indexed:
                raise ValueError('Duplicate executed case ID: ' + case['id'])
            indexed[case['id']] = (suite, case)
    ledger = []
    for spec_name, spec in specs.items():
        for expected in spec['cases']:
            cid = expected['id']
            row = {'id': cid, 'specification': spec_name, 'specification_sha256': spec['sha256'],
                   'expected': expected.get('expected', expected.get('expected_status')),
                   'dimension': expected.get('dimension', expected.get('scope', spec_name))}
            if cid in indexed:
                suite, case = indexed[cid]
                row.update(status=case_status(case), suite=suite['id'], report=suite['report'],
                           original_outcome=case.get('outcome', case.get('classification')),
                           failures=case.get('failures', []))
                if 'surface_results' in case:
                    row['surface_results'] = case['surface_results']
            elif cid == 'legacy.signed-records':
                suite = suite_by_id['wave1.account']
                required = [c['id'] for c in specs['wave1.account']['cases']
                            if not c.get('expected', {}).get('unsupported')]
                observed = [case_status(indexed[ref][1]) if ref in indexed else 'NOT_RUN' for ref in required]
                status = ('FAIL' if suite['status'] in {'FAILED', 'ERROR'} or 'FAIL' in observed else
                          'NOT_RUN' if suite['status'] == 'NOT_RUN' or 'NOT_RUN' in observed else
                          'PASS' if observed and all(s == 'PASS' for s in observed) else 'PARTIAL')
                row.update(status=status,
                           suite='wave1.account', mapped_case_ids=list(c['id'] for c in specs['wave1.account']['cases']),
                           reason='Exact frozen legacy account suite and its two-process reproducibility check')
            elif cid == 'legacy.signature-tamper':
                refs = ['account.altered_payload', 'account.altered_signature']
                statuses = [case_status(indexed[ref][1]) if ref in indexed else 'NOT_RUN' for ref in refs]
                row.update(status='PASS' if all(s == 'PASS' for s in statuses) else
                           'FAIL' if 'FAIL' in statuses else 'NOT_RUN',
                           suite='wave1.account', mapped_case_ids=refs,
                           reason='Unchanged payload and signature mutation expectations from frozen legacy cases')
            else:
                sid = spec_name if spec_name.startswith('wave1.') else (
                    'wave2.run-review' if expected.get('dimension') in {'bundle', 'comparison'}
                    else 'wave2.public-build' if cid == 'privacy.public-build' else 'wave2.reconciliation')
                suite = suite_by_id.get(sid, {})
                row.update(status='NOT_RUN', suite=sid, reason=suite.get('reason',
                    'Required case absent from completed harness report'))
                if suite.get('status') == 'COMPLETED':
                    row.update(status='FAIL', reason='Required case omitted by completed harness')
            ledger.append(row)
    return ledger


def run(source, output, *, receipts=None, freeze_sha256=None):
    source, output, receipts = validate_options(source, output, receipts, freeze_sha256)
    original_before = check_originals()
    specs = specifications()
    source_before = verify_source(source)
    receipt_before = adapter().validate_receipts(receipts, freeze_sha256) if receipts is not None else None
    output.mkdir()
    app = source / 'app'
    suites = []
    node = shutil.which('node')
    for name, action in [('harness.python', 'python-harness'), ('wave1.toolkit', 'toolkit')]:
        suites.append(run_command(name, python_command(action, app, output, name, None, None),
                                  output, report_name=name + '.json'))
    node_harness = ['tests/account.test.mjs', 'tests/test_viewer_benchmark.mjs',
                    'tests/test_auditzk_mock_benchmark.mjs', 'wave2/harness.test.mjs']
    if node:
        suites.append(run_command('harness.node', [node, '--test', '--test-reporter=tap',
                                                  *[str(ORIGINAL / p) for p in node_harness]], output))
    else:
        suites.append(not_run('harness.node', 'Node.js executable unavailable'))
    for name, script in [('wave1.account', 'account/run.mjs'), ('wave1.viewer', 'viewer/run.mjs'),
                         ('wave1.auditzk-mock', 'viewer/auditzk-mock-run.mjs'),
                         ('wave2.reconciliation', 'wave2/reconciliation.mjs')]:
        if node:
            suites.append(run_command(name, [node, str(ORIGINAL / script), '--target', str(app),
                                             '--output', str(output / (name + '.json'))],
                                      output, report_name=name + '.json'))
        else:
            suites.append(not_run(name, 'Node.js executable unavailable'))
    for name, action in [('harness.wave2-receipts', 'wave2-receipt-harness'),
                         ('wave1.receipts', 'receipts'), ('wave2.run-review', 'wave2-run-review')]:
        if receipts is None:
            suites.append(not_run(name, 'No explicit receipts and independently retained receipt freeze pin supplied'))
        elif name == 'wave2.run-review' and not node:
            suites.append(not_run(name, 'Node.js required by unchanged dual-surface receipt harness'))
        else:
            suites.append(run_command(name, python_command(action, app, output, name, receipts, freeze_sha256),
                                      output, report_name=name + '.json'))
    suites.append(not_run('wave1.engine', 'Actual pinned engine execution is not performed by this offline runner; '
                          'receipt verification and harness tests do not establish fresh engine execution'))
    suites.append(not_run('wave2.public-build', 'Frozen case requires a planted private sentinel and fresh site/source/review '
                          'builds. Extracted-archive identity checking does not exercise that build scenario'))
    if node:
        suites.append(run_command('comparison.n170', [node, str(KIT / 'comparison/n170-probe.mjs'),
                                                       str(app / 'src/calculator.js')], output, stdout_json=True))
    else:
        suites.append(not_run('comparison.n170', 'Node.js executable unavailable'))
    suites.append(not_run('comparison.upstream', 'The portable Go comparison adapter and fixtures are included, '
                          'but no upstream implementation, runtime, or binary is bundled or executed'))
    immutable_checks, immutable_errors = {}, []
    for name, operation, before in [('source', lambda: inventory(source), source_before),
                                     ('originals', check_originals, original_before),
                                     *([('receipts', lambda: adapter().validate_receipts(receipts, freeze_sha256), receipt_before)]
                                       if receipts is not None else [])]:
        try:
            immutable_checks[name] = operation() == before
            if not immutable_checks[name]:
                immutable_errors.append(name + ' changed during execution')
        except (OSError, ValueError) as exc:
            immutable_checks[name] = False
            immutable_errors.append(name + ': ' + str(exc))
    ledger = coverage_ledger(specs, suites, output)
    failed = bool(immutable_errors or any(s['status'] in {'FAILED', 'ERROR'} for s in suites)
                  or any(c['status'] == 'FAIL' for c in ledger))
    incomplete = any(s['status'] == 'NOT_RUN' for s in suites) or any(c['status'] in {'NOT_RUN', 'UNSUPPORTED', 'PARTIAL'} for c in ledger)
    exit_code = 1 if failed else 2 if incomplete else 0
    report = {'schema': SCHEMA, 'external_audit': False,
              'status': 'FAILED' if failed else 'INCOMPLETE' if incomplete else 'COMPLETE',
              'exit_code': exit_code, 'source_root': str(source), 'source_identity': source_before,
              'original_benchmark_identity': original_before,
              'runtime': {'python': sys.version, 'node_executable': node},
              'receipt_input': {'status': 'PROVIDED' if receipts is not None else 'NOT_RUN',
                  'caller_supplied_freeze_sha256': freeze_sha256,
                  'historical_default_freeze_sha256': adapter().HISTORICAL_RECEIPT_SHA256,
                  'control_expected_status': RECEIPT_CONTROL_STATUS,
                  'control_expectation_rationale': RECEIPT_CONTROL_RATIONALE},
              'engine_execution': 'NOT_RUN', 'scope': 'Offline supplied-evidence challenge checks; no broker authentication, '
              'unknown-attempt completeness, actual AuditZK execution, fresh engine execution, or external participant audit.',
              'suites': suites, 'cases': ledger,
              'coverage_by_specification': {name: dict(Counter(c['status'] for c in ledger if c['specification'] == name)) for name in specs},
              'immutable_inputs_unchanged': immutable_checks, 'immutable_input_errors': immutable_errors,
              'scoring_note': 'No blended pass percentage. NOT_RUN, UNSUPPORTED, PARTIAL, false acceptance, false rejection, '
              'and execution failures remain separate. A completed harness is not evidence of unsupported capabilities.'}
    write_json(output / 'report.json', report)
    print(json.dumps({'status': report['status'], 'exit_code': exit_code, 'report': str(output / 'report.json'),
                      'coverage_by_specification': report['coverage_by_specification']}, indent=2))
    return exit_code


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) == 3 and argv[0] == '--_worker':
        return worker(argv[1], adapter().strict_json(argv[2]))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='Explicit extracted accepted-source root containing app/')
    parser.add_argument('--output', type=Path, required=True, help='New directory for reports and logs')
    parser.add_argument('--receipts', type=Path, help='Explicit fresh receipts containing receipt-freeze.json')
    parser.add_argument('--receipt-freeze-sha256', help='Independently retained exact lowercase SHA-256; required with --receipts')
    args = parser.parse_args(argv)
    try:
        return run(args.source, args.output, receipts=args.receipts, freeze_sha256=args.receipt_freeze_sha256)
    except (OSError, ValueError, ImportError, KeyError) as exc:
        print('Challenge runner preflight/execution error: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
