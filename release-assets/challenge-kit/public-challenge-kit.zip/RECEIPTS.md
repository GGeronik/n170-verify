# Explicit receipt input contract

The kit accepts an explicitly supplied directory, never a private implicit path.
No actual engine execution is inferred from copied metadata, a valid digest,
synthetic counterclaim or parser result. The archive contains 90 unchanged raw
files from fresh local synthetic executions, plus their `receipt-freeze.json`,
under `receipts/`. They are used only when the paired arguments below are given.

The retained freeze SHA-256 is
`f510104c165d61705472197ad5b21a765d180071410b4392a1ca430b81707ec7`.
Raw payloads total 2,433,409 bytes. The prior plan is preserved unchanged as
`provenance/acquisition-plan.json`, SHA-256
`5cae2cf9ff7b4f81dfd316b0a5326a9d8429f720eb8da6b3445a1d9afa006da6`.
`INPUTS.json` identifies every copied file and its durable source handoff pin.
The handoff's remaining reports and files are not implicitly distributed.

Required paired CLI arguments are `--receipts DIRECTORY` and
`--receipt-freeze-sha256 HEX`. The 64-character SHA-256 must come from the
recipient's independent record of the exact `receipt-freeze.json` bytes. A hash
calculated from the received file is useful for comparison but cannot supply its
own external identity authority.

The directory contains `receipt-freeze.json` and three receipt subdirectories:
`rerun-a/`, `rerun-b/` and `mixed-controls/`. Its freeze object declares an exact
`files` list of `{path,size,sha256}` and `receipt_manifest_pins` mapping those
three names to their manifest SHA-256 values. Each subdirectory contains its
original `manifest.json` and every declared raw artifact, including captured
input, worker output and logs. Keep original bytes and all selected failures.
The bundled plan and raw files retain engine/image identity, invocation, observed
exit status, original inputs and failures. The plan describes eight executions
across four synthetic controls; repeated controls do not create additional
independent accuracy cases. Acquisition itself is not rerun by this kit's module
workflow, and no upstream engine implementation or image is shipped.

`rerun-a` and `rerun-b` are independently executed repeats of the same original
synthetic `N170Clean` and `N170Biased` selected scope and settings. The prior
expected outcomes are clean/no findings and biased/findings, with combined
`FINDINGS_REPORTED`. `mixed-controls` additionally preserves the declared never
triggered (`INSUFFICIENT`) and failed (`FAILED`) controls, producing
`NOT_ASSESSABLE`. These are frozen input expectations, not values inferred from
candidate output. A mismatch remains a challenge failure. The five separately
frozen `Challenge*` engine cases are not executed merely by checking these
`N170*` receipts.

The biased control detected the `future_close` indicator (ten checked signals,
zero biased entry signals and zero biased exit signals). This demonstrates the
handling of a declared future-dependent indicator, not biased trading decisions,
general detection accuracy, real-market performance or profitability. The local
acquisition and a separate AI agent's review support the stated engineering
provenance; they are not an external audit or authenticated execution attestation.

The adapter validates the caller's freeze pin and exact retained file inventory,
then constructs envelopes independently and calls the unchanged historical
mutation/scoring logic. It explicitly binds the original module's receipt pin
for the duration of that call and restores it afterward. The report discloses
the historical default, the caller-supplied pin and the actual pin used. This
changes neither original expected-case commitments nor source bytes.
The original mutation harness needs writable disposable files. The adapter
captures bounded, verified receipt bytes into a temporary writable directory,
checks that copy, and applies mutations there. It never changes original receipt
bytes or permissions. A first development run that failed on read-only copied
directories was retained in the separate validation evidence; the corrected
workflow stages verified bytes and reruns the checks.

Deliberately mutated byte/link cases and internally rebuilt semantic variants
are labelled challenge mutations or unsigned synthetic counterclaims. They are
not new engine executions. The original `rerun-a`, `rerun-b` and mixed receipts
remain unchanged; source identities and supplied file commitments are rechecked.
No wholly unknown omitted attempt, provider identity, independent timestamp or
trusted hardware assertion can be established from these unsigned files alone.

A wrong pin, malformed freeze, extra/missing file, symlink, unsafe path or changed
byte is a failed input check, not `NOT_RUN` and not a successful adversarial
rejection by the product. `NOT_RUN` is reserved for omitted prerequisites or
separate unexecuted dimensions. Browser operations absent from the published
module contract remain explicitly unsupported rather than silently passing.
