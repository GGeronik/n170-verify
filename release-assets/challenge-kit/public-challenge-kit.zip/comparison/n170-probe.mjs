// Original comparison adapter. Imports only the explicitly supplied, hash-pinned
// N170 calculator; it never obtains or invokes an upstream component.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const identities = JSON.parse(readFileSync(new URL('./identities.json', import.meta.url)));
const fixtureBytes = readFileSync(new URL('./fixtures.json', import.meta.url));
assert.equal(sha256(fixtureBytes), identities.kit.fixtures_sha256, 'fixture identity mismatch');
const fixtures = JSON.parse(fixtureBytes);
const [calculatorPath, ...extra] = process.argv.slice(2);
if (!calculatorPath || extra.length) {
  process.stderr.write('Usage: node n170-probe.mjs <separately-provided-n170-calculator.js>\n');
  process.exit(2);
}
const calculatorSha256 = sha256(readFileSync(calculatorPath));
assert.equal(calculatorSha256, identities.n170.calculator_sha256, 'calculator identity mismatch; this probe pins the standalone app source');
const sourceModulesSha256 = {};
for (const [moduleName, expectedSha256] of Object.entries(identities.n170.source_modules_sha256)) {
  const modulePath = resolve(dirname(calculatorPath), moduleName);
  const actualSha256 = sha256(readFileSync(modulePath));
  assert.equal(actualSha256, expectedSha256, `${moduleName}: required module identity mismatch`);
  sourceModulesSha256[moduleName] = actualSha256;
}
const { calculateEvidence, buildStampObservationEvidence, CALCULATION_VERSION } = await import(pathToFileURL(resolve(calculatorPath)).href);
assert.equal(typeof calculateEvidence, 'function');
assert.equal(typeof buildStampObservationEvidence, 'function');
assert.equal(CALCULATION_VERSION, identities.n170.calculation_version);
assert.equal(CALCULATION_VERSION, fixtures.n170_calculation_version);

const results = fixtures.cases.map((fixture) => {
  const csv = `date,nav,external_flow\n${fixtures.start_date},${fixture.opening},0\n${fixtures.end_date},${fixture.closing},${fixture.deposit}`;
  let result;
  try {
    const evidence = calculateEvidence(csv, fixtures.periods_per_year);
    const observation = buildStampObservationEvidence(csv, fixtures.periods_per_year);
    result = {
      name: fixture.name,
      method_status: evidence.quality_status,
      native_outcome: 'evidence_object',
      total_return: evidence.metrics.total_return_twr,
      max_drawdown: evidence.metrics.max_drawdown,
      native_metrics_e8: observation.metrics,
      annualization_status: evidence.annualization.status,
      annualized_volatility: evidence.metrics.annualized_volatility,
      cash_flow_timing: evidence.methodology.cash_flow_timing,
      provider_authenticated: evidence.provider_authenticated,
      provenance_assessment: 'not_tested',
    };
    assert.equal(result.cash_flow_timing, fixtures.n170_cash_flow_timing);
    assert.equal(result.provider_authenticated, false);
    assert.equal(evidence.calculation_version, identities.n170.calculation_version);
    assert.equal(observation.calculation_version, identities.n170.calculation_version);
    assert.equal(result.annualization_status, fixture.expected_n170.annualization_status);
    assert.equal(result.annualized_volatility, null);
    assert.deepEqual(result.native_metrics_e8, fixture.expected_n170.native_metrics_e8);
  } catch (error) {
    // Only this known unsupported-method condition is classified as unresolved.
    // Other exceptions remain failures; they are never turned into a zero return.
    if (error.message !== 'Row 2: cash-flow-adjusted wealth is zero or negative. Total loss and recapitalization are unsupported; keep this observation and obtain a separate accounting review.') throw error;
    result = {
      name: fixture.name,
      method_status: 'unresolved',
      native_outcome: 'exception',
      total_return: null,
      max_drawdown: null,
      error: error.message,
      provenance_assessment: 'not_tested',
    };
  }
  assert.equal(result.method_status, fixture.expected_n170.method_status, fixture.name);
  for (const metric of ['total_return', 'max_drawdown']) {
    const expected = fixture.expected_n170[metric];
    if (expected === null) assert.equal(result[metric], null, `${fixture.name}: ${metric}`);
    else assert.equal(result[metric], expected, `${fixture.name}: ${metric} (declared e8 rounding)`);
  }
  return result;
});

process.stdout.write(`${JSON.stringify({
  schema: 'n170.synthetic.calculation-comparison.observation.v1',
  input_kind: fixtures.input_kind,
  runtime: { node: process.version, platform: process.platform, arch: process.arch },
  calculator_sha256: calculatorSha256,
  source_modules_sha256: sourceModulesSha256,
  calculation_version: CALCULATION_VERSION,
  fixtures_sha256: sha256(fixtureBytes),
  status_interpretation: 'unresolved is this adapter\'s label for the recorded native exception; partial_metrics is the native quality_status when annualized volatility is withheld',
  results,
}, null, 2)}\n`);
