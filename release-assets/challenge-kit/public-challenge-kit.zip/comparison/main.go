// Original research harness: calls exported APIs in an unchanged local source
// checkout. It implements no upstream calculation or signing functions.
package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"time"

	"github.com/trackrecord/enclave/internal/repository"
	"github.com/trackrecord/enclave/internal/service"
)

type observation struct {
	Name string `json:"name"`
	Opening float64 `json:"opening"`
	Deposit float64 `json:"deposit"`
	Closing float64 `json:"closing"`
	PriorReconstructed bool `json:"prior_reconstructed"`
	Metrics *service.PerformanceMetrics `json:"upstream_metrics"`
}

func main() {
	cases := []struct {
		name string
		opening, deposit, closing, expected float64
		rebuilt bool
	}{
		{"funded_loss_reset", 100, 100, 50, 0, false},
		{"funded_loss_near_boundary_reset", 100, 100, 100, 0, false},
		{"funded_loss_above_boundary", 100, 100, 101, -0.495, false},
		{"ordinary_loss_control", 100, 0, 50, -0.5, false},
		{"reconstructed_opening_100_live_close_110", 100, 0, 110, 0.1, true},
		{"reconstructed_opening_90_live_close_110", 90, 0, 110, 20.0/90.0, true},
	}
	start := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	enc := json.NewEncoder(os.Stdout)
	for _, c := range cases {
		snapshots := []*repository.Snapshot{
			{Exchange: "research_fixture", Label: "offline", Timestamp: start, TotalEquity: c.opening, IsHistorical: c.rebuilt, FromExternalRebuilder: c.rebuilt},
			{Exchange: "research_fixture", Label: "offline", Timestamp: start.AddDate(0, 0, 1), TotalEquity: c.closing, Deposits: c.deposit},
		}
		m, err := service.NewMetricsService(nil).CalculateFromSnapshots(snapshots, 0)
		if err != nil { panic(fmt.Sprintf("%s: %v", c.name, err)) }
		if err := enc.Encode(observation{c.name, c.opening, c.deposit, c.closing, c.rebuilt, m}); err != nil { panic(err) }
		if math.Abs(m.TotalReturn-c.expected)>1e-12 { panic(fmt.Sprintf("unexpected upstream result for %s: got %.17g expected %.17g", c.name, m.TotalReturn, c.expected)) }
	}
}
