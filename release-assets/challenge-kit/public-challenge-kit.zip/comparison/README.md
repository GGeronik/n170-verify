# Original six-case calculation probe and portable Go recipe

This subset preserves the original `fixtures.json`, `identities.json`,
`n170-probe.mjs`, `main.go`, Apache-2.0 license and notice byte-for-byte from the
identified input kit. Its input manifest SHA-256 is
`5fd57cbd15e9f8cf1324ae7d559464a276ce608cad3e19dc0709e8390261adf9`.
`INPUTS.json` in the kit root binds this exact selection. Historical observed
outputs and their comparative table are deliberately omitted. No aggregate
scoreboard, upstream winner or new upstream execution is claimed.

The preserved original NOTICE references a historical observed-output file that
is not included here. `identities.json` also preserves historical execution
metadata and hashes as input provenance. They are not evidence that this new
portable recipient workflow ran. New observations must be captured separately.

## N170 calculation 2.0.0

From the kit root, after `prepare_source.py` extracted the pinned accepted source:

```sh
node comparison/n170-probe.mjs ../accepted-source/app/src/calculator.js
```

The default challenge wrapper also runs this probe and retains its stdout in a
fresh result directory. Node standard libraries suffice; there is no package
installation. The original probe checks **both** required module commitments
before import:

| Module | SHA-256 |
| --- | --- |
| calculator.js | 8a5aea0a5cb80d352540f64fd5ebbb4aaf1532f198ec78172d8077f4b64f3699 |
| calculatorLegacy.js | 80c6ee5c54f006f9bc1006e897d21ae30a8a744bad5319e3bb3ff15ee209357c |

The authoritative module hashes are in `identities.json`; the probe enforces
them. Its current API is calculation 2.0.0, with integer units of 10^-8 and the
native `partial_metrics` status when a one-interval sample withholds annualized
volatility. Known unsupported total-loss/recapitalization inputs remain native
exceptions represented as `unresolved`, with null returns; the probe never
substitutes zero or invents a -75% return. Other exceptions fail the probe.

Six original two-day inputs include loss, deposit and reconstructed-opening
sensitivity controls. Cash-flow conventions, rounding, coverage and support
status must accompany any observations. Supplied values do not prove provenance,
identity, broker authenticity, complete history or return correctness under a
different cash-flow timing assumption.

## Portable Go recipe — NOT_RUN for this kit

This recipe has **not been executed for this portable kit**. The default runner
records it as `NOT_RUN`. It requires a separately supplied restricted upstream
checkout, Go toolchain and populated dependency cache. This distribution contains
none of those components, no upstream `go.mod`/`go.sum`, source, binary or runtime,
and no fetch script. Obtain and review those components separately under their
applicable terms. This kit grants no upstream reuse or distribution rights.

The original harness targets commit
`e3924317ae3c82ee899f706d2399a18162ec11b5` and Go 1.26.6. Source-file and historical
runtime archive pins are recorded in `identities.json`; the recorded runtime
archive digest applies only to darwin/arm64. Other platforms need their own
independently retained runtime identities and executed evidence.

From this `comparison` directory, explicitly set the three supplied local paths.
This recipe is offline and fails when its required dependencies are unavailable:

```sh
set -eu
comparison_kit="$PWD"
comparison_upstream="/path/to/separately-obtained/tee-aggregator"
comparison_go="/path/to/go1.26.6/bin/go"
comparison_modules="/path/to/prepared/go-module-cache"
comparison_work="$(mktemp -d)"

test "$(git -C "$comparison_upstream" rev-parse HEAD)" = e3924317ae3c82ee899f706d2399a18162ec11b5
test -z "$(git -C "$comparison_upstream" status --porcelain --untracked-files=all)"
# Independently verify the supplied source/runtime against identities.json.
comparison_env() {
  env -i PATH=/usr/bin:/bin:/usr/sbin:/sbin TMPDIR="$comparison_work" \
    GOENV=off GOTOOLCHAIN=local CGO_ENABLED=0 GOPROXY=off GOSUMDB=off \
    GOPATH="$comparison_work/gopath" GOCACHE="$comparison_work/build-cache" \
    GOMODCACHE="$comparison_modules" "$@"
}
comparison_runtime="$(comparison_env "$comparison_go" version)"
case "$comparison_runtime" in
  'go version go1.26.6 '*) ;;
  *) printf '%s\n' 'Supply Go 1.26.6 explicitly.' >&2; exit 1 ;;
esac
mkdir -p "$comparison_work/harness"
cp "$comparison_kit/main.go" "$comparison_work/harness/main.go"
cd "$comparison_work/harness"
comparison_env "$comparison_go" mod init github.com/trackrecord/enclave/researchcheck
comparison_env "$comparison_go" mod edit -go=1.26.6 \
  -require=github.com/trackrecord/enclave@v0.0.0 \
  "-replace=github.com/trackrecord/enclave=$comparison_upstream"
comparison_env "$comparison_go" mod tidy
comparison_env "$comparison_go" mod verify
comparison_env "$comparison_go" build -mod=readonly -trimpath -buildvcs=false \
  -o "$comparison_work/calculation-harness" .
env -i PATH=/usr/bin:/bin:/usr/sbin:/sbin "$comparison_work/calculation-harness" \
  > "$comparison_work/my-auditzk-observation.jsonl"
```

The module namespace permits the original harness to call exported Go internal
APIs; it does not claim upstream authorship. The harness asserts its frozen
observations, not universal financial correctness. A successful new Go run must
retain its actual source/runtime identities, commands, exit status, stdout,
errors, limitations and native method conventions. Never replace it with a mock
or the historical metadata and call that actual execution.
