#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Verify the pinned accepted source ZIP, then publish a new local extraction."""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ACCEPTED_SOURCE_SHA256 = 'efa705edb9782568aba7561cea448f4e824f1a58cb745930471fb6cee39fe3e5'
DEFAULT_ARCHIVE = Path(__file__).resolve().parent / 'payload' / 'accepted-source.zip'
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_TOTAL_BYTES = 128 * 1024 * 1024


def _object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Duplicate manifest field')
        value[key] = item
    return value


def _validated_bytes(raw: bytes, expected_sha256: str) -> dict[str, bytes]:
    if len(raw) > MAX_ARCHIVE_BYTES or hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError('Accepted source archive SHA-256 mismatch or size limit exceeded')
    files = {}
    folded = set()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if not 1 <= len(entries) <= 4096:
            raise ValueError('Unexpected accepted source archive member count')
        total = 0
        for entry in entries:
            name = entry.filename
            parts = name.split('/')
            if (not name or len(name) > 240 or '\\' in name or ':' in name or '\x00' in name
                    or PurePosixPath(name).is_absolute() or any(p in {'', '.', '..'} for p in parts)
                    or name in files or name.casefold() in folded or entry.is_dir()):
                raise ValueError('Unsafe or duplicate accepted source path')
            if (entry.flag_bits & 1 or entry.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}
                    or stat.S_IFMT(entry.external_attr >> 16) not in {0, stat.S_IFREG}
                    or entry.file_size > MAX_ARCHIVE_BYTES
                    or entry.file_size > max(1024 * 1024, entry.compress_size * 200)):
                raise ValueError('Unsupported accepted source member')
            total += entry.file_size
            if total > MAX_TOTAL_BYTES:
                raise ValueError('Accepted source uncompressed size limit exceeded')
            data = archive.read(entry)
            if len(data) != entry.file_size:
                raise ValueError('Accepted source member size mismatch')
            files[name] = data
            folded.add(name.casefold())
    if 'MANIFEST.json' not in files:
        raise ValueError('Accepted source manifest missing')
    manifest = json.loads(files['MANIFEST.json'].decode('utf-8', errors='strict'), object_pairs_hook=_object)
    if not isinstance(manifest, dict) or manifest.get('schema') != 'n170.release.archive.v1':
        raise ValueError('Unsupported accepted source manifest schema')
    entries = manifest.get('files')
    if not isinstance(entries, dict) or set(files) != set(entries) | {'MANIFEST.json'} or 'MANIFEST.json' in entries:
        raise ValueError('Accepted source inventory membership mismatch')
    for name, item in entries.items():
        if not isinstance(item, dict) or set(item) != {'bytes', 'sha256'} or type(item['bytes']) is not int:
            raise ValueError('Invalid accepted source inventory entry')
        if len(files[name]) != item['bytes'] or hashlib.sha256(files[name]).hexdigest() != item['sha256']:
            raise ValueError('Accepted source member commitment mismatch')
    if 'app/src/reconciliation.js' not in files or 'app/verify_toolkit/run_review.py' not in files:
        raise ValueError('Accepted app/toolkit source layout missing')
    return files


def read_verified_source(archive_path: str | Path | None = None) -> dict[str, bytes]:
    """Capture once and validate the exact, externally pinned accepted artifact.

    This does not import or execute the implementation under test. The returned
    bytes include its unchanged MANIFEST and can be compared to an extraction.
    """
    path = Path(archive_path) if archive_path is not None else DEFAULT_ARCHIVE
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
    descriptor = os.open(path, flags)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_ARCHIVE_BYTES:
            raise ValueError('Accepted source archive must be a bounded regular file')
        with os.fdopen(descriptor, 'rb', closefd=False) as handle:
            raw = handle.read(MAX_ARCHIVE_BYTES + 1)
    finally:
        os.close(descriptor)
    return _validated_bytes(raw, ACCEPTED_SOURCE_SHA256)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, help='Optional copy of the same exactly pinned accepted ZIP')
    parser.add_argument('--output', type=Path, required=True, help='New extraction directory; never replaces an existing path')
    args = parser.parse_args(argv)
    try:
        files = read_verified_source(args.archive)
        from verify_archive import publish_verified_files
        publish_verified_files(files, args.output)
    except (OSError, ValueError, zipfile.BadZipFile, RuntimeError) as error:
        print(json.dumps({'status': 'FAILED', 'reason': str(error)}), file=sys.stderr)
        return 1
    print(json.dumps({'status': 'EXTRACTED', 'archive_sha256': ACCEPTED_SOURCE_SHA256,
                      'files': len(files), 'destination': str(args.output),
                      'executed_candidate_code': False, 'publisher_authenticated': False}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
