# Original N170 synthetic engineering fixture. SPDX-License-Identifier: Apache-2.0
# This is not a financial strategy or real-market performance evidence.
from freqtrade.strategy import IStrategy


class N170Failure(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"
    startup_candle_count = 3
    minimal_roi = {"0": 100.0}
    stoploss = -0.99
    can_short = False
    def populate_indicators(self, dataframe, metadata):
        raise RuntimeError("Original deliberate failure control")
        return dataframe

    def populate_entry_trend(self, dataframe, metadata):
        dataframe.loc[(dataframe["date"].dt.minute % 30 == 0) & (dataframe["volume"] > 0), "enter_long"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe, metadata):
        dataframe.loc[dataframe["date"].dt.minute % 30 == 10, "exit_long"] = 1
        return dataframe
