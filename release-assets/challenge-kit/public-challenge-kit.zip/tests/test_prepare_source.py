# SPDX-License-Identifier: Apache-2.0
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('prepare_source', ROOT / 'prepare_source.py')
prepare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prepare)


def archive_of(files):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w') as archive:
        for name, data in files:
            archive.writestr(name, data)
    return stream.getvalue()


class PrepareSourceTests(unittest.TestCase):
    def test_accepted_original_archive_binds_every_member_and_required_layout(self):
        files = prepare.read_verified_source()
        self.assertEqual(len(files), 161)
        self.assertIn('app/src/calculator.js', files)
        self.assertIn('app/verify_toolkit/run_review.py', files)
        self.assertEqual(hashlib.sha256(files['app/src/calculator.js']).hexdigest(), '8a5aea0a5cb80d352540f64fd5ebbb4aaf1532f198ec78172d8077f4b64f3699')

    def test_substituted_archive_rejects_before_extracting_or_running_code(self):
        with tempfile.TemporaryDirectory() as temporary:
            file = Path(temporary) / 'substitute.zip'
            file.write_bytes(archive_of([('evil.py', b'raise RuntimeError("must not run")')]))
            with self.assertRaisesRegex(ValueError, 'SHA-256'):
                prepare.read_verified_source(file)

    def test_inventory_missing_extra_or_changed_member_rejects_even_with_retained_outer_digest(self):
        member = b'original synthetic bytes'
        manifest = {'schema': 'n170.release.archive.v1', 'files': {'file.txt': {'bytes': len(member), 'sha256': hashlib.sha256(member).hexdigest()}}}
        for entries in [[('MANIFEST.json', json.dumps(manifest).encode())], [('MANIFEST.json', json.dumps(manifest).encode()), ('file.txt', b'changed')], [('MANIFEST.json', json.dumps(manifest).encode()), ('file.txt', member), ('extra.txt', b'extra')]]:
            raw = archive_of(entries)
            with self.assertRaisesRegex(ValueError, 'membership|commitment'):
                prepare._validated_bytes(raw, hashlib.sha256(raw).hexdigest())

    def test_duplicate_manifest_fields_and_path_traversal_reject(self):
        for entries in [[('MANIFEST.json', b'{"schema":"n170.release.archive.v1","files":{},"files":{}}')], [('../outside.py', b'unexecuted')]]:
            raw = archive_of(entries)
            with self.assertRaisesRegex(ValueError, 'Duplicate|Unsafe'):
                prepare._validated_bytes(raw, hashlib.sha256(raw).hexdigest())

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'FIFO unavailable on this platform')
    def test_fifo_archive_rejects_without_waiting_for_a_writer(self):
        with tempfile.TemporaryDirectory() as temporary:
            file = Path(temporary) / 'pipe.zip'
            os.mkfifo(file)
            with self.assertRaisesRegex(ValueError, 'regular file'):
                prepare.read_verified_source(file)

    def test_existing_destination_is_not_replaced(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / 'existing'
            output.mkdir()
            sentinel = output / 'owner.txt'
            sentinel.write_text('preserve')
            self.assertEqual(prepare.main(['--output', str(output)]), 1)
            self.assertEqual(sentinel.read_text(), 'preserve')
            self.assertEqual(sorted(p.name for p in output.iterdir()), ['owner.txt'])


if __name__ == '__main__':
    unittest.main()
