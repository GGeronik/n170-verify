"""Portable runner/adapter adversarial checks; synthetic receipts are not executions."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
KIT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT))
import run_challenges as runner
from adapters import wave2_run_review as receipt_adapter


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def receipt_fixture(root):
    root.mkdir()
    entries, pins = [], {}
    for name in sorted(receipt_adapter.RECEIPT_NAMES):
        folder = root / name
        folder.mkdir()
        # Only transport input validation is exercised by this fixture.
        raw = encoded({'synthetic_test_only': True, 'name': name})
        (folder / 'manifest.json').write_bytes(raw)
        pins[name] = runner.sha(raw)
        entries.append({'path': name + '/manifest.json', 'size': len(raw), 'sha256': runner.sha(raw)})
    raw = encoded({'files': entries, 'receipt_manifest_pins': pins})
    (root / 'receipt-freeze.json').write_bytes(raw)
    return runner.sha(raw)


def repin(root, mutate):
    path = root / 'receipt-freeze.json'
    value = json.loads(path.read_bytes())
    mutate(value)
    raw = encoded(value)
    path.write_bytes(raw)
    return runner.sha(raw)


class ExplicitInputsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.source = self.root / 'source'
        self.source.mkdir()
        self.output = self.root / 'results'

    def tearDown(self):
        self.temp.cleanup()

    def test_receipts_and_pin_are_required_together(self):
        for receipts, pin in [(self.root / 'receipts', None), (None, 'a' * 64)]:
            with self.subTest(receipts=receipts, pin=pin), self.assertRaisesRegex(ValueError, 'together'):
                runner.validate_options(self.source, self.output, receipts, pin)
        self.assertFalse(self.output.exists())

    def test_pin_syntax_has_no_case_or_whitespace_normalization(self):
        for pin in ['a' * 63, 'A' * 64, 'a' * 64 + '\n', 7, 'g' * 64]:
            with self.subTest(pin=pin), self.assertRaises(ValueError):
                receipt_adapter.require_pin(pin)

    def test_existing_output_is_never_overwritten(self):
        self.output.mkdir()
        marker = self.output / 'keep'
        marker.write_text('unchanged')
        with self.assertRaisesRegex(ValueError, 'new directory'):
            runner.validate_options(self.source, self.output)
        self.assertEqual(marker.read_text(), 'unchanged')

    def test_output_cannot_pollute_source_or_receipts(self):
        receipts = self.root / 'receipts'
        pin = receipt_fixture(receipts)
        for output in [self.source / 'results', receipts / 'results']:
            with self.subTest(output=output), self.assertRaisesRegex(ValueError, 'separate'):
                runner.validate_options(self.source, output, receipts, pin)

    def test_dotdot_output_cannot_bypass_immutable_tree_separation(self):
        receipts = self.root / 'receipts'
        pin = receipt_fixture(receipts)
        sibling = self.root / 'sibling'
        sibling.mkdir()
        for output in [sibling / '../source/reports', sibling / '../receipts/reports',
                       KIT / 'tests/../original/new-output', KIT / 'tests/../new-output']:
            with self.subTest(output=output), self.assertRaisesRegex(ValueError, 'separate'):
                runner.validate_options(self.source, output, receipts, pin)
            self.assertFalse(output.exists())

    def test_whole_kit_is_excluded_from_report_destinations(self):
        for output in [KIT / 'new-output', KIT / 'tests/new-output', KIT / 'adapters/new-output']:
            with self.subTest(output=output), self.assertRaisesRegex(ValueError, 'separate'):
                runner.validate_options(self.source, output)

    def test_symlink_source_is_rejected(self):
        link = self.root / 'source-link'
        link.symlink_to(self.source, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            runner.validate_options(link, self.output)

    def test_bad_source_stops_before_output_or_candidate_execution(self):
        with patch.object(runner, 'run_command') as command:
            with self.assertRaises((ValueError, RuntimeError)):
                runner.run(self.source, self.output)
            command.assert_not_called()
        self.assertFalse(self.output.exists())


class ReceiptPinTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve() / 'receipts'
        self.pin = receipt_fixture(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_exact_caller_pin_and_complete_inventory(self):
        checked = receipt_adapter.validate_receipts(self.root, self.pin)
        self.assertEqual(checked['freeze_sha256'], self.pin)
        self.assertEqual(len(checked['files']), 3)

    def test_wrong_pin_rejected_before_json_parse(self):
        (self.root / 'receipt-freeze.json').write_bytes(b'not JSON at all')
        with patch.object(receipt_adapter, 'strict_json', side_effect=AssertionError('parsed too early')):
            with self.assertRaisesRegex(ValueError, 'caller-supplied'):
                receipt_adapter.validate_receipts(self.root, self.pin)

    def test_computed_hash_is_not_an_implicit_trust_pin(self):
        with self.assertRaisesRegex(ValueError, '64 lowercase'):
            receipt_adapter.validate_receipts(self.root, None)

    def test_changed_receipt_bytes_rejected(self):
        (self.root / 'rerun-a/manifest.json').write_text('changed')
        with self.assertRaisesRegex(ValueError, 'identity mismatch'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    def test_missing_receipt_bytes_rejected(self):
        (self.root / 'rerun-b/manifest.json').unlink()
        with self.assertRaisesRegex(ValueError, 'Missing'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    def test_unlisted_receipt_bytes_rejected(self):
        (self.root / 'extra.txt').write_text('not in retained inventory')
        with self.assertRaisesRegex(ValueError, 'Unlisted'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    def test_symlink_artifact_rejected(self):
        original = self.root / 'rerun-a/manifest.json'
        content = original.read_bytes()
        original.unlink()
        outside = self.root.parent / 'outside'
        outside.write_bytes(content)
        original.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, '[Ss]ymlink'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    def test_inflated_artifact_rejected_before_content_allocation(self):
        path = self.root / 'rerun-a/manifest.json'
        with path.open('r+b') as file:
            file.truncate(1024 * 1024 * 1024)
        with self.assertRaisesRegex(ValueError, 'type/size exceeds'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'Named pipes unavailable')
    def test_fifo_receipt_node_is_rejected_without_opening_it(self):
        path = self.root / 'rerun-a/manifest.json'
        path.unlink()
        os.mkfifo(path)
        with self.assertRaisesRegex(ValueError, 'special files'):
            receipt_adapter.validate_receipts(self.root, self.pin)

    def test_freeze_descriptor_bounds_rejected_before_receipt_reads(self):
        pin = repin(self.root, lambda doc: doc['files'][0].update(size=receipt_adapter.MAX_RECEIPT_FILE_BYTES + 1))
        with self.assertRaisesRegex(ValueError, 'byte length exceeds'):
            receipt_adapter.validate_receipts(self.root, pin)

    def test_freeze_file_count_bound(self):
        pin = repin(self.root, lambda doc: doc.update(files=doc['files'] * (receipt_adapter.MAX_RECEIPT_FILES + 1)))
        with self.assertRaisesRegex(ValueError, 'file count'):
            receipt_adapter.validate_receipts(self.root, pin)

    def test_duplicate_paths_rejected_even_with_matching_pin(self):
        pin = repin(self.root, lambda doc: doc['files'].append(doc['files'][0]))
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            receipt_adapter.validate_receipts(self.root, pin)

    def test_unsafe_inventory_paths_rejected(self):
        for unsafe in ['../outside', '/absolute', 'rerun-a/../outside', 'rerun-a\\outside', 'C:/outside']:
            pin = repin(self.root, lambda doc: doc['files'][0].update(path=unsafe))
            with self.subTest(unsafe=unsafe), self.assertRaises(ValueError):
                receipt_adapter.validate_receipts(self.root, pin)

    def test_duplicate_json_fields_rejected(self):
        raw = b'{"files":[],"files":[],"receipt_manifest_pins":{}}'
        (self.root / 'receipt-freeze.json').write_bytes(raw)
        with self.assertRaisesRegex(ValueError, 'Duplicate JSON'):
            receipt_adapter.validate_receipts(self.root, runner.sha(raw))

    def test_pin_adapter_restores_historical_default_on_error(self):
        module = types.SimpleNamespace(RECEIPT_SHA=receipt_adapter.HISTORICAL_RECEIPT_SHA256)
        with self.assertRaisesRegex(RuntimeError, 'deliberate'):
            with receipt_adapter.explicit_receipt_pin(module, self.pin):
                self.assertEqual(module.RECEIPT_SHA, self.pin)
                raise RuntimeError('deliberate')
        self.assertEqual(module.RECEIPT_SHA, receipt_adapter.HISTORICAL_RECEIPT_SHA256)

    def test_public_adapter_reports_actual_pin_and_restores_original(self):
        module = types.SimpleNamespace(RECEIPT_SHA=receipt_adapter.HISTORICAL_RECEIPT_SHA256)
        observed = []
        def original_run(toolkit, app, receipts):
            observed.append((toolkit, app, receipts, module.RECEIPT_SHA))
            self.assertNotEqual(receipts, self.root)
            self.assertEqual(receipt_adapter.validate_receipts(receipts, self.pin),
                             receipt_adapter.validate_receipts(self.root, self.pin))
            return {'receipt_freeze_sha256': module.RECEIPT_SHA, 'cases': [], 'summary': {}}
        module.run = original_run
        with patch.object(receipt_adapter.importlib, 'import_module', return_value=module):
            report = receipt_adapter.run_with_receipts('explicit-toolkit', 'explicit-app', self.root, freeze_sha256=self.pin)
        self.assertEqual(len(observed), 1)
        self.assertEqual(observed[0][:2], ('explicit-toolkit', 'explicit-app'))
        self.assertEqual(observed[0][3], self.pin)
        self.assertFalse(observed[0][2].exists())
        self.assertEqual(report['receipt_freeze_sha256'], self.pin)
        self.assertEqual(report['public_kit_adapter']['caller_supplied_receipt_freeze_sha256'], self.pin)
        self.assertEqual(report['public_kit_adapter']['historical_default_receipt_freeze_sha256'], receipt_adapter.HISTORICAL_RECEIPT_SHA256)
        self.assertFalse(report['public_kit_adapter']['engine_execution_performed'])
        self.assertEqual(module.RECEIPT_SHA, receipt_adapter.HISTORICAL_RECEIPT_SHA256)

    def test_readonly_receipts_stage_writable_copies_without_changing_input_modes(self):
        for path in [self.root, *self.root.rglob('*')]:
            path.chmod(0o500 if path.is_dir() else 0o400)
        modes = {path: path.stat().st_mode for path in [self.root, *self.root.rglob('*')]}
        module = types.SimpleNamespace(RECEIPT_SHA=receipt_adapter.HISTORICAL_RECEIPT_SHA256)
        def original_run(_toolkit, _app, receipts):
            self.assertNotEqual(receipts, self.root)
            for path in [receipts, *receipts.rglob('*')]:
                self.assertTrue(path.stat().st_mode & 0o200)
            return {'receipt_freeze_sha256': module.RECEIPT_SHA, 'cases': [], 'summary': {}}
        module.run = original_run
        with patch.object(receipt_adapter.importlib, 'import_module', return_value=module):
            receipt_adapter.run_with_receipts('x', 'y', self.root, freeze_sha256=self.pin)
        self.assertEqual({path: path.stat().st_mode for path in modes}, modes)
        self.assertEqual(receipt_adapter.validate_receipts(self.root, self.pin)['freeze_sha256'], self.pin)

    def test_bad_receipt_pin_never_loads_historical_module(self):
        with patch.object(receipt_adapter.importlib, 'import_module') as load:
            with self.assertRaisesRegex(ValueError, 'caller-supplied'):
                receipt_adapter.run_with_receipts('x', 'y', self.root, freeze_sha256='0' * 64)
            load.assert_not_called()


class ReportingTests(unittest.TestCase):
    def test_failed_and_unsupported_cases_remain_distinct(self):
        self.assertEqual(runner.case_status({'outcome': 'pass', 'failures': []}), 'PASS')
        self.assertEqual(runner.case_status({'outcome': 'unsupported', 'failures': []}), 'UNSUPPORTED')
        self.assertEqual(runner.case_status({'outcome': 'unsupported', 'failures': ['overclaim']}), 'FAIL')
        self.assertEqual(runner.case_status({'outcome': 'pass', 'surface_results': {'browser_module': {'outcome': 'unsupported'}}}), 'PARTIAL')
        self.assertEqual(runner.case_status({'classification': 'execution_error'}), 'FAIL')

    def test_reproducibility_and_source_changes_cannot_pass(self):
        for report in [{'reproducibility': {'identical': False}}, {'candidate_unchanged': False},
                       {'reproducibility': {'equal_cases': 1, 'denominator': 2}},
                       {'summary': {'all_failures': ['bad']}}, {'successful': False}]:
            with self.subTest(report=report):
                self.assertTrue(runner.report_has_failures(report))

    def test_execution_failure_is_preserved_in_logs(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp).resolve()
            result = runner.run_command('deliberate-failure', [sys.executable, '-I', '-S', '-B', '-c',
                         'import sys; print("expected diagnostic",file=sys.stderr); sys.exit(3)'], output)
            self.assertEqual(result['status'], 'FAILED')
            self.assertEqual(result['returncode'], 3)
            self.assertIn('expected diagnostic', (output / result['stderr']).read_text())

    def test_missing_required_report_is_execution_error(self):
        with tempfile.TemporaryDirectory() as temp:
            result = runner.run_command('missing-report', [sys.executable, '-I', '-S', '-B', '-c', 'pass'],
                                        Path(temp).resolve(), report_name='required.json')
            self.assertEqual(result['status'], 'ERROR')

    def test_omitted_case_in_completed_harness_is_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp).resolve()
            runner.write_json(output / 'cases.json', {'cases': []})
            specs = {'wave1.toolkit': {'sha256': 'a' * 64, 'cases': [{'id': 'required-case'}]}}
            suites = [{'id': 'wave1.toolkit', 'status': 'COMPLETED', 'report': 'cases.json'}]
            self.assertEqual(runner.coverage_ledger(specs, suites, output)[0]['status'], 'FAIL')

    def test_legacy_mapping_cannot_launder_unsupported_surface_to_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp).resolve()
            runner.write_json(output / 'account.json', {'cases': [
                {'id': 'account.clean', 'classification': 'unsupported', 'failures': []}]})
            specs = {
                'wave1.account': {'sha256': 'a' * 64, 'cases': [{'id': 'account.clean', 'expected': {'accepted': True}}]},
                'wave2.expected': {'sha256': 'b' * 64, 'cases': [{'id': 'legacy.signed-records'}]},
            }
            suites = [{'id': 'wave1.account', 'status': 'COMPLETED', 'report': 'account.json'}]
            ledger = runner.coverage_ledger(specs, suites, output)
            self.assertEqual(ledger[-1]['status'], 'PARTIAL')

    def test_complete_frozen_case_inventory_is_175(self):
        runner.check_originals()
        self.assertEqual(sum(len(spec['cases']) for spec in runner.specifications().values()), 175)


class PortableIntegrationTests(unittest.TestCase):
    def test_missing_node_is_not_run_while_python_checks_still_execute(self):
        import prepare_source
        import verify_archive
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            source = root / 'source'
            verify_archive.publish_verified_files(prepare_source.read_verified_source(), source)
            output = root / 'report'
            with patch.object(runner.shutil, 'which', return_value=None), contextlib.redirect_stdout(io.StringIO()):
                code = runner.run(source, output)
            report = runner.read_json(output / 'report.json')
            suites = {suite['id']: suite for suite in report['suites']}
            self.assertEqual(code, 2)
            self.assertEqual(suites['harness.python']['status'], 'COMPLETED')
            self.assertEqual(suites['wave1.toolkit']['status'], 'COMPLETED')
            self.assertEqual(suites['harness.node']['status'], 'NOT_RUN')
            self.assertEqual(suites['wave2.reconciliation']['status'], 'NOT_RUN')
            self.assertEqual(report['coverage_by_specification']['wave1.account'], {'NOT_RUN': 31})

    @unittest.skipUnless(shutil.which('node'), 'Node.js required for full portable baseline')
    def test_exact_accepted_source_without_receipts_is_explicitly_incomplete(self):
        import prepare_source
        import verify_archive
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            source = root / 'source'
            verify_archive.publish_verified_files(prepare_source.read_verified_source(), source)
            output = root / 'report'
            with contextlib.redirect_stdout(io.StringIO()):
                code = runner.run(source, output)
            report = runner.read_json(output / 'report.json')
            self.assertEqual(code, 2)
            self.assertEqual(report['status'], 'INCOMPLETE')
            self.assertEqual(len(report['cases']), 175)
            self.assertFalse(any(c['status'] == 'FAIL' for c in report['cases']))
            suites = {suite['id']: suite for suite in report['suites']}
            for name in ['wave1.receipts', 'wave2.run-review', 'harness.wave2-receipts', 'wave1.engine', 'wave2.public-build']:
                self.assertEqual(suites[name]['status'], 'NOT_RUN', name)
            self.assertEqual(suites['harness.python']['harness_tests']['tests_run'], 17)
            self.assertEqual(suites['harness.node']['harness_tests']['tests'], 26)
            self.assertEqual(suites['comparison.n170']['observed_case_count'], 6)
            self.assertTrue(all(report['immutable_inputs_unchanged'].values()))
            self.assertFalse(any('private-evidence' in str(suite.get('command', [])) for suite in report['suites']))
            self.assertEqual(report['coverage_by_specification']['wave1.receipts'], {'NOT_RUN': 10})


if __name__ == '__main__':
    unittest.main()
