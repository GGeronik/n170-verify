"""Original synthetic archive controls; Python stdlib unittest only."""
import sys
sys.dont_write_bytecode = True

import hashlib
import io
import json
import os
from pathlib import Path
import stat
import struct
import subprocess
import tempfile
import unittest
from unittest import mock
import warnings
import zipfile
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import verify_archive as verify
import build_archive as build


def manifest(files):
    return {"schema_version": verify.SCHEMA, "files": [
        {"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        for name, data in sorted(files.items())]}


def encoded(value):
    return json.dumps(value, separators=(",", ":")).encode("utf-8")


def zipped(entries, compression=zipfile.ZIP_STORED):
    stream = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(stream, "w", compression=compression) as archive:
            for name, content in entries:
                archive.writestr(name, content)
    return stream.getvalue()


def packet(files=None, inventory=None, extra=(), compression=zipfile.ZIP_STORED):
    files = files if files is not None else {"docs/readme.txt": b"Original synthetic public archive control.\n"}
    inventory = encoded(manifest(files)) if inventory is None else inventory
    return zipped([(verify.INVENTORY, inventory), *files.items(), *extra], compression)


def raw_packet_with_trailing_member_data(method):
    """Independent ZIP framing with hidden bytes inside a declared data range."""
    files = {"a": b"original synthetic content"}
    records, directory = bytearray(), bytearray()
    for name, content in [(verify.INVENTORY, encoded(manifest(files))), *files.items()]:
        encoded_name = name.encode("ascii")
        compressor = zlib.compressobj(wbits=-15)
        packed = content if method == zipfile.ZIP_STORED else compressor.compress(content) + compressor.flush()
        if name == "a":
            packed += b"hidden bytes after the complete member"
        crc, offset = zlib.crc32(content), len(records)
        records += struct.pack("<4s5H3L2H", b"PK\x03\x04", 20, 0, method, 0, 33, crc, len(packed), len(content), len(encoded_name), 0)
        records += encoded_name + packed
        directory += struct.pack("<4s6H3L5H2L", b"PK\x01\x02", (3 << 8) | 20, 20, 0, method, 0, 33,
                                 crc, len(packed), len(content), len(encoded_name), 0, 0, 0, 0, (stat.S_IFREG | 0o644) << 16, offset)
        directory += encoded_name
    end = struct.pack("<4s4H2LH", b"PK\x05\x06", 0, 0, 2, 2, len(directory), len(records), 0)
    return bytes(records + directory + end)


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="n170-archive-test-")
        self.root = Path(self.temporary.name)
        self.files = {"docs/readme.txt": b"Original synthetic archive.\n", "payload/source.zip": b"Opaque synthetic payload, not an executable source."}

    def tearDown(self):
        self.temporary.cleanup()

    def source(self):
        root = self.root / "source"
        root.mkdir()
        for name, data in self.files.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        (root / verify.INVENTORY).write_bytes(encoded(manifest(self.files)))
        return root

    def reject(self, data, text=None):
        with self.assertRaises(verify.ArchiveError) as caught:
            verify.verify_bytes(data)
        if text:
            self.assertIn(text.lower(), str(caught.exception).lower())

    def test_valid_public_inventory_and_external_hash(self):
        data = packet(self.files)
        digest = hashlib.sha256(data).hexdigest()
        checked = verify.verify_bytes(data, digest.upper())
        self.assertEqual(checked.archive_sha256, digest)
        self.assertEqual(dict(checked.members), {verify.INVENTORY: encoded(manifest(self.files)), **self.files})
        with self.assertRaises(TypeError):
            checked.members["extra"] = b"not mutable"
        with self.assertRaisesRegex(verify.ArchiveError, "externally"):
            verify.verify_bytes(data, "0" * 64)
        with self.assertRaisesRegex(verify.ArchiveError, "64 hexadecimal"):
            verify.verify_bytes(data, "not a digest")

    def test_internal_inventory_is_not_authenticity(self):
        # A sender can recompute every internal digest. Only an independently
        # trusted original archive hash distinguishes this substituted package.
        original = packet(self.files)
        replacement = packet({"docs/readme.txt": b"Different public content"})
        verify.verify_bytes(replacement)
        with self.assertRaises(verify.ArchiveError):
            verify.verify_bytes(replacement, hashlib.sha256(original).hexdigest())

    def test_traversal_absolute_backslash_drive_and_reserved_paths(self):
        for path in ("../escape", "a/../../b", "/absolute", "\\absolute", "a\\b", "C:drive", "a//b", "./file", "a/./b", "a/../b", "a/", "a.", "CON", "con.txt", "a/NUL.zip", "LPT1", "a b", "a\nfile", "caf\u00e9", "x" * 241):
            with self.subTest(path=repr(path)):
                self.reject(packet({path: b"x"}))

    def test_duplicate_inventory_and_duplicate_member(self):
        data = packet(self.files)
        self.reject(packet(self.files, extra=[(verify.INVENTORY, encoded(manifest(self.files)))]), "Duplicate")
        self.reject(packet(self.files, extra=[("docs/readme.txt", b"other")]), "Duplicate")
        self.assertTrue(data)

    def test_casefold_and_directory_prefix_collisions(self):
        for files in ({"A.txt": b"x", "a.txt": b"y"}, {"A/one": b"x", "a/two": b"y"}, {"a": b"x", "a/b": b"y"}):
            with self.subTest(files=files):
                self.reject(packet(files), "collision")

    def test_symlink_and_special_nodes_are_rejected(self):
        for mode in (stat.S_IFLNK, stat.S_IFIFO, stat.S_IFSOCK, stat.S_IFCHR, stat.S_IFBLK, stat.S_IFDIR):
            with self.subTest(mode=mode):
                info = zipfile.ZipInfo("payload")
                info.create_system = 3
                info.external_attr = (mode | 0o777) << 16
                inventory = encoded(manifest({"payload": b"target"}))
                self.reject(zipped([(verify.INVENTORY, inventory), (info, b"target")]), "special")

    def test_explicit_directory_and_dos_directory_attributes_reject(self):
        self.reject(packet(self.files, extra=[("directory/", b"")]))
        info = zipfile.ZipInfo("directory")
        info.external_attr = 0x10
        self.reject(zipped([(verify.INVENTORY, encoded(manifest({"directory": b""}))), (info, b"")]), "Directory")

    def test_encryption_and_unsupported_flags_reject_before_read(self):
        for flag in (1, 0x40, 8, 0x10):
            with self.subTest(flag=flag):
                data = bytearray(packet(self.files))
                central = data.find(b"PK\x01\x02")
                struct.pack_into("<H", data, 6, flag)
                struct.pack_into("<H", data, central + 8, flag)
                self.reject(bytes(data))

    def test_local_header_name_and_metadata_disagreement_reject(self):
        data = bytearray(packet(self.files))
        data[30] = ord("x")
        self.reject(bytes(data), "names differ")
        data = bytearray(packet(self.files))
        struct.pack_into("<L", data, 22, 1)
        self.reject(bytes(data), "sizes or checksum")

    def test_nul_filename_rejects_before_zipfile_truncation(self):
        data = bytearray(packet({"nulx": b"data"}))
        for offset in (i for i in range(len(data) - 4) if data[i:i + 4] == b"nulx"):
            data[offset + 3] = 0
        self.reject(bytes(data), "NUL")

    def test_archive_comment_prefix_suffix_and_missing_end_reject(self):
        data = packet(self.files)
        for changed in (b"prefix" + data, data + b"suffix", data[:-1]):
            with self.subTest(length=len(changed)):
                self.reject(changed)
        stream = io.BytesIO(data)
        with zipfile.ZipFile(stream, "a") as archive:
            archive.comment = b"unsigned comment"
        self.reject(stream.getvalue(), "end record")

    def test_extra_fields_and_unsupported_compression_reject(self):
        info = zipfile.ZipInfo("a")
        info.extra = b"\x01\x00\x00\x00"
        self.reject(zipped([(verify.INVENTORY, encoded(manifest({"a": b"a"}))), (info, b"a")]), "metadata")
        self.reject(packet(self.files, compression=zipfile.ZIP_BZIP2), "compression")

    def test_missing_unlisted_and_inventory_self_membership_reject(self):
        inventory = encoded(manifest(self.files))
        self.reject(zipped(list(self.files.items())), "Missing")
        self.reject(packet(self.files, extra=[("secret.txt", b"unlisted")]), "unlisted")
        self.reject(packet({"docs/readme.txt": self.files["docs/readme.txt"]}, inventory), "omits")
        value = manifest(self.files)
        value["files"].append({"path": verify.INVENTORY, "size": 0, "sha256": "0" * 64})
        self.reject(packet(self.files, encoded(value)), "itself")

    def test_hash_size_and_crc_mismatch_reject(self):
        for field, replacement in (("size", 999), ("sha256", "0" * 64)):
            value = manifest(self.files)
            value["files"][0][field] = replacement
            self.reject(packet(self.files, encoded(value)), "mismatch")
        data = bytearray(packet(self.files))
        location = data.find(self.files["docs/readme.txt"])
        data[location] ^= 1
        self.reject(bytes(data), "CRC")

    def test_invalid_inventory_schema_unknown_fields_and_entry_types(self):
        controls = [[], {}, {"schema_version": "other", "files": []}, {**manifest(self.files), "trusted": True}]
        for field, value in (("path", 1), ("size", True), ("size", -1), ("size", 1.0), ("sha256", "A" * 64), ("sha256", 123)):
            changed = manifest(self.files)
            changed["files"][0][field] = value
            controls.append(changed)
        changed = manifest(self.files)
        changed["files"][0]["extra"] = "not allowed"
        controls.append(changed)
        for value in controls:
            with self.subTest(value=value):
                self.reject(packet(self.files, encoded(value)))

    def test_inventory_duplicate_escaped_fields_utf8_and_nonplain_numbers(self):
        data = encoded(manifest(self.files))
        controls = [data.replace(b'"size":', b'"s\\u0069ze":0,"size":', 1), data.replace(b'"files":', b'"files":[],"files":', 1),
                    data.replace(b'"size":28', b'"size":2.8e1', 1), data.replace(b'"size":28', b'"size":-0', 1),
                    b'{"schema_version":"\xff","files":[]}', b'[' * 1200 + b']' * 1200]
        for changed in controls:
            with self.subTest(prefix=changed[:80]):
                self.assertNotEqual(changed, data)
                self.reject(packet(self.files, changed))

    def test_inventory_order_and_duplicate_entries_reject(self):
        value = manifest(self.files)
        value["files"].reverse()
        self.reject(packet(self.files, encoded(value)), "sorted")
        value = manifest(self.files)
        value["files"].insert(0, value["files"][0])
        self.reject(packet(self.files, encoded(value)), "Duplicate")

    def test_bomb_ratio_member_total_archive_and_inventory_bounds(self):
        self.reject(packet({"bomb.txt": b"0" * (verify.RATIO_ALLOWANCE + 1)}, compression=zipfile.ZIP_DEFLATED), "ratio")
        data = packet(self.files)
        for setting, value, text in (("MAX_ARCHIVE", 10, "archive"), ("MAX_FILE", 10, "size"), ("MAX_TOTAL", 10, "total"), ("MAX_INVENTORY", 10, "unpacked"), ("MAX_ENTRIES", 1, "members")):
            with self.subTest(setting=setting), mock.patch.object(verify, setting, value):
                self.reject(data, text)

    def test_small_deflated_payload_is_supported(self):
        verify.verify_bytes(packet(self.files, compression=zipfile.ZIP_DEFLATED))

    def test_corrupted_deflate_is_a_clean_verification_failure(self):
        data = bytearray(packet(self.files, compression=zipfile.ZIP_DEFLATED))
        name_length = struct.unpack_from("<H", data, 26)[0]
        data[30 + name_length] = 0x07  # Reserved DEFLATE block type.
        self.reject(bytes(data), "Invalid")

    def test_hidden_trailing_bytes_inside_member_data_are_rejected(self):
        for method in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
            with self.subTest(method=method):
                self.reject(raw_packet_with_trailing_member_data(method))

    def test_overlapping_member_offsets_reject(self):
        data = bytearray(packet(self.files))
        first = data.find(b"PK\x01\x02")
        second = data.find(b"PK\x01\x02", first + 4)
        struct.pack_into("<L", data, second + 42, 0)
        self.reject(bytes(data), "overlapping")

    def test_fifo_archive_input_is_rejected_without_blocking(self):
        if not hasattr(os, "mkfifo"):
            self.skipTest("FIFO unavailable")
        path = self.root / "not-a-zip-fifo"
        os.mkfifo(path)
        with self.assertRaisesRegex(verify.ArchiveError, "regular"):
            verify.verify_archive(path)

    def test_builder_is_deterministic_and_sets_fixed_metadata(self):
        root = self.source()
        first = build.build_bytes(root)
        os.utime(root / "docs/readme.txt", (2000000000, 2000000000))
        (root / "docs/readme.txt").chmod(0o700)
        second = build.build_bytes(root)
        self.assertEqual(first, second)
        with zipfile.ZipFile(io.BytesIO(first)) as archive:
            self.assertEqual(archive.namelist(), sorted(archive.namelist()))
            for info in archive.infolist():
                self.assertEqual(info.date_time, (1980, 1, 1, 0, 0, 0))
                self.assertEqual(info.compress_type, zipfile.ZIP_STORED)
                self.assertEqual(info.external_attr >> 16, stat.S_IFREG | 0o644)
        verify.verify_bytes(first)

    def test_builder_rejects_unlisted_missing_modified_and_symlink_files(self):
        root = self.source()
        extra = root / "private-receipt.json"
        extra.write_bytes(b"must not be published")
        with self.assertRaisesRegex(verify.ArchiveError, "unlisted"):
            build.build_bytes(root)
        extra.unlink()
        target = root / "docs/readme.txt"
        target.write_bytes(b"changed")
        with self.assertRaises(verify.ArchiveError):
            build.build_bytes(root)
        target.unlink()
        with self.assertRaisesRegex(verify.ArchiveError, "omits"):
            build.build_bytes(root)
        target.symlink_to(self.root / "elsewhere")
        with self.assertRaisesRegex(verify.ArchiveError, "symlink"):
            build.build_bytes(root)

    def test_builder_rejects_source_directory_symlink_and_special_file(self):
        root = self.source()
        (root / "linked").symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(verify.ArchiveError, "symlink"):
            build.build_bytes(root)
        (root / "linked").unlink()
        if hasattr(os, "mkfifo"):
            os.mkfifo(root / "fifo")
            with self.assertRaisesRegex(verify.ArchiveError, "special"):
                build.build_bytes(root)

    def test_atomic_extract_never_rereads_changed_archive_path(self):
        path = self.root / "input.zip"
        path.write_bytes(packet(self.files))
        checked = verify.verify_archive(path)
        path.write_bytes(b"replaced after validation")
        destination = self.root / "new"
        verify.extract_verified(checked, destination)
        for name, data in checked.members.items():
            self.assertEqual((destination / name).read_bytes(), data)
        self.assertEqual(verify.verify_extracted_files(checked.members, destination), destination.resolve())

    def test_extract_refuses_existing_empty_nonempty_file_and_symlink(self):
        checked = verify.verify_bytes(packet(self.files))
        for kind in ("empty", "nonempty", "file", "symlink"):
            target = self.root / kind
            if kind in ("empty", "nonempty"):
                target.mkdir()
                if kind == "nonempty":
                    (target / "keep").write_bytes(b"untouched")
            elif kind == "file":
                target.write_bytes(b"untouched")
            else:
                target.symlink_to(self.root / "not-there")
            with self.subTest(kind=kind), self.assertRaisesRegex(verify.ArchiveError, "exists"):
                verify.extract_verified(checked, target)
        self.assertEqual((self.root / "nonempty/keep").read_bytes(), b"untouched")
        self.assertEqual((self.root / "file").read_bytes(), b"untouched")

    def test_target_created_during_staging_is_never_replaced(self):
        checked = verify.verify_bytes(packet(self.files))
        target = self.root / "competing-target"
        original = verify.publish_no_replace
        def competing(source, destination):
            Path(destination).mkdir()
            return original(source, destination)
        with mock.patch.object(verify, "publish_no_replace", side_effect=competing), self.assertRaises(OSError):
            verify.extract_verified(checked, target)
        self.assertEqual(list(target.iterdir()), [])
        self.assertFalse(list(self.root.glob(".n170-extract-*")))

    def test_extraction_write_failure_leaves_no_partial_destination_or_staging(self):
        checked = verify.verify_bytes(packet(self.files))
        destination = self.root / "new"
        with mock.patch.object(verify.os, "fsync", side_effect=OSError("injected write failure")), self.assertRaises(OSError):
            verify.extract_verified(checked, destination)
        self.assertFalse(destination.exists())
        self.assertFalse(list(self.root.glob(".n170-extract-*")))

    def test_unsupported_atomic_publication_fails_closed(self):
        checked = verify.verify_bytes(packet(self.files))
        destination = self.root / "new"
        with mock.patch.object(verify.sys, "platform", "unsupported-test-os"), self.assertRaisesRegex(verify.ArchiveError, "unsupported"):
            verify.extract_verified(checked, destination)
        self.assertFalse(destination.exists())
        self.assertFalse(list(self.root.glob(".n170-extract-*")))

    def test_public_helper_revalidates_paths_and_does_not_trust_callers(self):
        for files in ({"../bad": b"bad"}, {"A": b"x", "a": b"y"}, {"a": "not bytes"}, {}):
            with self.subTest(files=files), self.assertRaises(verify.ArchiveError):
                verify.publish_verified_files(files, self.root / "never-created")
        self.assertFalse((self.root / "never-created").exists())

    def test_tree_comparison_rejects_extra_modified_and_linked_files(self):
        checked = verify.verify_bytes(packet(self.files))
        target = verify.extract_verified(checked, self.root / "tree")
        verify.verify_extracted_files(checked.members, target)
        extra = target / "unexpected"
        extra.write_bytes(b"extra")
        with self.assertRaisesRegex(verify.ArchiveError, "unlisted"):
            verify.verify_extracted_files(checked.members, target)
        extra.unlink()
        path = target / "docs/readme.txt"
        path.write_bytes(b"modified")
        with self.assertRaisesRegex(verify.ArchiveError, "differs"):
            verify.verify_extracted_files(checked.members, target)
        path.unlink()
        path.symlink_to(self.root / "outside")
        with self.assertRaisesRegex(verify.ArchiveError, "symlink"):
            verify.verify_extracted_files(checked.members, target)

    def test_source_capture_does_not_follow_swapped_parent_link(self):
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "value").write_bytes(b"outside")
        root = self.root / "root"
        root.mkdir()
        (root / "parent").symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            verify.capture_source_file(root, "parent/value", 100)

    def test_atomic_builder_refuses_existing_output_and_output_inside_source(self):
        root = self.source()
        output = self.root / "built.zip"
        digest = build.build_archive(root, output)
        self.assertEqual(digest, hashlib.sha256(output.read_bytes()).hexdigest())
        with self.assertRaisesRegex(verify.ArchiveError, "exists"):
            build.build_archive(root, output)
        with self.assertRaisesRegex(verify.ArchiveError, "outside"):
            build.build_archive(root, root / "accidental-output.zip")

    def test_cli_verification_and_extraction_and_bad_input_leave_no_output(self):
        script = Path(verify.__file__)
        path = self.root / "input.zip"
        path.write_bytes(packet(self.files))
        target = self.root / "extracted"
        result = subprocess.run([sys.executable, "-B", str(script), str(path), "--extract", str(target)], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report["integrity"], "verified")
        self.assertEqual(report["authenticity"], "not_established_by_internal_inventory")
        path.write_bytes(b"invalid")
        failure = self.root / "no-output"
        result = subprocess.run([sys.executable, "-B", str(script), str(path), "--extract", str(failure)], text=True, capture_output=True)
        self.assertEqual(result.returncode, 1)
        self.assertFalse(failure.exists())


if __name__ == "__main__":
    unittest.main()
