"""Frozen independent mutations of a producer's immutable execution receipt.

Copies are mutated only in a new temporary directory. The target is never edited.
Expected results are receipt invariants, not verifier-generated answers.
"""
from __future__ import annotations
import argparse
import copy
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
from .toolkit import canonical, load_frozen, sha, source_identity


def receipt_files(root):
    root = Path(root).resolve()
    files = []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Receipt contains a symlink')
        mode = path.lstat().st_mode
        if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise ValueError('Receipt contains a nonregular file')
        if stat.S_ISREG(mode):
            raw = path.read_bytes()
            files.append({'path': path.relative_to(root).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
    return files


def safe_artifact(root, name):
    """Never let an untrusted inventory mutation escape its disposable copy."""
    if not isinstance(name, str) or not name or name.startswith('/') or any(p in {'', '.', '..'} for p in name.split('/')):
        raise ValueError('Unsafe receipt artifact path')
    path = root
    for component in name.split('/'):
        path = path / component
        if path.is_symlink():
            raise ValueError('Symlink receipt artifact')
    if root.resolve() not in path.resolve().parents or not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('Artifact must be a regular file inside the disposable receipt')
    return path


def invoke(target, directory, pin):
    script = '''import sys,json
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
from verify_toolkit.run_contract import verify_run
print(json.dumps(verify_run(sys.argv[2],manifest_sha256=sys.argv[3]),sort_keys=True,allow_nan=False))'''
    result = subprocess.run([sys.executable, '-I', '-S', '-B', '-c', script,
        str(Path(target).resolve()), str(directory), pin], capture_output=True, text=True, timeout=60)
    if result.returncode:
        return {'adapter_error': 'verifier_process_exit', 'exit_code': result.returncode}
    return json.loads(result.stdout)


def mutate(root, mutation, original_pin):
    path = root / 'manifest.json'
    m = json.loads(path.read_bytes())
    if mutation in {'artifact_bytes', 'artifact_missing'}:
        candidates = [x['path'] for x in m['artifacts'] if x['path'].endswith('lookahead.csv')]
        if not candidates:
            candidates = [x['path'] for x in m['artifacts']]
        if not candidates:
            raise ValueError('Control receipt needs a retained artifact')
        artifact = safe_artifact(root, candidates[0])
        if mutation == 'artifact_bytes':
            artifact.write_bytes(artifact.read_bytes() + b'\nindependent challenge alteration\n')
        else:
            artifact.unlink()
    elif mutation == 'extra_artifact':
        (root / 'uncommitted-evidence.txt').write_text('original synthetic undeclared evidence\n')
    elif mutation == 'manifest_changed_external_pin':
        m['run_id'] = str(m['run_id']) + '-changed'
    elif mutation == 'unfinished_state':
        m['state'] = 'RUNNING'
    elif mutation == 'duplicate_attempt':
        m['attempts'].append(copy.deepcopy(m['attempts'][0]))
    elif mutation == 'missing_attempt':
        m['attempts'].pop()
    elif mutation == 'failed_attempt_clean_summary':
        m['attempts'][0]['outcome'] = 'FAILED'
        m['attempts'][0]['exit_code'] = 1
    if mutation in {'manifest_changed_external_pin', 'unfinished_state', 'duplicate_attempt', 'missing_attempt', 'failed_attempt_clean_summary'}:
        path.write_text(json.dumps(m, sort_keys=True, indent=2) + '\n')
    return original_pin if mutation == 'manifest_changed_external_pin' else sha(path.read_bytes())


def run(target, receipt, expected_status, retained_pin):
    spec, spec_hash = load_frozen('receipt-cases')
    source = source_identity(target)
    receipt = Path(receipt).resolve()
    inventory = receipt_files(receipt)
    manifest_sha = sha((receipt / 'manifest.json').read_bytes())
    if manifest_sha != retained_pin:
        raise ValueError('Original receipt identity differs from retained manifest pin')
    if expected_status not in {'NO_FINDINGS_REPORTED', 'FINDINGS_REPORTED'}:
        raise ValueError('Receipt benchmark requires an independently expected assessable control')
    cases = []
    for case in spec['cases']:
        if case['kind'] == 'unsupported':
            cases.append(dict(case, classification='unsupported', failures=[], supported=False))
            continue
        repeats = []
        for _ in range(2):
            with tempfile.TemporaryDirectory(prefix='n170-independent-receipt-') as temp:
                clone = Path(temp).resolve() / 'receipt'
                shutil.copytree(receipt, clone)
                pin = mutate(clone, case['mutation'], manifest_sha)
                repeats.append(invoke(target, clone, pin))
        actual = repeats[0]
        if type(actual) is not dict:
            actual = {'adapter_error': 'invalid_verifier_result_shape'}
        status = actual.get('status')
        if type(status) is not str:
            status = None
            actual = dict(actual, adapter_error='invalid_verifier_status_shape')
        ok = status == expected_status if case['kind'] == 'clean' else status == 'NOT_ASSESSABLE'
        failures = [] if ok else ['unexpected_verifier_outcome']
        if canonical(repeats[0]) != canonical(repeats[1]):
            failures.append('nonreproducible')
        if actual.get('adapter_error'):
            failures.append('adapter_error')
        cases.append(dict(case, supported=True, classification='pass' if not failures else 'failure',
            actual=actual, failures=failures,
            false_acceptance=case['kind']=='adversarial' and status in {'NO_FINDINGS_REPORTED','FINDINGS_REPORTED'},
            false_rejection=case['kind']=='clean' and status=='NOT_ASSESSABLE',
            repeat_equal=canonical(repeats[0]) == canonical(repeats[1])))
    if source_identity(target) != source or receipt_files(receipt) != inventory:
        raise ValueError('Immutable candidate or receipt changed while testing')
    supported = [x for x in cases if x['supported']]
    return {'schema':'n170.challenge.receipt-result.v1','specification_sha256':spec_hash,
        'candidate_identity':source,'receipt_manifest_sha256':manifest_sha,'receipt_inventory':inventory,
        'expected_control_status':expected_status,'method':spec['method'],'external_audit':False,
        'scope':'Offline receipt integrity and attempt accounting, not independent engine execution or remote authenticity.',
        'cases':cases,'summary':{'total_cases':len(cases),'supported_cases':len(supported),
        'unsupported_cases':len(cases)-len(supported),
        'false_acceptance':{'count':sum(x['false_acceptance'] for x in supported),'denominator':sum(x['kind']=='adversarial' for x in supported)},
        'false_rejection':{'count':sum(x['false_rejection'] for x in supported),'denominator':sum(x['kind']=='clean' for x in supported)},
        'all_failures':[{'id':x['id'],'failures':x['failures']} for x in cases if x['failures']]},
        'reproducibility':{'equal_cases':sum(x['repeat_equal'] for x in supported),'denominator':len(supported),'processes_per_case':2}}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--toolkit-root',required=True);p.add_argument('--receipt',required=True)
    p.add_argument('--manifest-sha256',required=True);p.add_argument('--expected-status',required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=run(a.toolkit_root,a.receipt,a.expected_status,a.manifest_sha256)
    with a.output.open('x') as f:json.dump(r,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(r['summary'],indent=2))
    return bool(r['summary']['all_failures'])

if __name__=='__main__':raise SystemExit(main())
