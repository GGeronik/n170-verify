#!/usr/bin/env node
// SPDX-License-Identifier: Apache-2.0
// Exercises only the original N170 mock. Never imports upstream AuditZK code.
import { createHash } from 'node:crypto';
import { readFile, writeFile, lstat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { evaluateCase, summarizeCases, targetInventory } from './run.mjs';

const executeFile = promisify(execFile);
const script = fileURLToPath(import.meta.url);
const here = path.dirname(script);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const checkNames = ['endorsementChain', 'measurement', 'freshness', 'reportSignature', 'reportBinding', 'sourceBinding'];
const verificationFlags = ['realAttestationVerified', 'reportSignatureVerified', 'reportDigestVerified', 'sourceBindingVerified', 'financialCalculationVerified', 'signedRecordModification'];

export async function loadMockFreeze(directory = here) {
  const bytes = await readFile(path.join(directory, 'auditzk-mock-cases.json'));
  const expected = (await readFile(path.join(directory, 'auditzk-mock-cases.sha256'), 'utf8')).trim().split(/\s/)[0];
  if (sha(bytes) !== expected) throw new Error('Frozen mock-only expected results changed. Refusing to score.');
  const specification = JSON.parse(bytes);
  if (specification.schema !== 'n170.challenge.auditzk-mock.spec.v1') throw new Error('Unexpected mock-only specification.');
  return { specification, specification_sha256: expected };
}

export function mockCaseInput(specification, spec) {
  const options = structuredClone(specification.options);
  const request = structuredClone(specification.request);
  for (const [object, mutations] of [[options, spec.options_set], [request, spec.request_set]]) {
    for (const [location, value] of Object.entries(mutations || {})) {
      const keys = location.split('.');
      const key = keys.pop();
      let parent = object;
      for (const part of keys) parent = parent[part];
      parent[key] = structuredClone(value);
    }
  }
  let getterCalls = 0;
  if (spec.request_transform === 'getter') {
    Object.defineProperty(request, 'reportSha256', {
      enumerable: true, configurable: true,
      get() { getterCalls++; return specification.request.reportSha256; },
    });
  }
  return { options, request, getterCalls: () => getterCalls };
}

export function observeMock(result, operation) {
  if (operation === 'capabilities') {
    return Object.fromEntries(['integrationStatus', 'realIntegrationAvailable', 'grantStatus', 'acceptsCredentials', 'networkAccess', 'financialCalculation', 'signedRecordModification'].map(key => [key, result?.[key]]));
  }
  return {
    status: result?.status, synthetic: result?.synthetic,
    sourceClaimStatus: result?.sourceClaimStatus,
    sourceAuthenticity: result?.sourceAuthenticity,
    sourceFreshness: result?.sourceFreshness,
    sourceCompleteness: result?.sourceCompleteness,
    verified_flags: Object.fromEntries(verificationFlags.map(key => [key, result?.[key]])),
    mock_limitation: typeof result?.limitation === 'string' && result.limitation.includes('SYNTHETIC MOCK ONLY'),
    checks: Object.fromEntries(checkNames.map(key => [key, result?.checks?.find(check => check.check === key)?.status])),
    missingPrerequisites: result?.missingPrerequisites,
  };
}

async function worker(target, expectedSourceSha256) {
  const frozen = await loadMockFreeze();
  const identity = await targetInventory(target);
  if (expectedSourceSha256 && identity.source_sha256 !== expectedSourceSha256) throw new Error('Candidate identity differs from externally supplied source pin.');
  const modulePath = path.join(identity.root, frozen.specification.interface.module);
  let loaded;
  try {
    await lstat(modulePath);
    try { loaded = { exports: await import(pathToFileURL(modulePath).href) }; }
    catch (error) { loaded = { adapter_error: `Cannot load mock adapter: ${error.message}` }; }
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    loaded = { unsupported: true, unsupported_reason: 'Original N170 mock adapter interface is absent.' };
  }
  const cases = [];
  for (const spec of frozen.specification.cases) {
    let actual;
    if (spec.operation === 'unsupported') actual = { unsupported: true, executed: false };
    else if (!loaded.exports) actual = loaded;
    else if (['auditZkCapabilities', 'createAuditZkAdapter'].some(name => typeof loaded.exports[name] !== 'function')) {
      actual = { unsupported: true, unsupported_reason: 'Required original N170 mock adapter factory/capability interface is absent.' };
    } else {
      const input = mockCaseInput(frozen.specification, spec);
      let result;
      try {
        if (spec.operation === 'capabilities') result = await loaded.exports.auditZkCapabilities();
        else {
          const adapter = spec.operation === 'default' ? loaded.exports.createAuditZkAdapter()
            : loaded.exports.createAuditZkAdapter(input.options);
          result = await adapter.verify(input.request);
        }
      } catch (error) { actual = { accepted: false, error_name: error.name, error: error.message }; }
      if (!actual) {
        try { actual = { accepted: true, ...observeMock(result, spec.operation) }; }
        catch (error) { actual = { adapter_error: `Cannot observe mock result: ${error.message}` }; }
      }
      if (spec.request_transform === 'getter') actual.getter_calls = input.getterCalls();
    }
    cases.push(evaluateCase(spec, actual));
  }
  const after = await targetInventory(target);
  if (identity.source_sha256 !== after.source_sha256) throw new Error('Candidate source changed during mock-only evaluation.');
  const summary = summarizeCases(cases);
  summary.false_acceptance.denominator_definition = 'Supported invalid local mock-contract requests independently specified to reject.';
  summary.false_rejection.denominator_definition = 'Supported valid local mock-contract capability and simulated result requests independently specified to accept.';
  return { specification_sha256: frozen.specification_sha256, target: identity, cases, summary };
}

export async function runMockBenchmark({ target, expectedSourceSha256 }) {
  const runs = [];
  for (let i = 0; i < 2; i++) {
    const args = [script, '--worker', '--target', path.resolve(target)];
    if (expectedSourceSha256) args.push('--expected-source-sha256', expectedSourceSha256);
    const { stdout } = await executeFile(process.execPath, args, { maxBuffer: 8 * 1024 * 1024, timeout: 60000 });
    runs.push(JSON.parse(stdout));
  }
  const hashes = runs.map(run => sha(JSON.stringify(run)));
  const differing = runs[0].cases.filter((value, i) => !equal(value, runs[1].cases[i])).map(value => value.id);
  return {
    schema: 'n170.challenge.auditzk-mock.report.v1',
    benchmark: 'Original N170 AuditZK collaboration mock contract only; no upstream implementation or real evidence tested',
    synthetic: true, external_review: false, real_auditzk_verification_tested: false,
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    ...runs[0],
    reproducibility: { method: 'Two fresh Node processes exercise predetermined mock contract inputs; exact normalized results and source identity compared.', runs: 2, result_sha256: hashes, identical: hashes[0] === hashes[1], differing_case_ids: differing, equal_cases: runs[0].cases.length - differing.length, denominator: runs[0].cases.length },
    limitations: [
      'Mock scenarios choose outcomes. Passing these tests is not detector accuracy, attestation validation, signature verification or security review.',
      'No AuditZK upstream code, real report, TEE, provider account, network request, credential or applicable written license grant is exercised.',
      'Genuine verification remains unsupported; this additive mock suite does not change unsupported classifications in the viewer freeze.',
      'An agent-run engineering challenge is not an external audit or outside-user review.',
    ],
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === script) {
  try {
    const argv = process.argv.slice(2);
    const get = name => { const i = argv.indexOf(name); return i < 0 ? undefined : argv[i + 1]; };
    const target = get('--target');
    if (!target) throw new Error('Usage: node verify_benchmarks/viewer/auditzk-mock-run.mjs --target APP_DIRECTORY [--output REPORT.json] [--expected-source-sha256 HASH]');
    const options = { target, expectedSourceSha256: get('--expected-source-sha256') };
    const report = argv.includes('--worker') ? await worker(options.target, options.expectedSourceSha256) : await runMockBenchmark(options);
    const text = JSON.stringify(report, null, 2) + '\n';
    if (get('--output')) await writeFile(path.resolve(get('--output')), text);
    else process.stdout.write(text);
    if (!argv.includes('--worker') && (report.summary.failures.length || !report.reproducibility.identical)) process.exitCode = 1;
  } catch (error) { process.stderr.write(`Mock-only benchmark error: ${error.message}\n`); process.exitCode = 2; }
}
