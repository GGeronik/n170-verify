#!/usr/bin/env node
// SPDX-License-Identifier: Apache-2.0
import { createHash } from 'node:crypto';
import { readFile, writeFile, readdir, lstat, realpath } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const executeFile = promisify(execFile);
const script = fileURLToPath(import.meta.url);
const here = path.dirname(script);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const boundaryKeys = ['tool_execution', 'source_authenticity', 'run_completeness', 'run_freshness', 'context_authenticity'];

export async function loadFrozenCases(directory = here) {
  const bytes = await readFile(path.join(directory, 'cases.json'));
  const expected = (await readFile(path.join(directory, 'cases.sha256'), 'utf8')).trim().split(/\s/)[0];
  const specificationSha256 = digest(bytes);
  if (specificationSha256 !== expected) throw new Error('Frozen viewer expected results changed. Refusing to score.');
  const specification = JSON.parse(bytes);
  if (specification.schema !== 'n170.challenge.viewer.spec.v1') throw new Error('Unsupported viewer challenge specification.');
  const ids = specification.cases.map(c => c.id);
  if (new Set(ids).size !== ids.length) throw new Error('Duplicate viewer case identifiers.');
  return { specification, specification_sha256: specificationSha256 };
}

// Same explicit source identity boundary as the account suite. This inventory
// describes the scored source; it does not declare that every file is public.
export async function targetInventory(target) {
  const root = await realpath(target);
  const files = [];
  async function walk(relative) {
    const full = path.join(root, relative);
    let info;
    try { info = await lstat(full); } catch (error) { if (error.code === 'ENOENT') return; throw error; }
    if (info.isSymbolicLink()) throw new Error(`Source identity refuses symlink: ${relative}`);
    if (info.isDirectory()) {
      for (const name of (await readdir(full)).sort()) await walk(path.join(relative, name));
    } else if (info.isFile()) {
      const bytes = await readFile(full);
      files.push({ path: relative.split(path.sep).join('/'), bytes: bytes.length, sha256: digest(bytes) });
    }
  }
  for (const relative of ['src', 'package.json', 'package-lock.json', 'FORMAT.md', 'FORMAT-v3.md', 'scripts/verify-record.mjs']) await walk(relative);
  files.sort((a, b) => a.path.localeCompare(b.path));
  if (!files.length) throw new Error('No application source found at target.');
  return { root, method: 'SHA-256 of compact JSON entries sorted by relative path; each entry includes path, byte length and file SHA-256.', source_sha256: digest(JSON.stringify(files)), files };
}

export function caseInput(specification, spec) {
  const report = structuredClone(specification.fixture);
  function parentOf(location) {
    const keys = location.split('.');
    const key = keys.pop();
    let object = report;
    for (const part of keys) object = object[part];
    return { object, key };
  }
  for (const [location, value] of Object.entries(spec.set || {})) {
    const { object, key } = parentOf(location);
    object[key] = structuredClone(value);
  }
  for (const location of spec.remove || []) {
    const { object, key } = parentOf(location);
    delete object[key];
  }
  let text = JSON.stringify(report);
  if (spec.text_transform === 'duplicate_status') text = text.replace('"status":', '"status":"FINDINGS_REPORTED","status":');
  if (spec.text_transform === 'invalid_json') text = '{"schema":';
  if (spec.text_transform === 'oversized_utf8') {
    // A valid JSON string whose UTF-8 bytes exceed 4 MiB while JS character
    // count is below that limit, exercising bytes rather than string length.
    report.limitations = ['\u20ac'.repeat(Math.floor(specification.interface.max_input_bytes / 3) + 1)];
    text = JSON.stringify(report);
  }
  return { report, text };
}

function normalizeReport(value) {
  return typeof value === 'string' ? JSON.parse(value) : value;
}

export function observeReport(value, inputReport, operation) {
  const report = normalizeReport(value);
  const actual = {
    accepted: true,
    status: report?.status,
    tested_strategy_count: report?.tested_strategy_count,
    total_signals: report?.rows?.map(row => row.total_signals ?? null),
    scope: Object.fromEntries(boundaryKeys.map(key => [key, report?.scope?.[key]])),
  };
  if (operation.startsWith('export_')) {
    actual.strategy_labels_included = report?.disclosure?.strategy_labels_included;
    const labels = inputReport.rows.flatMap(row => [row.filename, row.strategy, ...(row.biased_indicators || [])]).filter(Boolean);
    const serialized = JSON.stringify(report) ?? '';
    actual.labels_omitted = Array.isArray(report?.rows)
      && report.rows.every(row => !['filename', 'strategy', 'biased_indicators'].some(key => Object.hasOwn(row, key)))
      && labels.every(label => !serialized.includes(label));
    actual.labels_retained = labels.every(label => serialized.includes(label));
  }
  return actual;
}

export function evaluateCase(spec, actual) {
  const failures = [];
  const expected = spec.expected;
  let classification;
  if (expected.unsupported || actual.unsupported) classification = 'unsupported';
  else if (actual.adapter_error) { classification = 'execution_error'; failures.push(actual.adapter_error); }
  else {
    for (const [key, value] of Object.entries(expected)) {
      if (!equal(actual[key], value)) failures.push(`${key}: expected ${JSON.stringify(value)}, actual ${JSON.stringify(actual[key])}.`);
    }
    if (expected.accepted === false && actual.accepted === true) classification = 'false_acceptance';
    else if (expected.accepted === true && actual.accepted === false) classification = 'false_rejection';
    else if (failures.length) classification = 'assertion_failure';
    else classification = expected.accepted ? 'true_acceptance' : 'true_rejection';
  }
  return {
    id: spec.id, scope: spec.scope, kind: spec.kind, method: spec.oracle_method,
    expected, actual, supported: classification !== 'unsupported', classification, failures,
    ...(classification === 'unsupported' ? { unsupported_reason: spec.unsupported_reason || actual.unsupported_reason } : {}),
  };
}

export function summarizeCases(cases) {
  const supported = cases.filter(c => c.supported);
  const adverse = supported.filter(c => c.kind === 'adversarial');
  const clean = supported.filter(c => c.kind === 'clean');
  const count = label => cases.filter(c => c.classification === label).length;
  const failures = cases.filter(c => c.failures.length).map(c => ({ id: c.id, classification: c.classification, failures: c.failures }));
  return {
    total_cases: cases.length, supported_cases: supported.length, unsupported_cases: count('unsupported'),
    false_acceptance: { count: count('false_acceptance'), denominator: adverse.length, denominator_definition: 'Supported adversarial cases independently specified to reject invalid or overclaiming reports.' },
    false_rejection: { count: count('false_rejection'), denominator: clean.length, denominator_definition: 'Supported clean cases independently specified to accept valid clean, findings, unassessable, or sharing operations.' },
    assertion_failures: count('assertion_failure'), execution_errors: count('execution_error'),
    passed_cases: count('true_acceptance') + count('true_rejection'),
    unsupported_coverage: { count: count('unsupported'), denominator: cases.length, case_ids: cases.filter(c => !c.supported).map(c => c.id) },
    scopes: Object.fromEntries([...new Set(cases.map(c => c.scope))].sort().map(scope => {
      const group = cases.filter(c => c.scope === scope);
      return [scope, { cases: group.length, supported: group.filter(c => c.supported).length, failures: group.filter(c => c.failures.length).map(c => c.id) }];
    })),
    supported_outcome_failures: supported.filter(c => c.failures.length).map(c => c.id),
    failures, all_failures: failures,
  };
}

async function executeCases(target, specification) {
  const filename = path.join(target, specification.interface.module);
  let loaded;
  try {
    await lstat(filename);
    try { loaded = { exports: await import(pathToFileURL(filename).href) }; }
    catch (error) { loaded = { adapter_error: `Cannot load toolEvidence.js: ${error.message}` }; }
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    loaded = { unsupported: true, unsupported_reason: 'src/toolEvidence.js is absent; baseline has no compatible viewer interface.' };
  }
  const results = [];
  for (const spec of specification.cases) {
    let actual;
    if (spec.operation === 'unsupported') actual = { unsupported: true, unsupported_reason: spec.unsupported_reason, executed: false };
    else if (!loaded.exports) actual = loaded;
    else {
      const implementation = loaded.exports;
      const names = spec.operation === 'parse' ? ['parseToolEvidence'] : ['parseToolEvidence', 'makeToolEvidenceExport'];
      const missing = names.filter(name => typeof implementation[name] !== 'function');
      if (missing.length) actual = { unsupported: true, unsupported_reason: `Required exported interface absent: ${missing.join(', ')}` };
      else {
        const input = caseInput(specification, spec);
        let returned;
        try {
          const parsed = await implementation.parseToolEvidence(input.text);
          returned = spec.operation === 'parse' ? parsed
            : spec.operation === 'export_default' ? await implementation.makeToolEvidenceExport(parsed)
              : await implementation.makeToolEvidenceExport(parsed, { includeLabels: true });
        } catch (error) {
          actual = { accepted: false, error_name: error.name, error: error.message };
        }
        if (!actual) {
          try { actual = observeReport(returned, input.report, spec.operation); }
          catch (error) { actual = { adapter_error: `Returned report cannot be observed: ${error.message}` }; }
        }
      }
    }
    results.push(evaluateCase(spec, actual));
  }
  return results;
}

async function worker(target, expectedSourceSha256) {
  const frozen = await loadFrozenCases();
  const identity = await targetInventory(target);
  if (expectedSourceSha256 && identity.source_sha256 !== expectedSourceSha256) throw new Error('Candidate identity differs from externally supplied source pin.');
  const cases = await executeCases(identity.root, frozen.specification);
  const after = await targetInventory(target);
  if (identity.source_sha256 !== after.source_sha256) throw new Error('Target changed while viewer benchmark was running.');
  return { specification_sha256: frozen.specification_sha256, target: identity, cases, summary: summarizeCases(cases) };
}

export async function runViewerBenchmark({ target, expectedSourceSha256 }) {
  if (!target) throw new Error('Target application directory is required.');
  const runs = [];
  for (let index = 0; index < 2; index++) {
    const args = [script, '--worker', '--target', path.resolve(target)];
    if (expectedSourceSha256) args.push('--expected-source-sha256', expectedSourceSha256);
    const { stdout } = await executeFile(process.execPath, args, { maxBuffer: 16 * 1024 * 1024, timeout: 60000 });
    runs.push(JSON.parse(stdout));
  }
  const resultHashes = runs.map(run => digest(JSON.stringify(run)));
  const differing = runs[0].cases.filter((value, i) => !equal(value, runs[1].cases[i])).map(value => value.id);
  return {
    schema: 'n170.challenge.viewer.report.v1', benchmark: 'Independent synthetic supplied-tool observation viewer challenges',
    synthetic: true, external_review: false,
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    ...runs[0],
    reproducibility: { method: 'Two sequential fresh Node.js processes; exact JSON observations and target source identity compared. No engine, account, network or external participant is involved.', runs: 2, result_sha256: resultHashes, identical: resultHashes[0] === resultHashes[1], differing_case_ids: differing, equal_cases: runs[0].cases.length - differing.length, denominator: runs[0].cases.length },
    limitations: [
      'Engineering challenge only; not an external audit or outside-user review.',
      'Supplied report parser and export conformance do not establish engine detector performance, source authenticity, run freshness or complete research coverage.',
      'Synthetic observations do not validate investment performance or feasible execution.',
      'Rates apply only to enumerated supported cases and denominators; unsupported dimensions are not passes.',
      'Node interface tests do not exercise browser UI, accessibility, persistence or deployment.',
      'AuditZK conformance remains separately unsupported pending an explicit interface and applicable license grant.',
    ],
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === script) {
  try {
    const argv = process.argv.slice(2);
    const get = name => { const i = argv.indexOf(name); return i < 0 ? undefined : argv[i + 1]; };
    const target = get('--target');
    if (!target) throw new Error('Usage: node verify_benchmarks/viewer/run.mjs --target APP_DIRECTORY [--output REPORT.json] [--expected-source-sha256 HASH]');
    const expectedSourceSha256 = get('--expected-source-sha256');
    const report = argv.includes('--worker') ? await worker(target, expectedSourceSha256) : await runViewerBenchmark({ target, expectedSourceSha256 });
    const text = JSON.stringify(report, null, 2) + '\n';
    if (get('--output')) await writeFile(path.resolve(get('--output')), text);
    else process.stdout.write(text);
    // Scored defects are worker data, not a failed subprocess transport. The
    // outer CLI still returns 1 so CI fails while retaining the full report.
    if (!argv.includes('--worker') && (report.summary.failures.length || report.reproducibility?.identical === false)) process.exitCode = 1;
  } catch (error) { process.stderr.write(`Viewer benchmark error: ${error.message}\n`); process.exitCode = 2; }
}
