// SPDX-License-Identifier: Apache-2.0
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { loadMockFreeze, mockCaseInput, observeMock, runMockBenchmark } from '../viewer/auditzk-mock-run.mjs';
import { evaluateCase } from '../viewer/run.mjs';

test('additive mock freeze is separately identified and leaves real verification unsupported', async () => {
  const { specification, specification_sha256 } = await loadMockFreeze();
  assert.equal(specification_sha256, 'b3616feddf6cfa51ce595c5a229b27e6b84394c3492587bc04f046d5500b66dd');
  assert.equal(specification.cases.length, 22);
  assert.equal(specification.cases.filter(c => c.kind === 'clean').length, 12);
  assert.equal(specification.cases.filter(c => c.kind === 'adversarial').length, 9);
  assert.equal(specification.cases.filter(c => c.expected.unsupported).length, 1);
});

test('getter challenge does not execute its getter during fixture construction', async () => {
  const { specification } = await loadMockFreeze();
  const spec = specification.cases.find(c => c.id === 'auditzk_mock.request_accessor_refused');
  const input = mockCaseInput(specification, spec);
  assert.equal(input.getterCalls(), 0);
  assert.equal(typeof Object.getOwnPropertyDescriptor(input.request, 'reportSha256').get, 'function');
  void input.request.reportSha256;
  assert.equal(input.getterCalls(), 1);
});

test('mock success promoted to genuine verification is scored as an assertion failure', async () => {
  const { specification } = await loadMockFreeze();
  const spec = specification.cases.find(c => c.id === 'auditzk_mock.all_mock_checks_pass');
  const expected = spec.expected;
  const result = {
    ...expected, ...expected.verified_flags, realAttestationVerified: true,
    limitation: 'SYNTHETIC MOCK ONLY', checks: Object.entries(expected.checks).map(([check, status]) => ({ check, status })),
  };
  const observed = { accepted: true, ...observeMock(result, 'verify') };
  const evaluated = evaluateCase(spec, observed);
  assert.equal(evaluated.classification, 'assertion_failure');
  assert.match(evaluated.failures.join('\n'), /verified_flags/);
});

test('absent mock reports unsupported without upgrading real integration', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-mock-absent-'));
  try {
    await writeFile(path.join(temporary, 'package.json'), '{"type":"module"}\n');
    const report = await runMockBenchmark({ target: temporary });
    assert.equal(report.summary.unsupported_cases, 22);
    assert.equal(report.summary.supported_cases, 0);
    assert.equal(report.real_auditzk_verification_tested, false);
    assert.equal(report.reproducibility.identical, true);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});

test('permissive fake adapter produces a complete defect report from fresh workers', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-mock-mutant-'));
  try {
    await mkdir(path.join(temporary, 'src'));
    await writeFile(path.join(temporary, 'package.json'), '{"type":"module"}\n');
    await writeFile(path.join(temporary, 'src/auditZkAdapter.js'), 'export const auditZkCapabilities = () => ({realIntegrationAvailable:true}); export const createAuditZkAdapter = () => ({verify: async request => ({status:"verified",realAttestationVerified:true})});\n');
    const report = await runMockBenchmark({ target: temporary });
    assert.equal(report.summary.false_acceptance.count, 9);
    assert.equal(report.summary.false_acceptance.denominator, 9);
    assert.equal(report.summary.false_rejection.count, 0);
    assert.equal(report.summary.assertion_failures, 12);
    assert.equal(report.summary.unsupported_cases, 1);
    assert.equal(report.reproducibility.identical, true);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});
