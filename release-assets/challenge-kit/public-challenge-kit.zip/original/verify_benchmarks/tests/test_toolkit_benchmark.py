import copy
from pathlib import Path
import tempfile
import unittest
from verify_benchmarks.toolkit import BOUNDARY, classify, load_frozen, sha, summarize, source_identity

class IndependentScoreTests(unittest.TestCase):
    def observation(self, case):
        return {'actual': {'status': case['expected_status'], 'scope': dict(BOUNDARY, source_sha256=sha(case['csv'].encode()))}}

    def test_frozen_specs_load_and_have_required_challenges(self):
        parser, _ = load_frozen('toolkit-cases')
        engine, _ = load_frozen('engine-cases')
        self.assertEqual(len(parser['cases']), 22)
        self.assertEqual(len(engine['cases']), 5)
        self.assertEqual(len({c['id'] for c in parser['cases']}), len(parser['cases']))

    def test_clean_loss_is_not_rejected_by_generic_scoring(self):
        case = {'id':'valid_loss','csv':'synthetic','dimension':'numerical','kind':'clean','expected_status':'NO_FINDINGS_REPORTED','rationale':'A loss is valid evidence.'}
        result = classify(case, self.observation(case))
        self.assertEqual(result['classification'], 'pass')
        self.assertFalse(result['false_rejection'])

    def test_false_clean_and_false_rejection_count_separately(self):
        cases, _ = load_frozen('toolkit-cases')
        valid = copy.deepcopy(cases['cases'][0]); bad = copy.deepcopy(cases['cases'][5])
        a = self.observation(valid); a['actual']['status'] = 'NOT_ASSESSABLE'
        b = self.observation(bad); b['actual']['status'] = 'NO_FINDINGS_REPORTED'
        totals = summarize([classify(valid, a), classify(bad, b)])
        self.assertEqual(totals['false_acceptance']['count'], 1)
        self.assertEqual(totals['false_acceptance']['denominator'], 1)
        self.assertEqual(totals['false_rejection']['count'], 1)
        self.assertEqual(totals['false_rejection']['denominator'], 1)

    def test_unsupported_never_inflates_pass_or_adversarial_denominator(self):
        spec, _ = load_frozen('toolkit-cases'); case = spec['cases'][-1]
        row = classify(case, self.observation(case)); summary = summarize([row])
        self.assertEqual(row['classification'], 'unsupported')
        self.assertEqual(summary['supported_cases'], 0)
        self.assertEqual(summary['false_acceptance']['denominator'], 0)
        self.assertEqual(summary['unsupported_coverage']['count'], 1)

    def test_false_provenance_is_failure_even_when_parser_status_matches(self):
        spec, _ = load_frozen('toolkit-cases'); case=spec['cases'][0]
        actual=self.observation(case); actual['actual']['scope']['source_authenticity']='verified'
        self.assertIn('overclaim_or_missing_scope:source_authenticity', classify(case,actual)['failures'])

    def test_invalid_evidence_with_findings_is_still_false_acceptance(self):
        spec,_=load_frozen('toolkit-cases');case=spec['cases'][5]
        actual=self.observation(case);actual['actual']['status']='FINDINGS_REPORTED'
        self.assertTrue(classify(case,actual)['false_acceptance'])

    def test_malformed_candidate_result_does_not_hide_other_cases(self):
        spec,_=load_frozen('toolkit-cases');case=spec['cases'][0]
        for value in (None,[],{'status':'NO_FINDINGS_REPORTED','scope':None},{'status':[],'scope':{}},{'status':{},'scope':{}}):
            row=classify(case,{'actual':value})
            self.assertEqual(row['classification'],'failure')
            self.assertTrue(row['failures'])

    def test_source_identity_refuses_executable_caches(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'verify_toolkit';p.mkdir();(p/'__init__.py').write_text('')
            cache=p/'__pycache__';cache.mkdir();(cache/'freqtrade.pyc').write_bytes(b'unpinned')
            with self.assertRaises(ValueError):source_identity(temp)

    def test_raw_newlines_and_bom_are_in_digest(self):
        spec,_=load_frozen('toolkit-cases'); case=spec['cases'][3]
        actual=self.observation(case)
        actual['actual']['scope']['source_sha256']=sha(case['csv'].removeprefix('\ufeff').replace('\r\n','\n').encode())
        self.assertIn('source_bytes_digest_mismatch', classify(case,actual)['failures'])

if __name__ == '__main__': unittest.main()
