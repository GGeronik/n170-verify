// SPDX-License-Identifier: Apache-2.0
import test from 'node:test';
import assert from 'node:assert/strict';
import { createPublicKey, verify, createHash } from 'node:crypto';
import { readFile, writeFile, mkdtemp, mkdir, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadFrozenCases, evaluateCase, summarizeCases, runAccountBenchmark, targetInventory } from '../account/run.mjs';

const fixtureDir = fileURLToPath(new URL('../account/fixtures/', import.meta.url));
const fixture = async name => JSON.parse(await readFile(path.join(fixtureDir, name), 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
function inspectWithNodeCrypto(profile) {
  const raw = Buffer.from(profile.public_key, 'base64url');
  assert.equal(raw[0], 4);
  assert.equal(raw.length, 65);
  assert.equal(profile.profile_id, sha(Buffer.concat([Buffer.from('n170.verify.profile-key.v3\n'), raw])));
  const key = createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: raw.subarray(1, 33).toString('base64url'), y: raw.subarray(33).toString('base64url') }, format: 'jwk' });
  return profile.stamps.map(stamp => {
    const bytes = Buffer.from(JSON.stringify(stamp.payload));
    return { hash: stamp.sha256 === sha(bytes), signature: verify('sha256', Buffer.concat([Buffer.from('n170.verify.stamp-signature.v4\n'), bytes]), { key, dsaEncoding: 'ieee-p1363' }, Buffer.from(stamp.signature, 'base64url')) };
  });
}

test('the expected-results freeze and every public fixture hash verify', async () => {
  const frozen = await loadFrozenCases();
  assert.equal(frozen.specification_sha256, '1b8d1a61305962a22ad2986c983644ae869ca01534b6d7db2bfcd68da21681ba');
  assert.equal(frozen.specification.cases.length, 31);
  assert.equal(new Set(frozen.specification.cases.map(c => c.id)).size, 31);
  assert.ok(frozen.specification.cases.every(c => c.oracle_method.length > 20));
});

test('valid and intentionally dishonest fixtures really carry valid independent cryptographic signatures', async () => {
  // These dishonest fixtures must fail because of meaning, arithmetic or schema,
  // not accidentally because the fixture writer produced a broken signature.
  for (const name of ['clean.json', 'loss.json', 'gap.json', 'false-authentication.json', 'false-completeness.json', 'false-timestamp.json', 'wrong-arithmetic.json', 'bad-coverage.json']) {
    assert.ok(inspectWithNodeCrypto(await fixture(name)).every(r => r.hash && r.signature), name);
  }
});

test('evidence and signature tamper fixtures break the intended independent crypto check', async () => {
  const payload = inspectWithNodeCrypto(await fixture('altered-payload.json'))[0];
  assert.equal(payload.hash, false);
  assert.equal(payload.signature, false);
  const signature = inspectWithNodeCrypto(await fixture('altered-signature.json'))[0];
  assert.equal(signature.hash, true);
  assert.equal(signature.signature, false);
});

test('hand-calculated fixtures preserve positive returns, legitimate losses and retained history', async () => {
  const clean = await fixture('clean.json');
  const loss = await fixture('loss.json');
  assert.equal(clean.stamps[0].payload.metrics.total_return_twr_e8, Math.round(((110 / 100) * (121 / 110) - 1) * 1e8));
  assert.equal(loss.stamps[0].payload.metrics.total_return_twr_e8, Math.round(((90 / 100) * (81 / 90) - 1) * 1e8));
  const gap = await fixture('gap.json');
  assert.deepEqual(gap.stamps[0], clean.stamps[0]);
  assert.equal(gap.stamps[1].payload.previous_sha256, clean.stamps[0].sha256);
});

test('semantic failures remain failures even if acceptance boolean matches', () => {
  const rejected = evaluateCase({ id: 'missing-period', expected: { accepted: false, required_issue: 'missing_period' } }, { accepted: false, issue_codes: [] });
  assert.equal(rejected.classification, 'assertion_failure');
  assert.equal(rejected.failures.length, 1);
  const accepted = evaluateCase({ id: 'authentication', expected: { accepted: true, provider_authenticated: false } }, { accepted: true, provider_authenticated: true });
  assert.equal(accepted.classification, 'assertion_failure');
});

test('false rates use separate supported denominators and exclude unsupported observations', () => {
  const cases = [
    evaluateCase({ id: 'bad', scope: 'parser', expected: { accepted: false } }, { accepted: true }),
    evaluateCase({ id: 'good', scope: 'parser', expected: { accepted: true } }, { accepted: false }),
    evaluateCase({ id: 'unknown', scope: 'unsupported', expected: { unsupported: true } }, { accepted: false }),
    evaluateCase({ id: 'missing-api', scope: 'parser', expected: { accepted: false } }, { unsupported: true, unsupported_reason: 'No interface.' }),
  ];
  const summary = summarizeCases(cases);
  assert.equal(summary.false_acceptance.count, 1);
  assert.equal(summary.false_acceptance.denominator, 1);
  assert.equal(summary.false_rejection.count, 1);
  assert.equal(summary.false_rejection.denominator, 1);
  assert.equal(summary.unsupported_coverage.count, 2);
  assert.equal(summary.unsupported_coverage.denominator, 4);
});

test('a deliberately permissive parser is detected and complete results survive worker failures', async () => {
  const directory = await mkdtemp(path.join(tmpdir(), 'n170-account-harness-'));
  try {
    await mkdir(path.join(directory, 'src'));
    await writeFile(path.join(directory, 'package.json'), '{"type":"module"}\n');
    await writeFile(path.join(directory, 'src/importer.js'), 'export async function importStatement() { return {canCalculate:true,source:{authenticated:false},rows:[{},{}],exceptions:[]}; }\n');
    const report = await runAccountBenchmark({ target: directory });
    assert.equal(report.summary.supported_cases, 6);
    assert.equal(report.summary.false_acceptance.count, 4);
    assert.equal(report.summary.false_acceptance.denominator, 4);
    assert.ok(report.summary.failures.some(f => f.id === 'account.import_missing_period'));
    assert.equal(report.reproducibility.identical, true);
    assert.equal(report.cases.length, 31);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('source identity rejects symlinks instead of silently hashing another candidate', async () => {
  const directory = await mkdtemp(path.join(tmpdir(), 'n170-account-identity-'));
  try {
    await mkdir(path.join(directory, 'src'));
    await writeFile(path.join(directory, 'actual.js'), '// fake source\n');
    await symlink('../actual.js', path.join(directory, 'src/calculator.js'));
    await assert.rejects(targetInventory(directory), /refuses symlink/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});
