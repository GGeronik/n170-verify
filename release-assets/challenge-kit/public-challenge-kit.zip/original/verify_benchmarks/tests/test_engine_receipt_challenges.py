import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from verify_benchmarks import engine
from verify_benchmarks.engine_fixture import generate
from verify_benchmarks.receipts import mutate, receipt_files
from verify_benchmarks.toolkit import load_frozen, source_identity

class EngineeringChallengeTests(unittest.TestCase):
    def test_fixture_is_reproducible_and_contains_real_future_dependency(self):
        with tempfile.TemporaryDirectory() as directory:
            a=generate(Path(directory)/'a');b=generate(Path(directory)/'b')
            self.assertEqual(receipt_files(a),receipt_files(b))
            future=(a/'strategies/ChallengeFuture.py').read_text()
            self.assertIn('shift(-1)',future)
            self.assertIn('dataframe["future_close"] > dataframe["close"]',future)
            candles=json.loads((a/'data/BTC_USDT-5m.json').read_text())
            self.assertEqual(len(candles),876)
            self.assertTrue(all(low <= opening <= high and low <= closing <= high for _,opening,high,low,closing,_ in candles))
            self.assertEqual(len({c[0] for c in candles}),876)

    def test_future_oracle_uses_identical_observed_prefix_and_changed_future(self):
        # Independent mathematical counterexample; no implementation under test.
        first=[100,101];second=[100,99]
        self.assertEqual(first[:1],second[:1])
        self.assertNotEqual(first[1]>first[0],second[1]>second[0])
        self.assertFalse(99 <= 90 <= 103)

    def test_artifact_mutation_retains_old_manifest_commitment(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);(p/'lookahead.csv').write_text('original\n')
            m={'artifacts':[{'path':'lookahead.csv'}]};(p/'manifest.json').write_text(json.dumps(m))
            old=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()
            returned=mutate(p,'artifact_bytes',old)
            self.assertEqual(old,returned)
            self.assertNotEqual((p/'lookahead.csv').read_text(),'original\n')

    def test_external_pin_substitution_uses_original_not_recomputed_pin(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);(p/'manifest.json').write_text(json.dumps({'run_id':'original'}))
            old=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()
            returned=mutate(p,'manifest_changed_external_pin',old)
            self.assertEqual(returned,old)
            self.assertNotEqual(returned,hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest())

    def test_untrusted_artifact_path_cannot_mutate_outside_copy(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);root=p/'copy';root.mkdir()
            outside=p/'outside-lookahead.csv';outside.write_bytes(b'preserve')
            for name in ('../outside-lookahead.csv',str(outside)):
                (root/'manifest.json').write_text(json.dumps({'artifacts':[{'path':name}]}))
                for mutation in ('artifact_bytes','artifact_missing'):
                    with self.assertRaises(ValueError):mutate(root,mutation,'unused')
                    self.assertEqual(outside.read_bytes(),b'preserve')

    def test_structural_attack_uses_new_pin_to_exercise_semantics(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);(p/'manifest.json').write_text(json.dumps({'state':'FINALIZED'}))
            old=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()
            returned=mutate(p,'unfinished_state',old)
            self.assertNotEqual(returned,old)
            self.assertEqual(returned,hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest())

    def test_receipt_spec_frozen_and_unknown_authenticity_unsupported(self):
        spec,_=load_frozen('receipt-cases')
        self.assertEqual(len(spec['cases']),10)
        self.assertEqual(spec['cases'][-1]['kind'],'unsupported')

    def test_claimed_expected_outcomes_without_worker_evidence_cannot_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();target=root/'target';(target/'verify_toolkit').mkdir(parents=True)
            (target/'verify_toolkit/__init__.py').write_text('')
            pin=source_identity(target)['sha256']
            def fake_launch(target,fixture,destination,image):
                destination.mkdir()
                m={'attempts':[{'id':str(i),'strategy':name,'outcome':outcome} for i,(name,outcome) in enumerate(engine.EXPECTED.items())],'engine':{},'summary':{}}
                (destination/'manifest.json').write_text(json.dumps(m))
                return m
            with patch.object(engine,'launch',fake_launch),patch.object(engine,'invoke',return_value={'reason_codes':['INVENTORY_AND_ACCOUNTING_CONSISTENT']}):
                report=engine.run(target,root/'runs','synthetic@sha256:'+'0'*64,pin)
            self.assertEqual(len(report['summary']['all_failures']),3)
            self.assertFalse(report['reproducibility']['identical'])

if __name__=='__main__':unittest.main()
