// SPDX-License-Identifier: Apache-2.0
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm, symlink } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  loadFrozenCases, caseInput, observeReport, evaluateCase, summarizeCases,
  runViewerBenchmark, targetInventory,
} from '../viewer/run.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const fixtureDirectory = path.resolve(here, '../viewer');

test('frozen specification has independent unique cases and expected denominators', async () => {
  const { specification, specification_sha256 } = await loadFrozenCases();
  assert.equal(specification_sha256, '1ce5b87099569c747284c5c150e6da5614df0f63b2681f9973a4c24168819822');
  assert.equal(specification.cases.length, 35);
  assert.equal(new Set(specification.cases.map(c => c.id)).size, 35);
  assert.equal(specification.cases.filter(c => c.kind === 'clean').length, 7);
  assert.equal(specification.cases.filter(c => c.kind === 'adversarial').length, 23);
  assert.equal(specification.cases.filter(c => c.expected.unsupported).length, 5);
  assert.equal(specification.fixture.rows[0].total_signals, 24);
});

test('changed freeze bytes refuse scoring instead of silently updating expectations', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-viewer-freeze-'));
  try {
    await writeFile(path.join(temporary, 'cases.sha256'), await readFile(path.join(fixtureDirectory, 'cases.sha256')));
    const original = await readFile(path.join(fixtureDirectory, 'cases.json'), 'utf8');
    await writeFile(path.join(temporary, 'cases.json'), original.replace('"total_signals": 24', '"total_signals": 25'));
    await assert.rejects(loadFrozenCases(temporary), /Frozen viewer expected results changed/);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});

test('fixture mutations preserve source fixture and exercise UTF-8 byte budget', async () => {
  const { specification } = await loadFrozenCases();
  const original = JSON.stringify(specification.fixture);
  const input = caseInput(specification, specification.cases.find(c => c.id === 'viewer.oversized_utf8_input'));
  assert.ok(Buffer.byteLength(input.text, 'utf8') > 4 * 1024 * 1024);
  assert.ok(input.text.length < 4 * 1024 * 1024);
  assert.doesNotThrow(() => JSON.parse(input.text));
  const duplicate = caseInput(specification, specification.cases.find(c => c.id === 'viewer.duplicate_json_field'));
  assert.match(duplicate.text, /"status":"FINDINGS_REPORTED","status":"NO_FINDINGS_REPORTED"/);
  assert.equal(JSON.stringify(specification.fixture), original);
});

test('false acceptance, false rejection and unsupported coverage have separate denominators', () => {
  const clean = { id: 'clean', scope: 'parser', kind: 'clean', expected: { accepted: true } };
  const invalid = { id: 'invalid', scope: 'parser', kind: 'adversarial', expected: { accepted: false } };
  const unsupported = { id: 'unsupported', scope: 'unsupported', kind: 'unsupported', expected: { unsupported: true } };
  const cases = [evaluateCase(clean, { accepted: false }), evaluateCase(invalid, { accepted: true }), evaluateCase(unsupported, { accepted: true })];
  const summary = summarizeCases(cases);
  assert.equal(summary.false_acceptance.count, 1);
  assert.equal(summary.false_acceptance.denominator, 1);
  assert.equal(summary.false_rejection.count, 1);
  assert.equal(summary.false_rejection.denominator, 1);
  assert.equal(summary.unsupported_coverage.count, 1);
  assert.equal(summary.unsupported_coverage.denominator, 3);
  assert.equal(summary.passed_cases, 0);
  assert.equal(summary.failures.length, 2);
});

test('label removal checks values as well as known keys and preserves numeric observations', async () => {
  const { specification } = await loadFrozenCases();
  const spec = specification.cases.find(c => c.id === 'viewer.default_export_omits_labels');
  const input = caseInput(specification, spec).report;
  const exported = structuredClone(input);
  delete exported.rows[0].filename;
  delete exported.rows[0].strategy;
  delete exported.rows[0].biased_indicators;
  exported.disclosure.strategy_labels_included = false;
  assert.equal(observeReport(exported, input, spec.operation).labels_omitted, false, 'private display label must also be removed');
  exported.rows[0].display_label = 'Strategy 1';
  const actual = observeReport(exported, input, spec.operation);
  assert.equal(actual.labels_omitted, true);
  assert.deepEqual(actual.total_signals, [24]);
  assert.equal(evaluateCase(spec, actual).classification, 'true_acceptance');
});

test('accepted report with lost boundary information is an assertion defect', async () => {
  const { specification } = await loadFrozenCases();
  const spec = specification.cases.find(c => c.id === 'viewer.clean_observation');
  const changed = structuredClone(specification.fixture);
  changed.scope.source_authenticity = 'verified';
  const result = evaluateCase(spec, observeReport(changed, specification.fixture, 'parse'));
  assert.equal(result.classification, 'assertion_failure');
  assert.equal(result.failures.length, 1);
  assert.match(result.failures[0], /scope:/);
});

test('absent baseline viewer reports unsupported in two repeatable fresh processes', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-viewer-absent-'));
  try {
    await writeFile(path.join(temporary, 'package.json'), '{"type":"module"}\n');
    const report = await runViewerBenchmark({ target: temporary });
    assert.equal(report.summary.supported_cases, 0);
    assert.equal(report.summary.unsupported_cases, 35);
    assert.equal(report.summary.passed_cases, 0);
    assert.equal(report.summary.false_acceptance.denominator, 0);
    assert.equal(report.summary.false_rejection.denominator, 0);
    assert.equal(report.reproducibility.identical, true);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});

test('permissive mock is detected without using any producer candidate', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-viewer-mutant-'));
  try {
    await mkdir(path.join(temporary, 'src'));
    await writeFile(path.join(temporary, 'package.json'), '{"type":"module"}\n');
    await writeFile(path.join(temporary, 'src/toolEvidence.js'), 'export const parseToolEvidence = JSON.parse; export const makeToolEvidenceExport = report => structuredClone(report);\n');
    const report = await runViewerBenchmark({ target: temporary });
    assert.equal(report.summary.false_acceptance.denominator, 23);
    assert.equal(report.summary.false_acceptance.count, 22, 'invalid JSON alone is rejected by JSON.parse');
    assert.equal(report.summary.false_rejection.count, 0);
    assert.equal(report.summary.assertion_failures, 1, 'mock must leak default labels');
    assert.equal(report.summary.unsupported_cases, 5);
    assert.equal(report.reproducibility.identical, true);
    await assert.rejects(runViewerBenchmark({ target: temporary, expectedSourceSha256: '0'.repeat(64) }), /Candidate identity differs/);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});

test('source identity refuses symlinked code', async () => {
  const temporary = await mkdtemp(path.join(os.tmpdir(), 'n170-viewer-link-'));
  try {
    await mkdir(path.join(temporary, 'src'));
    await writeFile(path.join(temporary, 'package.json'), '{"type":"module"}\n');
    await symlink(path.join(temporary, 'package.json'), path.join(temporary, 'src/toolEvidence.js'));
    await assert.rejects(targetInventory(temporary), /refuses symlink/);
  } finally { await rm(temporary, { recursive: true, force: true }); }
});
