"""Execute original frozen engine fixtures through an immutable producer runner.

Explicitly runs local synthetic code in a separately installed pinned image.
Reports detector outcomes separately from receipt verification and feasibility.
"""
from __future__ import annotations
import argparse
import csv
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from .toolkit import FIXTURES, canonical, load_frozen, sha, source_identity
from .receipts import invoke

EXPECTED={'ChallengeCausal':'NO_FINDINGS_REPORTED','ChallengeFuture':'FINDINGS_REPORTED','ChallengeSilent':'INSUFFICIENT'}
ENGINE_VERSION='2026.8'
ENGINE_REVISION='9f10e357a93c1dcf10c2a2b367659214d89c073e'
ENGINE_SOURCE_SHA256='a96f980268301b69f8fb6e423d27606ede3f174449f63ff672aebb48f97ac6de'


def verified_fixture():
    root=FIXTURES/'engine-inputs-v2'
    manifest_raw=(root/'fixture-manifest.json').read_bytes()
    pin=(FIXTURES/'engine-inputs-v2.sha256').read_text().split()[0]
    if sha(manifest_raw)!=pin:raise ValueError('Frozen engine fixture manifest changed')
    manifest=json.loads(manifest_raw);seen=set()
    for f in manifest['files']:
        name=f['path']
        if name.startswith('/') or any(p in {'','.','..'} for p in name.split('/')) or name in seen:raise ValueError('Unsafe fixture inventory')
        seen.add(name);p=root/name
        if p.is_symlink() or any(parent.is_symlink() for parent in p.parents):raise ValueError('Symlink fixture')
        raw=p.read_bytes()
        if len(raw)!=f['bytes'] or sha(raw)!=f['sha256']:raise ValueError('Frozen engine fixture bytes changed')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if actual!=seen|{'fixture-manifest.json'}:raise ValueError('Uninventoried fixture file')
    return root.resolve(),pin


def launch(target,fixture,destination,image):
    script='''import sys,json
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
from pathlib import Path
from verify_toolkit.runner import run_freqtrade
root=Path(sys.argv[2])
result=run_freqtrade(sys.argv[3],image=sys.argv[4],strategies={name:root/'strategies'/(name+'.py') for name in ['ChallengeCausal','ChallengeFuture','ChallengeSilent']},data=root/'data/BTC_USDT-5m.json',acknowledge_local_code=True,timeout_seconds=180,minimum_trade_amount=5,targeted_trade_amount=10,timerange='20260101-20260103')
print(json.dumps(result,sort_keys=True,allow_nan=False))'''
    p=subprocess.run([sys.executable,'-I','-S','-B','-c',script,str(Path(target).resolve()),str(fixture),str(destination),image],text=True,capture_output=True,timeout=600)
    (destination.parent/(destination.name+'-process.json')).write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2)+'\n')
    if p.returncode:raise RuntimeError('Engine runner subprocess failed; process evidence retained')
    return json.loads((destination/'manifest.json').read_bytes())


def semantic_receipt(root,manifest,fixture):
    observations=[]
    for a in manifest['attempts']:
        worker=root/'attempts'/a['id']/'output/worker-result.json'
        failures=[]
        try:
            w=json.loads(worker.read_bytes())
            if type(w) is not dict:raise ValueError('Invalid worker shape')
        except (OSError,ValueError):
            w={};failures.append('missing_or_invalid_worker_evidence')
        if w.get('strategy')!=a['strategy']:failures.append('worker_strategy_mismatch')
        expected_engine={'version':ENGINE_VERSION,'revision':ENGINE_REVISION,'source_sha256':ENGINE_SOURCE_SHA256}
        engine=w.get('engine',{})
        if type(engine) is not dict:engine={}
        if any(engine.get(k)!=v for k,v in expected_engine.items()) or engine.get('source_after_sha256')!=ENGINE_SOURCE_SHA256:
            failures.append('worker_engine_identity_mismatch')
        if type(engine.get('source_files')) is not list or sha(canonical(engine['source_files']))!=ENGINE_SOURCE_SHA256:
            failures.append('worker_engine_source_inventory_mismatch')
        input_rows=w.get('input_inventory',[])
        if type(input_rows) is not list:input_rows=[]
        input_rows=[x for x in input_rows if type(x) is dict]
        for path in ('data/BTC_USDT-5m.json',f"strategies/{a['strategy']}.py"):
            raw=(fixture/path).read_bytes()
            matching=[x for x in input_rows if x.get('path')==path]
            if matching!=[{'path':path,'size':len(raw),'sha256':sha(raw)}]:failures.append('frozen_input_identity_mismatch:'+path)
        if a['strategy']=='ChallengeSilent':
            if w.get('outcome')!='INSUFFICIENT':failures.append('missing_insufficient_worker_outcome')
        else:
            if w.get('outcome')!='COMPLETED':failures.append('missing_completed_worker_outcome')
            analysis=w.get('analysis',{})
            if type(analysis) is not dict:analysis={}
            try:
                csv_path=worker.with_name('lookahead.csv')
                rows=list(csv.DictReader(io.StringIO(csv_path.read_text())))
                if len(rows)!=1 or rows[0]['strategy']!=a['strategy']:raise ValueError('Wrong CSV strategy')
                row=rows[0]
                counts={k:int(row[k]) for k in ('total_signals','biased_entry_signals','biased_exit_signals')}
                if not 5 < counts['total_signals'] <= 10:raise ValueError('Insufficient analyzed signals')
                if any(analysis.get(k)!=v for k,v in counts.items()):raise ValueError('Worker/CSV counts differ')
                bias=row['has_bias'].lower()=='true'
                if row['has_bias'].lower() not in ('true','false') or analysis.get('has_bias') is not bias:raise ValueError('Worker/CSV bias differs')
                if bias!=(a['strategy']=='ChallengeFuture'):failures.append('unexpected_detector_bias_flag')
            except (OSError,ValueError,KeyError):failures.append('missing_or_inconsistent_analyzed_csv')
        observations.append({'strategy':a['strategy'],'outcome':a['outcome'],'analysis':w.get('analysis'),
            'engine':w.get('engine'), 'input_sources':[f for f in input_rows if str(f.get('path','')).startswith(('data/','strategies/'))],
            'evidence_failures':failures})
    return observations


def run(target,output,image,source_pin):
    if not re.fullmatch(r'[^\s]+@sha256:[0-9a-f]{64}',image):raise ValueError('Immutable image digest required')
    spec,spec_pin=load_frozen('engine-cases');fixture,fixture_pin=verified_fixture()
    source=source_identity(target)
    if source['sha256']!=source_pin:raise ValueError('Candidate source differs from retained pin')
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=False)
    manifests=[];semantics=[];verifications=[]
    for index in range(2):
        directory=output/f'run-{index+1}'
        m=launch(target,fixture,directory,image);manifests.append(m);semantics.append(semantic_receipt(directory,m,fixture))
        verification=invoke(target,directory,sha((directory/'manifest.json').read_bytes()))
        verifications.append(verification)
        if source_identity(target)!=source:raise ValueError('Candidate source changed during execution')
        verified_fixture()
    cases=[]
    for case,name in zip(spec['cases'][:3],EXPECTED):
        found=[a for a in manifests[0]['attempts'] if a['strategy']==name]
        actual=found[0]['outcome'] if len(found)==1 else 'MISSING_OR_DUPLICATE'
        failures=[] if actual==EXPECTED[name] else ['unexpected_engine_outcome']
        for index in range(2):
            evidence=[o for o in semantics[index] if o['strategy']==name]
            if len(evidence)!=1:failures.append(f'run_{index+1}:missing_or_duplicate_worker')
            else:failures.extend(f'run_{index+1}:'+f for f in evidence[0]['evidence_failures'])
            v=verifications[index]
            if type(v) is not dict or 'INVENTORY_AND_ACCOUNTING_CONSISTENT' not in v.get('reason_codes',[]):
                failures.append(f'run_{index+1}:receipt_integrity_not_established')
        executed=bool(found and found[0].get('argv')) and all(
            any(o['strategy']==name and o['engine'] for o in observations) for observations in semantics)
        cases.append(dict(case,expected=EXPECTED[name],actual=actual,supported=executed,
            classification=('pass' if not failures else 'failure') if executed else 'execution_error',
            failures=failures))
    # Stale-output integrity is evaluated separately by receipts.py; do not claim a detector pass.
    cases.append(dict(spec['cases'][3],supported=False,classification='unsupported',actual='See separate receipt integrity challenges',failures=[]))
    cases.append(dict(spec['cases'][4],supported=False,classification='unsupported',actual='Fill feasibility not assessed by lookahead analysis',failures=[]))
    hashes=[sha(canonical(s)) for s in semantics]
    report={'schema':'n170.challenge.engine-result.v1','specification_sha256':spec_pin,'fixture_manifest_sha256':fixture_pin,
        'candidate_identity':source,'image_reference':image,'engine_identity':manifests[0]['engine'],
        'method':'Two real pinned Freqtrade runner invocations on identical original synthetic data/strategies. Expectations frozen before target execution. No mocked detector.',
        'scope':'Exercised lookahead detector signals under original synthetic market metadata; not realistic investment research or source authentication.',
        'cases':cases,'runs':[{'directory':f'run-{i+1}','manifest_sha256':sha((output/f'run-{i+1}'/'manifest.json').read_bytes()),'summary':m['summary']} for i,m in enumerate(manifests)],
        'summary':{'total_cases':5,'supported_cases':sum(c['supported'] for c in cases),'unsupported_cases':2,
            'unexecuted_cases':sum(c['classification']=='execution_error' for c in cases),
            'false_acceptance':{'count':sum(c['supported'] and c['actual']=='NO_FINDINGS_REPORTED' for c in cases[1:3]),'denominator':sum(c['supported'] for c in cases[1:3]),'method':'Future-biased or insufficient exercised control incorrectly returned no findings. Unexecuted cases excluded.'},
            'false_rejection':{'count':int(cases[0]['supported'] and cases[0]['actual']!='NO_FINDINGS_REPORTED'),'denominator':int(cases[0]['supported'])},
            'all_failures':[{'id':c['id'],'failures':c['failures']} for c in cases if c['failures']]},
        'receipt_verifications':verifications,
        'reproducibility':{'semantic_sha256':hashes,'identical':hashes[0]==hashes[1] and not any(c['failures'] for c in cases),'runs':2,'raw_receipts_identical_expected':False,
            'method':'Compare per-strategy outcomes, full worker analysis, engine identity and strategy/data byte inventory. Local timestamps, run IDs, paths and process logs intentionally differ.'},
        'observations':semantics,'limitations':['Synthetic fixtures only. No real-market execution validation, broker evidence, external participant or comparative-superiority claim.','Freqtrade is separately installed GPL-3.0 software; no engine code copied into benchmark.']}
    (output/'result.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--toolkit-root',required=True);p.add_argument('--output',required=True)
    p.add_argument('--image',required=True);p.add_argument('--expected-source-sha256',required=True)
    a=p.parse_args();r=run(a.toolkit_root,a.output,a.image,a.expected_source_sha256)
    print(json.dumps(r['summary'],indent=2));raise SystemExit(bool(r['summary']['all_failures']) or not r['reproducibility']['identical'])
