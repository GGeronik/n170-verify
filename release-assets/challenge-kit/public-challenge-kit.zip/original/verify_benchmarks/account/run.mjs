#!/usr/bin/env node
// SPDX-License-Identifier: Apache-2.0
import { createHash, webcrypto } from 'node:crypto';
import { readFile, writeFile, readdir, lstat, realpath } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const executeFile = promisify(execFile);
const here = path.dirname(fileURLToPath(import.meta.url));
const script = fileURLToPath(import.meta.url);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

export async function loadFrozenCases() {
  const bytes = await readFile(path.join(here, 'cases.json'));
  const sha256 = digest(bytes);
  const expectedHash = (await readFile(path.join(here, 'cases.sha256'), 'utf8')).split(/\s/)[0];
  if (sha256 !== expectedHash) throw new Error('Frozen account expected results changed. Refusing to score.');
  const manifestBytes = await readFile(path.join(here, 'fixtures-manifest.json'));
  const manifest = JSON.parse(manifestBytes);
  if (manifest.expected_results_sha256 !== sha256) throw new Error('Fixtures were not bound to this expected-results freeze.');
  for (const entry of manifest.entries) {
    if (!/^fixtures\/[a-z-]+\.json$/.test(entry.path)) throw new Error('Unexpected fixture manifest path.');
    const value = await readFile(path.join(here, entry.path));
    if (value.length !== entry.bytes || digest(value) !== entry.sha256) throw new Error(`Frozen fixture changed: ${entry.path}`);
  }
  return { specification: JSON.parse(bytes), specification_sha256: sha256, fixture_manifest_sha256: digest(manifestBytes) };
}

// Hash the whole application source directory, metadata, and independent verifier.
// Excludes docs evidence dumps, caches, environments and node_modules. The exact
// inventory is returned; this does not assert that the app is a public allowlist.
export async function targetInventory(target) {
  const root = await realpath(target);
  const files = [];
  async function walk(relative) {
    const full = path.join(root, relative);
    let info;
    try { info = await lstat(full); } catch (error) { if (error.code === 'ENOENT') return; throw error; }
    if (info.isSymbolicLink()) throw new Error(`Source identity refuses symlink: ${relative}`);
    if (info.isDirectory()) {
      for (const name of (await readdir(full)).sort()) await walk(path.join(relative, name));
    } else if (info.isFile()) {
      const bytes = await readFile(full);
      files.push({ path: relative.split(path.sep).join('/'), bytes: bytes.length, sha256: digest(bytes) });
    }
  }
  for (const relative of ['src', 'package.json', 'package-lock.json', 'FORMAT.md', 'FORMAT-v3.md', 'scripts/verify-record.mjs']) await walk(relative);
  files.sort((a, b) => a.path.localeCompare(b.path));
  if (!files.length) throw new Error('No application source found at target.');
  return { root, method: 'SHA-256 of compact JSON entries sorted by relative path; each entry includes path, byte length and file SHA-256.', source_sha256: digest(JSON.stringify(files)), files };
}

export function evaluateCase(spec, actual) {
  const failures = [];
  const expected = spec.expected;
  let classification;
  if (expected.unsupported || actual.unsupported) classification = 'unsupported';
  else if (actual.adapter_error) { classification = 'execution_error'; failures.push(actual.adapter_error); }
  else {
    for (const [key, value] of Object.entries(expected)) {
      if (key === 'required_issue') {
        if (!actual.issue_codes?.includes(value)) failures.push(`Required issue ${value} absent.`);
      } else if (key === 'metrics') {
        for (const [metric, number] of Object.entries(value)) if (actual.metrics?.[metric] !== number) failures.push(`metrics.${metric}: expected ${JSON.stringify(number)}, actual ${JSON.stringify(actual.metrics?.[metric])}.`);
      } else if (!same(actual[key], value)) failures.push(`${key}: expected ${JSON.stringify(value)}, actual ${JSON.stringify(actual[key])}.`);
    }
    if (expected.accepted === false && actual.accepted === true) classification = 'false_acceptance';
    else if (expected.accepted === true && actual.accepted === false) classification = 'false_rejection';
    else if (failures.length) classification = 'assertion_failure';
    else classification = expected.accepted ? 'true_acceptance' : 'true_rejection';
  }
  return { id: spec.id, scope: spec.scope, method: spec.oracle_method, expected, actual, classification, failures, ...(classification === 'unsupported' ? { unsupported_reason: spec.unsupported_reason || actual.unsupported_reason } : {}) };
}

export function summarizeCases(cases) {
  const supported = cases.filter(c => c.classification !== 'unsupported');
  const mustReject = supported.filter(c => c.expected.accepted === false);
  const mustAccept = supported.filter(c => c.expected.accepted === true);
  const count = label => cases.filter(c => c.classification === label).length;
  return {
    total_cases: cases.length, supported_cases: supported.length, unsupported_cases: count('unsupported'),
    false_acceptance: { count: count('false_acceptance'), denominator: mustReject.length, denominator_definition: 'Supported cases independently specified to reject invalid input.' },
    false_rejection: { count: count('false_rejection'), denominator: mustAccept.length, denominator_definition: 'Supported cases independently specified to accept clean, valid-loss, or valid-with-limitations input.' },
    assertion_failures: count('assertion_failure'), execution_errors: count('execution_error'),
    passed_cases: count('true_acceptance') + count('true_rejection'),
    unsupported_coverage: { count: count('unsupported'), denominator: cases.length },
    scopes: Object.fromEntries([...new Set(cases.map(c => c.scope))].sort().map(scope => {
      const group = cases.filter(c => c.scope === scope);
      return [scope, { cases: group.length, supported: group.filter(c => c.classification !== 'unsupported').length, failures: group.filter(c => c.failures.length).map(c => c.id) }];
    })),
    failures: cases.filter(c => c.failures.length).map(c => ({ id: c.id, classification: c.classification, failures: c.failures })),
  };
}

async function executeCases(target, specification) {
  if (!globalThis.crypto?.subtle) globalThis.crypto = webcrypto;
  const modules = new Map();
  async function module(name, functions) {
    if (!modules.has(name)) {
      const file = path.join(target, 'src', name);
      try {
        await lstat(file);
        try { modules.set(name, { exports: await import(pathToFileURL(file).href) }); }
        catch (error) { modules.set(name, { adapter_error: `Cannot load ${name}: ${error.message}` }); }
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
        modules.set(name, { unsupported: true, unsupported_reason: `${name} is absent; adapter has no compatible interface.` });
      }
    }
    const loaded = modules.get(name);
    if (!loaded.exports) return loaded;
    const absent = functions.filter(name => typeof loaded.exports[name] !== 'function');
    return absent.length ? { unsupported: true, unsupported_reason: `Required exported interface absent: ${absent.join(', ')}` } : loaded;
  }
  const results = [];
  for (const spec of specification.cases) {
    let actual;
    const requirement = {
      calculate: ['calculator.js', ['buildStampObservationEvidence']],
      relative_metrics: ['calculator.js', ['calculateRecordMetricsV2', 'analyzeObservationSchedule']],
      import: ['importer.js', ['importStatement']], profile: ['trackRecord.js', ['inspectProfile']],
      review_html: ['reviewPackage.js', ['inspectReviewPackage']],
    }[spec.kind];
    if (!requirement) actual = { unsupported: true, unsupported_reason: spec.unsupported_reason, executed: false };
    else {
      const loaded = await module(...requirement);
      if (!loaded.exports) actual = loaded;
      else try {
        const implementation = loaded.exports;
        if (spec.kind === 'calculate') {
          const observed = await implementation.buildStampObservationEvidence(spec.input.csv, spec.input.frequency);
          actual = { accepted: true, metrics: observed.metrics, returns_e8: observed.relative_returns?.map(r => r.return_e8), external_cash_flow_count: observed.coverage?.external_cash_flow_count, annualization_status: observed.annualization?.status };
        } else if (spec.kind === 'relative_metrics') {
          actual = { accepted: true, metrics: await implementation.calculateRecordMetricsV2(spec.input.intervals, spec.input.frequency), annualization_status: (await implementation.analyzeObservationSchedule(spec.input.intervals, spec.input.frequency)).status };
        } else if (spec.kind === 'import') {
          const observed = await implementation.importStatement(spec.input.csv, spec.input.options);
          actual = { accepted: observed.canCalculate, source_authenticated: observed.source?.authenticated, observations: observed.rows?.length, issue_codes: observed.exceptions?.filter(e => e.severity === 'error').map(e => e.code).sort() };
        } else {
          const json = await readFile(path.join(here, 'fixtures', spec.input.fixture), 'utf8');
          const options = spec.input.previous_fixture ? { previousProfile: await readFile(path.join(here, 'fixtures', spec.input.previous_fixture), 'utf8') } : {};
          const observed = spec.kind === 'profile'
            ? await implementation.inspectProfile(json, options)
            : await implementation.inspectReviewPackage(`${spec.input.prefix}<script id="n170-evidence" type="application/json">${json}</script>`, options);
          actual = { accepted: true, provider_authenticated: observed.checks?.provider_authenticated, independent_timestamp: observed.checks?.independent_timestamp, identity_established: observed.checks?.identity_established, gaps: observed.summary?.gaps, previous_copy_status: observed.checks?.previous_copy?.status };
        }
      } catch (error) {
        actual = { accepted: false, error_name: error.name, error: error.message };
      }
    }
    results.push(evaluateCase(spec, actual));
  }
  return results;
}

async function worker(target) {
  const frozen = await loadFrozenCases();
  const identity = await targetInventory(target);
  const cases = await executeCases(identity.root, frozen.specification);
  const after = await targetInventory(target);
  if (identity.source_sha256 !== after.source_sha256) throw new Error('Target changed while benchmark was running.');
  return { specification_sha256: frozen.specification_sha256, fixture_manifest_sha256: frozen.fixture_manifest_sha256, target: identity, cases, summary: summarizeCases(cases) };
}

export async function runAccountBenchmark({ target }) {
  if (!target) throw new Error('target application directory is required');
  // Sequential fresh processes avoid shared JS module caches hiding divergence.
  const runs = [];
  for (let run = 0; run < 2; run++) {
    const { stdout } = await executeFile(process.execPath, [script, '--worker', '--target', path.resolve(target)], { maxBuffer: 8 * 1024 * 1024, timeout: 120000 });
    runs.push(JSON.parse(stdout));
  }
  const resultHashes = runs.map(r => digest(JSON.stringify(r)));
  const differing = runs[0].cases.filter((c, i) => !same(c, runs[1].cases[i])).map(c => c.id);
  return {
    schema: 'n170.challenge.account.report.v1', benchmark: 'Independent synthetic account arithmetic, parser conformance and evidence verification',
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    ...runs[0],
    reproducibility: { method: 'Two sequential fresh Node.js processes against identical frozen fixtures; exact JSON outcomes and source identity compared. No random output, clock, network or private key is used in scoring.', runs: 2, result_sha256: resultHashes, identical: resultHashes[0] === resultHashes[1], differing_case_ids: differing },
    limitations: ['Engineering challenge, not an external audit or outside-user review.', 'Parser conformance is not broker source authentication or real-engine detector performance.', 'Synthetic records do not validate live account performance, economic completeness, execution feasibility or investment skill.', 'False acceptance and rejection rates apply only to these enumerated supported cases and denominators.', 'Node module interface tests do not exercise browser UI, accessibility, persistence or deployment.'],
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === script) {
  try {
    const argv = process.argv.slice(2);
    const get = name => { const i = argv.indexOf(name); return i < 0 ? undefined : argv[i + 1]; };
    const target = get('--target');
    if (!target) throw new Error('Usage: node verify_benchmarks/account/run.mjs --target APP_DIRECTORY [--output REPORT.json]');
    const report = argv.includes('--worker') ? await worker(target) : await runAccountBenchmark({ target });
    const text = JSON.stringify(report, null, 2) + '\n';
    if (get('--output')) await writeFile(path.resolve(get('--output')), text, { flag: 'wx' });
    else process.stdout.write(text);
    // Workers always deliver complete scored outcomes. The outer CLI owns the
    // failure exit code so a known defect cannot discard its own report.
    if (!argv.includes('--worker') && (report.summary.failures.length || report.reproducibility?.identical === false)) process.exitCode = 1;
  } catch (error) { process.stderr.write(`Account benchmark error: ${error.message}\n`); process.exitCode = 2; }
}
