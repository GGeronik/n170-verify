// SPDX-License-Identifier: Apache-2.0
// One-time ORIGINAL SYNTHETIC fixture authoring. Never imports target modules.
// Private signing material is ephemeral and is never exported or written.
import { generateKeyPairSync, createHash, sign } from 'node:crypto';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const directory = path.join(here, 'fixtures');
const sha = value => createHash('sha256').update(value).digest('hex');
const casesBytes = await readFile(path.join(here, 'cases.json'));
const expectedHash = (await readFile(path.join(here, 'cases.sha256'), 'utf8')).split(/\s/)[0];
if (sha(casesBytes) !== expectedHash) throw new Error('Expected-results freeze is missing or changed.');
if ((await readdir(directory)).length) throw new Error('Refusing to overwrite frozen signed fixtures. Create a new benchmark revision explicitly.');

const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
const jwk = publicKey.export({ format: 'jwk' });
const rawPublicKey = Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url')]);
const profileId = sha(Buffer.concat([Buffer.from('n170.verify.profile-key.v3\n'), rawPublicKey]));
const displayName = 'Original synthetic benchmark - not an account';
const profile = stamps => ({ schema_version: 'n170.verify.track-record.v4', profile_id: profileId, display_name: displayName, public_key: rawPublicKey.toString('base64url'), stamps });

// Field order follows the public FORMAT.md v4 contract. Metrics are independent
// constants frozen in cases.json, not outputs from the target calculator.
function payload({ returns = [10000000, 10000000], start = 1, sequence = 1, previous = null, loss = false } = {}) {
  const day = n => `2025-01-${String(n).padStart(2, '0')}`;
  return {
    schema_version: 'n170.verify.performance-stamp.v4', calculation_version: '2.0.0',
    sequence, profile_id: profileId, display_name: displayName, previous_sha256: previous,
    source_kind: 'synthetic_demo', provider_authenticated: false, independent_timestamp: false,
    period: { start: day(start), end: day(start + 2) }, periods_per_year: 365,
    relative_returns: returns.map((r, i) => ({ start: day(start + i), end: day(start + i + 1), return_e8: r })),
    coverage: { nav_observations: 3, return_observations: 2, external_cash_flow_count: 0 },
    metrics: { total_return_twr_e8: loss ? -19000000 : 21000000, annualized_volatility_e8: null, max_drawdown_e8: loss ? -19000000 : 0 },
    serialization_version: '1.0.0', event_type: 'performance', correction: null,
    provenance: { kind: 'manual', format: 'manual-nav-flow', original_sha256: null, source_sha256: null, normalized_sha256: null,
      mapping: [], account_scope: 'Entirely synthetic fixture, no real account', currency: 'USD', completeness: 'not_established', corrections: [], reviewed: true },
  };
}
function signed(p) {
  const bytes = Buffer.from(JSON.stringify(p));
  return { payload: p, sha256: sha(bytes), signature: sign('sha256', Buffer.concat([Buffer.from('n170.verify.stamp-signature.v4\n'), bytes]), { key: privateKey, dsaEncoding: 'ieee-p1363' }).toString('base64url') };
}
const first = signed(payload());
const clean = profile([first]);
const gap = profile([first, signed(payload({ start: 10, sequence: 2, previous: first.sha256 }))]);
const fixtures = {
  'clean.json': clean,
  'loss.json': profile([signed(payload({ returns: [-10000000, -10000000], loss: true }))]),
  'gap.json': gap,
};
for (const [name, mutate] of [
  ['bad-coverage.json', p => { p.coverage.nav_observations = 99; }],
  ['false-authentication.json', p => { p.provider_authenticated = true; }],
  ['false-completeness.json', p => { p.provenance.completeness = 'established'; }],
  ['false-timestamp.json', p => { p.independent_timestamp = true; }],
  ['wrong-arithmetic.json', p => { p.metrics.total_return_twr_e8 = 22000000; }],
]) {
  const p = payload(); mutate(p); fixtures[name] = profile([signed(p)]);
}
fixtures['altered-payload.json'] = structuredClone(clean);
fixtures['altered-payload.json'].stamps[0].payload.provenance.currency = 'EUR';
fixtures['altered-signature.json'] = structuredClone(clean);
const broken = Buffer.from(first.signature, 'base64url'); broken[10] ^= 1;
fixtures['altered-signature.json'].stamps[0].signature = broken.toString('base64url');
fixtures['duplicate-field.json'] = JSON.stringify(clean).replace('"profile_id":', '"profile_id":"duplicate intentionally invalid","profile_id":');
const entries = [];
for (const [name, fixture] of Object.entries(fixtures).sort(([a], [b]) => a.localeCompare(b))) {
  const bytes = Buffer.from((typeof fixture === 'string' ? fixture : JSON.stringify(fixture, null, 2)) + '\n');
  await writeFile(path.join(directory, name), bytes, { flag: 'wx' });
  entries.push({ path: `fixtures/${name}`, bytes: bytes.length, sha256: sha(bytes) });
}
await writeFile(path.join(here, 'fixtures-manifest.json'), JSON.stringify({ schema: 'n170.challenge.account.fixtures.v1', expected_results_sha256: expectedHash, key_material: 'Fresh ephemeral P-256 key; only public key and public signatures retained. No private key file exists.', entries }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ specification_sha256: expectedHash, fixture_count: entries.length }));
