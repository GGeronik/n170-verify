"""Original simple challenge data/strategies, independent of producer fixtures.

No engine import is needed to generate the fixture or calculate its causal oracle.
A generated strategy is opt-in local code for a separately installed Freqtrade.
"""
import argparse
import hashlib
import json
from pathlib import Path

PRELUDE='''# SPDX-License-Identifier: Apache-2.0
# Original synthetic engineering fixture, not investment advice or market evidence.
from freqtrade.strategy import IStrategy

class NAME(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"
    startup_candle_count = 3
    minimal_roi = {"0": 100.0}
    stoploss = -0.99
    can_short = False
    def populate_indicators(self, dataframe, metadata):
        dataframe["clock"] = (dataframe["date"].dt.hour * 12 + dataframe["date"].dt.minute // 5) % 8
INDICATOR
        return dataframe
    def populate_entry_trend(self, dataframe, metadata):
ENTRY
        return dataframe
    def populate_exit_trend(self, dataframe, metadata):
        dataframe.loc[dataframe["clock"] == 3, "exit_long"] = 1
        return dataframe
'''


def generate(destination):
    root=Path(destination);root.mkdir(parents=True,exist_ok=False)
    (root/'strategies').mkdir();(root/'data').mkdir()
    strategies={
      'ChallengeCausal':('        dataframe["past_close"] = dataframe["close"].shift(1)',
         '        dataframe.loc[dataframe["clock"] == 0, "enter_long"] = 1'),
      'ChallengeFuture':('        dataframe["future_close"] = dataframe["close"].shift(-1)',
         '        dataframe.loc[(dataframe["clock"] == 0) & (dataframe["future_close"] > dataframe["close"]), "enter_long"] = 1'),
      'ChallengeSilent':('        dataframe["past_close"] = dataframe["close"].shift(1)',
         '        dataframe["enter_long"] = 0'),
    }
    for name,(indicator,entry) in strategies.items():
        (root/'strategies'/f'{name}.py').write_text(PRELUDE.replace('NAME',name).replace('INDICATOR',indicator).replace('ENTRY',entry))
    candles=[]
    # Integer-valued periodic paths avoid platform-dependent transcendental math.
    for i in range(876):
        price=100+(i%8)
        candles.append([1767222000000+i*300000,price,price+2,price-1,price+1,1000])
    (root/'data'/'BTC_USDT-5m.json').write_text(json.dumps(candles,separators=(',',':'))+'\n')
    oracle={'schema':'n170.challenge.engine-fixture.v1','original_synthetic':True,
      'rights':'Original Apache-2.0 artificial candles and strategy source; no real-market data.',
      'expectations':{'ChallengeCausal':'NO_FINDINGS_REPORTED on exercised signals',
       'ChallengeFuture':'FINDINGS_REPORTED for deliberate future_close and future-dependent entry',
       'ChallengeSilent':'INSUFFICIENT; no clean overall claim'},
      'independent_oracles':{'future_prefix':[100,101],'altered_future_prefix':[100,99],
       'entry_at_t0_before':True,'entry_at_t0_after':False,
       'information_through_t0_identical':True,'causal_indicator_at_t0_unchanged':True,
       'silent_entry_count':0,'infeasible_fill':{'low':99,'high':103,'buy':90,'feasible':False}},
      'limitations':['A lookahead detector does not establish execution realism or source authenticity.',
                      'Every value is invented; no realistic investment-study claim.']}
    (root/'oracle.json').write_text(json.dumps(oracle,indent=2,sort_keys=True)+'\n')
    files=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file()]
    (root/'fixture-manifest.json').write_text(json.dumps({'schema':'n170.challenge.fixture-inventory.v1','files':files},indent=2,sort_keys=True)+'\n')
    return root

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination');a=p.parse_args();print(generate(a.destination))
