"""Independent synthetic challenges for N170 Verify. Original Apache-2.0 code."""
