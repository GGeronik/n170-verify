# SPDX-License-Identifier: Apache-2.0
# Original synthetic engineering fixture, not investment advice or market evidence.
from freqtrade.strategy import IStrategy

class ChallengeSilent(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"
    startup_candle_count = 3
    minimal_roi = {"0": 100.0}
    stoploss = -0.99
    can_short = False
    def populate_indicators(self, dataframe, metadata):
        dataframe["clock"] = (dataframe["date"].dt.hour * 12 + dataframe["date"].dt.minute // 5) % 8
        dataframe["past_close"] = dataframe["close"].shift(1)
        return dataframe
    def populate_entry_trend(self, dataframe, metadata):
        dataframe["enter_long"] = 0
        return dataframe
    def populate_exit_trend(self, dataframe, metadata):
        dataframe.loc[dataframe["clock"] == 3, "exit_long"] = 1
        return dataframe
