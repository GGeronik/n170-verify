# SPDX-License-Identifier: Apache-2.0
# Original synthetic engineering fixture, not investment advice or market evidence.
from freqtrade.strategy import IStrategy

class ChallengeFuture(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"
    startup_candle_count = 3
    minimal_roi = {"0": 100.0}
    stoploss = -0.99
    can_short = False
    def populate_indicators(self, dataframe, metadata):
        dataframe["clock"] = (dataframe["date"].astype("int64") // 300000000000) % 8
        dataframe["future_close"] = dataframe["close"].shift(-1)
        return dataframe
    def populate_entry_trend(self, dataframe, metadata):
        dataframe.loc[(dataframe["clock"] == 0) & (dataframe["future_close"] > dataframe["close"]), "enter_long"] = 1
        return dataframe
    def populate_exit_trend(self, dataframe, metadata):
        dataframe.loc[dataframe["clock"] == 3, "exit_long"] = 1
        return dataframe
