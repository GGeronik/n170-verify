"""Run frozen benchmark against an explicit immutable source candidate."""
import argparse
import json
from pathlib import Path
from .toolkit import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolkit-root', type=Path, required=True)
    parser.add_argument('--expected-source-sha256')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = run(args.toolkit_root, args.expected_source_sha256)
    text = json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n'
    if args.output:
        with args.output.open('x') as output:
            output.write(text)
    print(text)
    return 1 if result['summary']['all_failures'] or result['reproducibility']['failures'] else 0

if __name__ == '__main__':
    raise SystemExit(main())
