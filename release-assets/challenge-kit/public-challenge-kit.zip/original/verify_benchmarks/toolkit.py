"""Independent parser challenges. Never score CSV parsing as engine detection."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys

FIXTURES = Path(__file__).with_name('fixtures')
BOUNDARY = {'tool_execution': 'not_performed', 'source_authenticity': 'unverified',
            'context_authenticity': 'unverified', 'run_completeness': 'not_established',
            'run_freshness': 'not_established'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def load_frozen(name):
    path = FIXTURES / (name + '.json')
    data = path.read_bytes()
    expected = (FIXTURES / (name + '.sha256')).read_text().split()[0]
    if sha(data) != expected:
        raise ValueError('Frozen challenge specification changed: ' + name)
    return json.loads(data), expected


def source_identity(root):
    root = Path(root).resolve()
    folder = root / 'verify_toolkit'
    if not folder.is_dir() or folder.is_symlink():
        raise ValueError('Target must contain a regular verify_toolkit directory')
    files = []
    for path in sorted(folder.rglob('*')):
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            raise ValueError('Unpinned executable bytecode cache in target source')
        if path.is_symlink():
            raise ValueError('Symlink in target source')
        if path.is_file():
            data = path.read_bytes()
            files.append({'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': sha(data)})
    return {'schema': 'n170.challenge.source-identity.v1', 'sha256': sha(canonical(files)), 'files': files}


def worker(target, cases):
    # Target executes only in a separate interpreter with site and env imports disabled.
    script = """
import sys, json
sys.dont_write_bytecode = True
sys.path.insert(0, sys.argv[1])
from verify_toolkit.freqtrade import assess_lookahead
cases = json.load(sys.stdin)
result = []
for case in cases:
    try:
        actual = assess_lookahead(case['csv'], context=case.get('context'))
        result.append({'id': case['id'], 'actual': actual})
    except Exception as exc:
        result.append({'id': case['id'], 'error_type': type(exc).__name__})
print(json.dumps(result, sort_keys=True, allow_nan=False))
"""
    result = subprocess.run([sys.executable, '-I', '-S', '-B', '-c', script, str(Path(target).resolve())],
                            input=json.dumps(cases), text=True, capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError('Candidate worker failed with exit ' + str(result.returncode))
    output = json.loads(result.stdout)
    if not isinstance(output, list) or [c.get('id') for c in output] != [c['id'] for c in cases]:
        raise ValueError('Candidate adapter result shape is invalid')
    return output


def classify(case, observation):
    actual = observation.get('actual', {})
    failures = []
    if type(actual) is not dict:
        actual = {}
        failures.append('invalid_result_shape')
    status = actual.get('status')
    if type(status) is not str:
        status = None
        failures.append('invalid_status_shape')
    if observation.get('error_type'):
        failures.append('candidate_exception:' + observation['error_type'])
    if status != case['expected_status']:
        failures.append('unexpected_status')
    scope = actual.get('scope', {})
    if type(scope) is not dict:
        scope = {}
        failures.append('invalid_scope_shape')
    for name, expected in BOUNDARY.items():
        if scope.get(name) != expected:
            failures.append('overclaim_or_missing_scope:' + name)
    if scope.get('source_sha256') != sha(case['csv'].encode()):
        failures.append('source_bytes_digest_mismatch')
    unsupported = case.get('supported') is False
    # Unsupported dimensions are counted separately even if guard labels behave well.
    result = 'unsupported' if unsupported else ('pass' if not failures else 'failure')
    return {'id': case['id'], 'dimension': case['dimension'], 'kind': case['kind'],
            'supported': not unsupported, 'classification': result,
            'expected': case['expected_status'], 'actual': status,
            'boundary_failures': failures, 'failures': failures,
            'false_acceptance': bool(not unsupported and case['kind'] == 'adversarial' and status in {'NO_FINDINGS_REPORTED', 'FINDINGS_REPORTED'}),
            'false_rejection': bool(not unsupported and case['kind'] == 'clean' and status == 'NOT_ASSESSABLE'),
            'rationale': case['rationale'], 'observation': actual}


def summarize(cases):
    supported = [c for c in cases if c['supported']]
    adverse = [c for c in supported if c['kind'] == 'adversarial']
    valid = [c for c in supported if c['kind'] == 'clean']
    return {
        'total_cases': len(cases), 'supported_cases': len(supported),
        'unsupported_cases': len(cases) - len(supported),
        'false_acceptance': {'count': sum(c['false_acceptance'] for c in adverse), 'denominator': len(adverse),
            'method': 'Invalid or incomplete supplied evidence incorrectly given either assessable status; additional boundary defects listed separately.'},
        'false_rejection': {'count': sum(c['false_rejection'] for c in valid), 'denominator': len(valid),
            'method': 'Valid supported supplied observations incorrectly marked NOT_ASSESSABLE; valid findings are not rejection.'},
        'supported_outcome_failures': [c['id'] for c in supported if c['failures']],
        'all_failures': [{'id': c['id'], 'failures': c['failures']} for c in cases if c['failures']],
        'unsupported_coverage': {'count': len(cases)-len(supported), 'denominator': len(cases),
            'case_ids': [c['id'] for c in cases if not c['supported']]},
    }


def run(target, expected_source_sha256=None):
    spec, spec_sha = load_frozen('toolkit-cases')
    identity = source_identity(target)
    if expected_source_sha256 and identity['sha256'] != expected_source_sha256:
        raise ValueError('Candidate identity does not match externally supplied pin')
    first, second = worker(target, spec['cases']), worker(target, spec['cases'])
    final_identity = source_identity(target)
    if identity != final_identity:
        raise ValueError('Candidate source changed during evaluation')
    cases = [classify(c, a) for c, a in zip(spec['cases'], first)]
    repeat_failures = [a['id'] for a, b in zip(first, second) if canonical(a) != canonical(b)]
    return {'schema': 'n170.challenge.toolkit-result.v1', 'specification_sha256': spec_sha,
            'synthetic': True, 'external_review': False, 'scope': spec['scope'], 'method': spec['method'],
            'candidate_identity': identity, 'cases': cases, 'summary': summarize(cases),
            'reproducibility': {'equal_cases': len(cases)-len(repeat_failures), 'denominator': len(cases),
                'independent_processes': 2, 'first_output_sha256': sha(canonical(first)),
                'second_output_sha256': sha(canonical(second)), 'failures': repeat_failures,
                'method': 'Byte-identical canonical observations from two isolated standard-library Python processes; no claim of engine rerun.'}}
