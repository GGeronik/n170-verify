#!/usr/bin/env node
// SPDX-License-Identifier: Apache-2.0
import { webcrypto } from 'node:crypto';
import { readFile, lstat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import { SPEC_SHA256, SUPPLEMENT_SHA256, sha256, specification, supplementalSpecification, score, summarize, writeExclusive, options } from './common.mjs';
import { targetInventory } from '../account/run.mjs';

const execute = promisify(execFile);
const script = fileURLToPath(import.meta.url);
const marker = 'WAVE2_PRIVATE_SOURCE_SENTINEL_9fb641e2';
const csv = (nav, flow = nav.map(() => '0'), dates = nav.map((_, i) => `2026-01-${String(i + 1).padStart(2, '0')}`)) =>
  'date,nav,external_flow\n' + nav.map((value, i) => `${dates[i]},${value},${flow[i]}`).join('\n');
const BASE = { currency: 'USD', frequency: 365, accountScope: 'Original synthetic one-account scope', flowTimingConfirmed: true, expectedSchedule: 'calendar_daily', flowActivity: 'reviewed_no_hidden', flowTiming: 'interval_end', format: 'n170' };

// Inputs come only from the frozen independent oracle or direct extensions of its
// malformed-row/source cases. None are copied from producer tests.
function inputFor(spec) {
  const f = spec.fixture;
  if (f.nav && spec.expected.resolved === true) return { ...BASE, input: csv(f.nav, f.end_flows), fileName: 'synthetic-observations.csv' };
  switch (spec.id) {
    case 'reconcile.gap': return { ...BASE, input: csv(['100', '110'], undefined, f.observations) };
    case 'reconcile.rejected-row': return { ...BASE, input: csv(['100', '110']) + '\nnot-a-date,malformed,0' };
    case 'reconcile.duplicate-observation': return { ...BASE, input: csv(['100', '100', '110'], undefined, ['2026-01-01', '2026-01-02', '2026-01-02']) };
    case 'reconcile.unsupported-timing': return { ...BASE, input: csv(['100', '160'], ['0', '50']), flowTiming: 'intraperiod' };
    case 'reconcile.source-inventory': return { ...BASE, input: csv(['100', '110']), sources: [{ text: csv(['100', '110']), fileName: 'unused.csv', disposition: 'excluded', reason: 'Original synthetic unrelated duplicate source retained for explicit owner review.' }] };
    default: return null;
  }
}

// Independently compose disclosed integer returns using exact rational BigInt.
// This does not call any target metric helper. Frozen oracle values stay fixed.
function composedMetrics(intervals) {
  const unit = 100000000n;
  const rounded = (n, d) => {
    let q = n / d, r = n % d;
    if (r < 0n) { q--; r += d; }
    return Number(q + (r * 2n >= d ? 1n : 0n));
  };
  let n = 1n, d = 1n, pn = 1n, pd = 1n, ddn = 0n, ddd = 1n;
  for (const interval of intervals) {
    if (!Number.isSafeInteger(interval.return_e8)) return null;
    n *= unit + BigInt(interval.return_e8); d *= unit;
    if (n * pd > pn * d) { pn = n; pd = d; }
    const nextN = n * pd - pn * d, nextD = d * pn;
    if (nextN * ddd < ddn * nextD) { ddn = nextN; ddd = nextD; }
  }
  return { return_e8: rounded((n - d) * unit, d), drawdown_e8: rounded(ddn * unit, ddd) };
}

function checks(spec, result) {
  const checks = [];
  const add = (ok, message) => checks.push({ ok, message });
  const blocked = result.canCalculate === false && result.selected_scope_status === 'blocked';
  const intervals = Array.isArray(result.intervals) ? result.intervals : [];
  if (spec.expected.resolved === true) {
    add(result.canCalculate === true, 'Valid independently specified interval must calculate.');
    add(intervals.length > 0 && intervals.every(i => i.status === 'calculable'), 'Every supplied valid interval must resolve.');
    const metrics = composedMetrics(intervals);
    for (const k of ['return_e8', 'drawdown_e8']) if (k in spec.expected) add(metrics?.[k] === spec.expected[k], `${k}: expected ${spec.expected[k]}, actual ${metrics?.[k]}.`);
  }
  if (spec.expected.complete === false) {
    add(blocked, 'Contradictory or incomplete selected scope must remain blocked.');
    add(Array.isArray(result.blocking_issues) && result.blocking_issues.length > 0, 'Blocking reason must be retained.');
    if (spec.id === 'reconcile.gap') add(intervals.some(i => i.status === 'unresolved' && i.return_e8 === null), 'A supplied observation gap must remain an unresolved interval with no fabricated return.');
    if (spec.id === 'reconcile.rejected-row') add(result.source_inventory?.some(s => s.text?.includes('not-a-date,malformed,0')), 'Malformed supplied row must remain in retained raw source inventory.');
  }
  if (spec.id === 'reconcile.source-inventory') {
    add(Array.isArray(result.source_inventory) && result.source_inventory.length === 2 && result.source_inventory.some(s => s.file_name === 'unused.csv'), 'Active and supplied excluded source must both remain inventoried.');
    add(result.source_inventory?.every(s => typeof s.sha256 === 'string' && typeof s.byte_length === 'number'), 'Every retained source must bind bytes.');
  }
  return checks;
}

async function executeCases(target) {
  if (!globalThis.crypto?.subtle) globalThis.crypto = webcrypto;
  const spec = await specification();
  const supplement = await supplementalSpecification();
  const selected = [...spec.cases.filter(c => c.dimension === 'reconciliation' || c.id === 'privacy.public-projection'), ...supplement.cases];
  const moduleFile = path.join(target, 'src/reconciliation.js');
  let adapter;
  try { await lstat(moduleFile); adapter = await import(pathToFileURL(moduleFile).href); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return selected.map(c => score(c, { unsupported: true, unsupported_reason: 'Candidate does not implement the frozen reconciliation API.' }));
  }
  const output = [];
  for (const entry of selected) {
    if (entry.classification === 'unsupported') { output.push(score(entry, {})); continue; }
    try {
      if (entry.id.startsWith('followup.')) {
        const f = entry.fixture;
        if (entry.id === 'followup.capture-byte-identity') {
          const bytes = new TextEncoder().encode(f.text);
          const result = await adapter.captureSource({ ...BASE, bytes, fileName: 'synthetic-bom-crlf.csv' });
          output.push(score(entry, { accepted: true, result }, [
            { ok: result.sha256 === sha256(bytes), message: 'Captured digest must hash exact BOM/CRLF input bytes.' },
            { ok: result.byte_length === bytes.length, message: 'Captured byte count differs from exact UTF-8 input.' },
            { ok: result.text === f.text, message: 'Captured decoded source must retain BOM and CRLF.' },
          ]));
        } else if (entry.id === 'followup.opening-dependency') {
          const a = await adapter.reconcileAccount({ ...BASE, input: csv(f.original_nav) });
          const b = await adapter.reconcileAccount({ ...BASE, input: csv(f.modified_nav) });
          output.push(score(entry, { accepted: a.canCalculate && b.canCalculate, original: a, changed: b }, [
            { ok: a.intervals?.[0]?.dependency_sha256 && a.intervals[0].dependency_sha256 !== b.intervals?.[0]?.dependency_sha256, message: 'Changing opening NAV must change interval dependency hash.' },
            { ok: a.source_inventory?.[0]?.sha256 && a.source_inventory[0].sha256 !== b.source_inventory?.[0]?.sha256, message: 'Changing opening NAV must change source hash.' },
          ]));
        } else {
          const input = { ...BASE, input: csv(f.nav, f.end_flows, f.dates), ...(f.period ? { period: f.period } : {}), ...(f.flowActivity ? { flowActivity: f.flowActivity } : {}) };
          const result = await adapter.reconcileAccount(input);
          const assertions = [{ ok: result.canCalculate === false, message: 'Unsupported or missing observation must keep calculation blocked.' }, { ok: result.blocking_issues?.length > 0, message: 'Blocking reason must remain visible.' }];
          if (entry.id === 'followup.funded-loss') {
            assertions.push({ ok: typeof result.intervals?.[0]?.economic_change === 'string' && /^-150(?:\.0+)?$/.test(result.intervals[0].economic_change), message: 'Economic change must equal exact -150, not zero or net-flow-adjusted percentage.' });
            assertions.push({ ok: result.intervals?.[0]?.return_e8 === null, message: 'Negative adjusted closing wealth must preserve a null unresolved return.' });
          } else if (entry.id === 'followup.offsetting-unresolved') assertions.push({ ok: result.intervals?.length > 0 && result.intervals.every(i => i.return_e8 === null), message: 'Known offsetting flow history must retain unresolved intervals without calculated returns.' });
          else assertions.push({ ok: result.intervals?.some(i => i.status === 'unresolved'), message: 'Missing requested boundary must remain as an unresolved interval.' });
          output.push(score(entry, { accepted: result.canCalculate, result }, assertions));
        }
        continue;
      }
      if (entry.id === 'reconcile.offsetting-flows') {
        const result = await adapter.reconcileAccount({ ...BASE, input: csv(['100', '110']), flowActivity: 'offsetting' });
        output.push(score(entry, { unsupported: true, unsupported_reason: 'Contract accepts net flow observations only; separate same-end gross flow rows have no supported interface. Refusal is a boundary observation, not a numerical pass.', observed_canCalculate: result.canCalculate, observed_intervals: result.intervals, observed_blocking_issues: result.blocking_issues }));
        continue;
      }
      if (entry.id === 'reconcile.mixed-currency') {
        const input = 'Account ID,From Date,To Date,Starting Value,Ending Value,Deposits/Withdrawals,Internal Cash Transfers,Asset Transfers,Linking Adjustments,Other,Currency,Base Currency,Mark-to-Market\nSYNTHETIC,20260102,20260102,100,160,50,0,0,0,0,EUR,USD,10';
        const result = await adapter.reconcileAccount({ ...BASE, input, original: input, format: 'ibkr-flex' });
        output.push(score(entry, { accepted: result.canCalculate, result }, checks(entry, result)));
        continue;
      }
      if (entry.id === 'reconcile.missing-source') {
        // No source-reference-only ingestion is declared. Capture a missing raw
        // source as a historical attempted source; fabricated rows have no authority.
        const result = await adapter.reconcileAccount({ ...BASE, input: csv(['100', '110']), sources: [{ fileName: 'missing.csv', id: 'missing-source', sha256: '0'.repeat(64), rows: [{ date: '2026-01-02', nav: '110', flow: '0' }], disposition: 'unresolved' }] });
        output.push(score(entry, { accepted: result.canCalculate, result }, checks(entry, result)));
        continue;
      }
      if (entry.id === 'privacy.public-projection') {
        const input = `Account ID,From Date,To Date,Starting Value,Ending Value,Deposits/Withdrawals,Internal Cash Transfers,Asset Transfers,Linking Adjustments,Other,Currency,Base Currency,Mark-to-Market\n${marker},20260102,20260102,100,110,0,0,0,0,0,USD,USD,10`;
        const result = await adapter.reconcileAccount({ ...BASE, input, original: input, format: 'ibkr-flex', fileName: marker + '.csv', sources: [{ text: marker, fileName: marker + '-historical.csv', disposition: 'excluded', reason: marker + ' original synthetic unrelated source excluded explicitly' }] });
        const { importDisclosure } = await import(pathToFileURL(path.join(target, 'src/importer.js')).href);
        const { provenanceFromImport } = await import(pathToFileURL(path.join(target, 'src/trackRecord.js')).href);
        const publicData = { disclosure: importDisclosure(result.review), provenance: provenanceFromImport(result.review, { accountScope: BASE.accountScope, reviewed: true }) };
        const text = JSON.stringify(publicData);
        const exposed = text.includes(marker) || text.includes('date,nav,external_flow') || text.includes('raw_cells') || text.includes('bytes_base64');
        output.push(score(entry, { accepted: exposed, publicData, scope: 'Pure public import-disclosure and signed-provenance projections only; exact UI/package journey is independently checked by release parent.' }, [{ ok: !exposed, message: 'Private source marker or raw source data leaked into public projection.' }]));
        continue;
      }
      const input = inputFor(entry);
      if (!input) { output.push(score(entry, { unsupported: true, unsupported_reason: 'Independent adapter has not mapped this frozen case.' })); continue; }
      const result = await adapter.reconcileAccount(input);
      output.push(score(entry, { accepted: result.canCalculate, result }, checks(entry, result)));
    } catch (error) {
      output.push(score(entry, { execution_error: `${error.name}: ${error.message}` }));
    }
  }
  return output;
}

export async function runReconciliationBenchmark({ target }) {
  target = path.resolve(target);
  const before = await targetInventory(target);
  const runs = [];
  for (let i = 0; i < 2; i++) {
    const { stdout } = await execute(process.execPath, [script, '--worker', target], { maxBuffer: 32 * 1024 * 1024, timeout: 120000 });
    runs.push(JSON.parse(stdout));
  }
  const after = await targetInventory(target);
  const cases = runs[0];
  const reproducibility = { identical: JSON.stringify(runs[0]) === JSON.stringify(runs[1]), result_sha256: runs.map(r => sha256(JSON.stringify(r))), runs: 2, differing_case_ids: cases.filter((c, i) => JSON.stringify(c) !== JSON.stringify(runs[1][i])).map(c => c.id) };
  return { schema: 'n170.wave2.reconciliation-challenge.v1', external_audit: false, specification_sha256: SPEC_SHA256, supplemental_specification_sha256: SUPPLEMENT_SHA256, candidate_identity: before, candidate_unchanged: before.source_sha256 === after.source_sha256, cases, summary: summarize(cases), reproducibility };
}

if (process.argv[1] && path.resolve(process.argv[1]) === script) {
  if (process.argv[2] === '--worker') process.stdout.write(JSON.stringify(await executeCases(path.resolve(process.argv[3]))));
  else {
    const args = options(process.argv.slice(2), ['--target', '--output']);
    if (!args['--target'] || !args['--output']) throw new Error('Use --target APP --output NEW_REPORT.json');
    const report = await runReconciliationBenchmark({ target: args['--target'] });
    await writeExclusive(args['--output'], report);
    process.stdout.write(JSON.stringify(report.summary, null, 2) + '\n');
    process.exitCode = report.summary.failures.length || !report.reproducibility.identical || !report.candidate_unchanged ? 1 : 0;
  }
}
