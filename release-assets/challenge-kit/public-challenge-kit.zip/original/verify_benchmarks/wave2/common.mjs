// SPDX-License-Identifier: Apache-2.0
// Independent engineering harness. No producer code calculates expected results.
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

export const SPEC_SHA256 = 'bc19a976c7e790dfa69ebd2543f071f5a388cd9434509307987ac1f9ea4c1e26';
export const SUPPLEMENT_SHA256 = 'fb700cdf17779caa11dbd89bc5e95f865c5849e6802735049a1089859d252029';
export const sha256 = value => createHash('sha256').update(value).digest('hex');
export const here = fileURLToPath(new URL('.', import.meta.url));
export async function specification() {
  const bytes = await readFile(new URL('./expected-cases.json', import.meta.url));
  if (sha256(bytes) !== SPEC_SHA256) throw new Error('Independent expected case bytes changed; refusing to score.');
  const adjacent = (await readFile(new URL('./expected-cases.sha256', import.meta.url), 'utf8')).trim().split(/\s+/)[0];
  if (adjacent !== SPEC_SHA256) throw new Error('Independent expected case commitment changed.');
  return JSON.parse(bytes);
}

export async function supplementalSpecification() {
  const bytes = await readFile(new URL('./supplemental-cases.json', import.meta.url));
  if (sha256(bytes) !== SUPPLEMENT_SHA256) throw new Error('Independent supplemental expected cases changed.');
  return JSON.parse(bytes);
}

// Unsupported cases and execution errors have their own denominators. A reason
// string alone never establishes a rejection, and an exception is not a pass.
export function score(spec, actual, assertions = []) {
  if (spec.classification === 'unsupported' || actual.unsupported) return {
    ...spec, actual, outcome: 'unsupported', failures: [],
    unsupported_reason: actual.unsupported_reason || spec.rationale,
  };
  if (actual.execution_error) return { ...spec, actual, outcome: 'execution_error', failures: [actual.execution_error] };
  const failures = assertions.filter(assertion => !assertion.ok).map(assertion => assertion.message);
  const falseAccept = spec.classification === 'adversarial' && actual.accepted === true;
  const falseReject = spec.classification === 'valid' && actual.accepted === false;
  return { ...spec, actual, outcome: falseAccept ? 'false_acceptance' : falseReject ? 'false_rejection' : failures.length ? 'assertion_failure' : 'pass', failures };
}

export function summarize(cases) {
  const supported = cases.filter(c => !['unsupported', 'execution_error'].includes(c.outcome));
  const outcome = name => cases.filter(c => c.outcome === name).length;
  return {
    total_cases: cases.length, executed_supported_cases: supported.length,
    passed_cases: outcome('pass'), unsupported_cases: outcome('unsupported'), execution_errors: outcome('execution_error'),
    assertion_failures: outcome('assertion_failure'),
    false_acceptance: { count: outcome('false_acceptance'), denominator: supported.filter(c => c.classification === 'adversarial').length },
    false_rejection: { count: outcome('false_rejection'), denominator: supported.filter(c => c.classification === 'valid').length },
    unsupported: cases.filter(c => c.outcome === 'unsupported').map(c => ({ id: c.id, reason: c.unsupported_reason })),
    failures: cases.filter(c => !['pass', 'unsupported'].includes(c.outcome)).map(c => ({ id: c.id, outcome: c.outcome, failures: c.failures })),
  };
}

export async function writeExclusive(file, report) {
  await writeFile(file, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
}

export function options(argv, names) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    if (!names.includes(argv[i]) || !argv[i + 1] || argv[i + 1].startsWith('--')) throw new Error(`Expected named options: ${names.join(', ')}`);
    if (out[argv[i]]) throw new Error(`Duplicate option ${argv[i]}`);
    out[argv[i]] = argv[i + 1];
  }
  return out;
}
