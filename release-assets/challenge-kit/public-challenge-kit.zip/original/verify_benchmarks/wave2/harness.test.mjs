// SPDX-License-Identifier: Apache-2.0
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { specification, score, summarize, SPEC_SHA256 } from './common.mjs';
import { runReconciliationBenchmark } from './reconciliation.mjs';

test('precommitted oracle preserves all cases and impossible completeness boundaries', async () => {
  const spec = await specification();
  assert.equal(SPEC_SHA256, 'bc19a976c7e790dfa69ebd2543f071f5a388cd9434509307987ac1f9ea4c1e26');
  assert.equal(spec.cases.length, 44);
  assert.equal(new Set(spec.cases.map(c => c.id)).size, 44);
  assert.equal(spec.cases.filter(c => c.classification === 'unsupported').length, 5);
  for (const id of ['limit.unsigned-rebuild', 'limit.unknown-omitted-attempt']) assert.equal(spec.cases.find(c => c.id === id).classification, 'unsupported');
});

test('unsupported observations and execution errors cannot inflate pass denominators', () => {
  const adversarial = { id: 'a', classification: 'adversarial' };
  const valid = { id: 'v', classification: 'valid' };
  const cases = [score(adversarial, { accepted: true }), score(valid, { accepted: false }), score(adversarial, { execution_error: 'timeout' }), score(valid, { unsupported: true, unsupported_reason: 'No supported interface' })];
  const summary = summarize(cases);
  assert.deepEqual(summary.false_acceptance, { count: 1, denominator: 1 });
  assert.deepEqual(summary.false_rejection, { count: 1, denominator: 1 });
  assert.equal(summary.passed_cases, 0);
  assert.equal(summary.execution_errors, 1);
  assert.equal(summary.unsupported_cases, 1);
});

test('a missing reason remains an assertion failure despite correct refusal', () => {
  const result = score({ id: 'x', classification: 'adversarial' }, { accepted: false }, [{ ok: false, message: 'Required unresolved reason absent' }]);
  assert.equal(result.outcome, 'assertion_failure');
});

test('deliberately permissive source produces retained false accepts in fresh workers', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'n170-wave2-permissive-'));
  try {
    await mkdir(path.join(root, 'src'));
    await writeFile(path.join(root, 'package.json'), '{"type":"module"}');
    await writeFile(path.join(root, 'src/reconciliation.js'), `export async function reconcileAccount() { return {canCalculate:true,selected_scope_status:'calculable_under_owner_assumptions',intervals:[{status:'calculable',return_e8:10000000}],blocking_issues:[],source_inventory:[]}; }`);
    const report = await runReconciliationBenchmark({ target: root });
    assert.equal(report.candidate_unchanged, true);
    assert.equal(report.reproducibility.identical, true);
    assert.ok(report.summary.false_acceptance.count >= 5);
    assert.ok(report.summary.execution_errors >= 1); // missing public projection interface is preserved
    assert.equal(report.cases.length, 21);
    assert.ok(report.cases.some(c => c.id === 'reconcile.growth' && c.outcome === 'assertion_failure'));
    assert.ok(report.cases.some(c => c.id === 'reconcile.valid-loss' && c.outcome === 'assertion_failure'));
  } finally { await rm(root, { recursive: true, force: true }); }
});
