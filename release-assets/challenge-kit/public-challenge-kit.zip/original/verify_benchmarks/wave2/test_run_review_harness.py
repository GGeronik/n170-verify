"""Independent harness checks; do not load or execute a producer candidate."""
import base64
import json
import unittest
from pathlib import Path
from verify_benchmarks.wave2.run_review import (
    HERE, descriptor, evaluate, get_manifest, load_spec, mutate,
    receipt_envelopes, changed_semantics, sha,
)


class RunReviewHarnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec = {c['id']: c for c in load_spec()['cases']}
        cls.bundles = receipt_envelopes(HERE / 'private-evidence/receipts')

    def test_frozen_real_receipt_bytes_keep_failed_attempt_visible(self):
        manifest = get_manifest(self.bundles['mixed-controls'])
        self.assertEqual([a['outcome'] for a in manifest['attempts']], ['NO_FINDINGS_REPORTED', 'FINDINGS_REPORTED', 'INSUFFICIENT', 'FAILED'])
        self.assertEqual(manifest['summary']['status'], 'NOT_ASSESSABLE')

    def test_transport_and_semantic_mutations_are_distinct(self):
        original = self.bundles['rerun-a']
        byte_change = mutate(original, 'bundle.altered-byte', self.bundles['mixed-controls'])
        bad = [d for d in byte_change['artifacts'] if sha(base64.b64decode(d['base64'])) != d['sha256']]
        self.assertEqual(len(bad), 1)
        semantic_change = mutate(original, 'bundle.settings', self.bundles['mixed-controls'])
        self.assertEqual(semantic_change['manifest']['sha256'], sha(base64.b64decode(semantic_change['manifest']['base64'])))
        self.assertNotEqual(get_manifest(original)['request'], get_manifest(semantic_change)['request'])

    def test_rebuilt_unsigned_changes_bind_every_retained_byte(self):
        for field in ['strategy', 'data', 'settings', 'scope', 'findings']:
            bundle = changed_semantics(self.bundles['rerun-a'], 'compare.changed-' + field)
            manifest = get_manifest(bundle)
            entries = [{k: v for k, v in d.items() if k != 'base64'} for d in bundle['artifacts']]
            self.assertEqual(entries, manifest['artifacts'], field)
            for d in [bundle['manifest'], *bundle['artifacts']]:
                raw = base64.b64decode(d['base64'])
                self.assertEqual(d['size'], len(raw), field)
                self.assertEqual(d['sha256'], sha(raw), field)
            files = {d['path']: base64.b64decode(d['base64']) for d in bundle['artifacts']}
            for attempt in manifest['attempts']:
                prefix = f"attempts/{attempt['id']}/"
                request = json.loads(files[prefix + 'input/request.json'])
                worker = json.loads(files[prefix + 'output/worker-result.json'])
                self.assertEqual(worker['request_sha256'], sha(files[prefix + 'input/request.json']))
                self.assertEqual(worker['input_inventory'], request['input_inventory'])
                for entry in request['input_inventory']:
                    raw = files[prefix + 'input/' + entry['path']]
                    self.assertEqual(sha(raw), entry['sha256'])
                    self.assertEqual(len(raw), entry['size'])
                lines = [line for line in files[prefix + 'stdout.log'].splitlines() if line.startswith(b'N170_RESULT_BUNDLE_V1:')]
                self.assertEqual(len(lines), 1)
                transport = json.loads(base64.b64decode(lines[0].split(b':', 1)[1]))
                for name, data in transport.items():
                    self.assertEqual(base64.b64decode(data), files[prefix + 'output/' + name])

    def test_permissive_verifier_is_false_acceptance(self):
        for cid in ['bundle.altered-byte', 'bundle.hidden-supplied-failure', 'bundle.settings']:
            result = evaluate(self.spec[cid], {'integrity': 'VALID'})
            self.assertEqual(result['outcome'], 'false_acceptance')

    def test_not_comparable_cannot_pass_changed_semantics_case(self):
        result = evaluate(self.spec['compare.changed-data'], {'status': 'NOT_COMPARABLE'})
        self.assertEqual(result['outcome'], 'assertion_failure')

    def test_missing_interface_and_execution_error_are_never_passes(self):
        self.assertEqual(evaluate(self.spec['compare.equivalent'], {'unsupported': True})['outcome'], 'unsupported')
        self.assertEqual(evaluate(self.spec['bundle.altered-byte'], {'execution_error': 'timeout'})['outcome'], 'execution_error')


if __name__ == '__main__':
    unittest.main()
