"""Independent wave-2 portable receipt challenges; never executes captured code.

The tested verifier source itself is trusted local code and runs in child
processes. Expected outcomes are frozen independently of these adapters.
"""
from __future__ import annotations
import argparse
import base64
import copy
import hashlib
import json
from pathlib import Path
import stat
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SPEC_SHA = 'bc19a976c7e790dfa69ebd2543f071f5a388cd9434509307987ac1f9ea4c1e26'
RECEIPT_SHA = '0ab643e5509671753cc59318cda484b8f5e72ddd6e0f7e2bfd269cf312308151'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda value: (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def load_spec():
    raw = (HERE / 'expected-cases.json').read_bytes()
    if sha(raw) != SPEC_SHA:
        raise ValueError('Frozen independent expectations changed')
    return json.loads(raw)


def inventory(root, paths):
    root = Path(root).resolve()
    entries = []
    for scope in paths:
        base = root / scope
        if base.is_symlink():
            raise ValueError('Refuse candidate source-directory symlink')
        candidates = [base] if base.is_file() else sorted(base.rglob('*')) if base.exists() else []
        for file in candidates:
            if file.is_symlink():
                raise ValueError('Refuse candidate symlink')
            if file.is_dir():
                continue
            if not stat.S_ISREG(file.lstat().st_mode):
                raise ValueError('Refuse nonregular candidate file')
            if file.suffix == '.pyc' or '__pycache__' in file.parts:
                raise ValueError('Refuse unpinned executable bytecode')
            raw = file.read_bytes()
            entries.append({'path': file.relative_to(root).as_posix(), 'size': len(raw), 'sha256': sha(raw)})
    entries.sort(key=lambda e: e['path'])
    if not entries:
        raise ValueError('No candidate source files found')
    return {'sha256': sha(encode(entries)), 'files': entries}


def descriptor(path, raw):
    return {'path': path, 'size': len(raw), 'sha256': sha(raw), 'base64': base64.b64encode(raw).decode()}


def receipt_envelopes(root):
    root = Path(root)
    if root.is_symlink() or (root / 'receipt-freeze.json').is_symlink():
        raise ValueError('Refuse frozen receipt root or manifest symlink')
    raw = (root / 'receipt-freeze.json').read_bytes()
    if sha(raw) != RECEIPT_SHA:
        raise ValueError('Independent receipt freeze changed')
    freeze = json.loads(raw)
    by_receipt = {}
    for entry in freeze['files']:
        name = entry['path']
        if name.startswith('/') or any(part in {'', '.', '..'} for part in name.split('/')):
            raise ValueError('Unsafe frozen receipt path')
        file = root / name
        current = root
        for part in name.split('/'):
            current = current / part
            if current.is_symlink():
                raise ValueError('Refuse symlink in frozen receipt path')
        if file.is_symlink() or not stat.S_ISREG(file.lstat().st_mode):
            raise ValueError('Frozen receipt must be a regular file')
        content = file.read_bytes()
        if len(content) != entry['size'] or sha(content) != entry['sha256']:
            raise ValueError('Retained receipt byte changed: ' + name)
        receipt, relative = name.split('/', 1)
        by_receipt.setdefault(receipt, {})[relative] = content
    result = {}
    for receipt, files in by_receipt.items():
        manifest = files.pop('manifest.json')
        if sha(manifest) != freeze['receipt_manifest_pins'][receipt]:
            raise ValueError('Manifest pin mismatch')
        result[receipt] = {'schema': 'n170.run-review.v1', 'manifest': descriptor('manifest.json', manifest), 'artifacts': [descriptor(name, raw) for name, raw in sorted(files.items())]}
    return result


def get_manifest(bundle):
    return json.loads(base64.b64decode(bundle['manifest']['base64']))


def set_manifest(bundle, value):
    bundle['manifest'] = descriptor('manifest.json', encode(value))


def mutate(control, case_id, mixed):
    bundle = copy.deepcopy(mixed if case_id == 'bundle.hidden-supplied-failure' else control)
    manifest = get_manifest(bundle)
    artifacts = bundle['artifacts']
    csv = next((i for i, a in enumerate(artifacts) if a['path'].endswith('/lookahead.csv')), 0)
    if case_id == 'bundle.altered-byte':
        raw = base64.b64decode(artifacts[csv]['base64'])
        artifacts[csv]['base64'] = base64.b64encode(bytes([raw[0] ^ 1]) + raw[1:]).decode()
    elif case_id == 'bundle.missing-artifact':
        artifacts.pop(csv)
    elif case_id == 'bundle.extra-artifact':
        artifacts.append(descriptor('unlisted.txt', b'original synthetic undeclared evidence\n'))
        artifacts.sort(key=lambda a: a['path'])
    elif case_id == 'bundle.wrong-byte-count':
        artifacts[csv]['size'] += 1
    elif case_id == 'bundle.duplicate-path':
        artifacts.insert(csv, copy.deepcopy(artifacts[csv]))
    elif case_id in {'bundle.unsafe-path', 'bundle.absolute-path'}:
        artifacts[csv]['path'] = '../outside.json' if case_id.endswith('unsafe-path') else '/tmp/outside.json'
    elif case_id == 'bundle.attempt-id':
        manifest['attempts'][0]['id'] = '999'
        set_manifest(bundle, manifest)
    elif case_id == 'bundle.run-id':
        manifest['run_id'] = 'f' * 32
        # Retained invocation/container identities still contain the original ID.
        set_manifest(bundle, manifest)
    elif case_id == 'bundle.settings':
        manifest['request']['minimum_trade_amount'] += 1
        set_manifest(bundle, manifest)
    elif case_id == 'bundle.hidden-supplied-failure':
        manifest['summary']['status'] = 'NO_FINDINGS_REPORTED'
        manifest['summary']['assessed_count'] = len(manifest['attempts'])
        set_manifest(bundle, manifest)
    elif case_id == 'bundle.duplicate-attempt':
        manifest['attempts'].append(copy.deepcopy(manifest['attempts'][0]))
        set_manifest(bundle, manifest)
    elif case_id == 'bundle.missing-reproduction-input':
        chosen = next(a for a in artifacts if '/input/data/' in a['path'])
        artifacts.remove(chosen)
        # Recompute declared envelope and manifest inventory to test missing
        # prerequisites, not only a stale descriptor at the outer transport.
        manifest['artifacts'] = [a for a in manifest['artifacts'] if a['path'] != chosen['path']]
        set_manifest(bundle, manifest)
    return bundle


def changed_semantics(control, case_id):
    """Build explicitly unsigned internally consistent synthetic counterclaims.

    These are not new engine executions. Rebuilding every public digest is
    possible without a producer secret, exactly the documented authenticity
    limit. Expected comparisons come from deliberately changed semantic fields.
    """
    bundle = copy.deepcopy(control)
    manifest = get_manifest(bundle)
    files = {d['path']: base64.b64decode(d['base64']) for d in bundle['artifacts']}
    field = case_id.removeprefix('compare.changed-')
    if field == 'scope':
        manifest['attempts'] = manifest['attempts'][:1]
        manifest['request']['strategies'] = manifest['request']['strategies'][:1]
        files = {name: raw for name, raw in files.items() if name.startswith('attempts/000/')}
    if field == 'strategy':
        chosen = next(name for name in files if name.startswith('attempts/000/input/strategies/'))
        files[chosen] += b'\n# Original independent synthetic changed strategy identity.\n'
    if field == 'data':
        chosen = 'attempts/000/input/data/BTC_USDT-5m.json'
        data = json.loads(files[chosen])
        data[0][5] += 1  # Original synthetic volume change, no market claim.
        files[chosen] = encode(data)
    if field == 'settings':
        manifest['request']['minimum_trade_amount'] = 6
    for attempt in manifest['attempts']:
        prefix = f"attempts/{attempt['id']}/"
        input_prefix = prefix + 'input/'
        request_path = input_prefix + 'request.json'
        worker_path = prefix + 'output/worker-result.json'
        request = json.loads(files[request_path])
        worker = json.loads(files[worker_path])
        if field == 'settings':
            request['minimum_trade_amount'] = 6
            worker['engine_arguments']['minimum_trade_amount'] = 6
            worker['analysis']['minimum_trade_amount'] = 6
            config_path = prefix + 'output/effective-config.json'
            config = json.loads(files[config_path])
            config['minimum_trade_amount'] = 6
            files[config_path] = encode(config)
            worker['effective_config_sha256'] = sha(files[config_path])
            worker['effective_config_canonical_sha256'] = sha(json.dumps(config, sort_keys=True, separators=(',', ':')).encode())
        if field == 'findings' and attempt['id'] == '000':
            csv_path = prefix + 'output/lookahead.csv'
            text = files[csv_path].decode()
            files[csv_path] = text.replace('False,10,0,0,', 'True,10,0,0,independent_indicator').encode()
            worker['analysis']['has_bias'] = True
            worker['analysis']['biased_indicators'] = ['independent_indicator']
            attempt['outcome'] = 'FINDINGS_REPORTED'
            attempt['reason_codes'] = ['FINDINGS_REPORTED']
        selected_inputs = []
        for name, raw in sorted(files.items()):
            if name.startswith(input_prefix) and name != request_path:
                selected_inputs.append({'path': name.removeprefix(input_prefix), 'size': len(raw), 'sha256': sha(raw)})
        request['input_inventory'] = selected_inputs
        files[request_path] = encode(request)
        worker['input_inventory'] = selected_inputs
        worker['request_sha256'] = sha(files[request_path])
        files[worker_path] = encode(worker)
        outputs = {name.removeprefix(prefix + 'output/'): base64.b64encode(raw).decode() for name, raw in sorted(files.items()) if name.startswith(prefix + 'output/')}
        transport = b'N170_RESULT_BUNDLE_V1:' + base64.b64encode(json.dumps(outputs, sort_keys=True).encode())
        stdout = prefix + 'stdout.log'
        files[stdout] = b'\n'.join(transport if line.startswith(b'N170_RESULT_BUNDLE_V1:') else line for line in files[stdout].split(b'\n'))
        attempt['artifacts'] = [{'path': name, 'size': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items()) if name.startswith(prefix)]
    manifest['artifacts'] = [{'path': name, 'size': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items())]
    manifest['inputs'] = [entry for entry in manifest['artifacts'] if '/input/' in entry['path']]
    counts = {name: sum(a['outcome'] == name for a in manifest['attempts']) for name in manifest['summary']['outcome_counts']}
    manifest['summary'] = {'status': 'FINDINGS_REPORTED' if counts['FINDINGS_REPORTED'] else 'NO_FINDINGS_REPORTED', 'selected_count': len(manifest['attempts']), 'assessed_count': len(manifest['attempts']), 'findings_count': counts['FINDINGS_REPORTED'], 'outcome_counts': counts}
    bundle['artifacts'] = [descriptor(name, raw) for name, raw in sorted(files.items())]
    set_manifest(bundle, manifest)
    return bundle


def invoke(toolkit, app, operation, bundles):
    payload = json.dumps({'operation': operation, 'bundles': [json.dumps(b) for b in bundles]})
    py = '''import sys,json
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
from verify_toolkit.run_review import verify_run_review,compare_run_reviews,export_run_review
p=json.load(sys.stdin)
if p['operation']=='export':
 try:
  export_run_review(json.loads(p['bundles'][0]));r={'rejected_export':False}
 except (ValueError,OSError) as e:r={'rejected_export':True,'reason':str(e)}
else:
 f=verify_run_review if p['operation']=='verify' else compare_run_reviews
 r=f(*p['bundles'])
print(json.dumps(r,sort_keys=True,allow_nan=False))'''
    js = '''import {webcrypto} from 'node:crypto';import {pathToFileURL} from 'node:url';import {readFileSync} from 'node:fs';
if(!globalThis.crypto?.subtle)globalThis.crypto=webcrypto;
const m=await import(pathToFileURL(process.argv[1]+'/src/runReview.js').href);
const p=JSON.parse(readFileSync(0,'utf8'));const f=p.operation==='verify'?m.verifyRunReview:p.operation==='compare'?m.compareRunReviews:null;
process.stdout.write(JSON.stringify(typeof f==='function'?await f(...p.bundles):{unsupported:true,unsupported_reason:'This surface does not expose this operation in its contract.'}));'''
    calls = [('python', [sys.executable, '-I', '-S', '-B', '-c', py, str(toolkit)]), ('browser_module', ['node', '--input-type=module', '-e', js, str(app)])]
    result = {}
    for name, command in calls:
        try:
            child = subprocess.run(command, input=payload, capture_output=True, text=True, timeout=60)
            result[name] = json.loads(child.stdout) if child.returncode == 0 else {'execution_error': 'process_exit', 'exit_code': child.returncode, 'stderr': child.stderr[-4000:]}
        except Exception as error:
            result[name] = {'execution_error': type(error).__name__, 'detail': str(error)}
    return result


def observations(result):
    if result.get('execution_error'):
        return {'execution_error': result['execution_error']}
    return result


def evaluate(spec, actual):
    failures = []
    valid = spec['classification'] == 'valid'
    if actual.get('unsupported'):
        return {'outcome': 'unsupported', 'failures': [], 'unsupported_reason': actual.get('unsupported_reason')}
    if actual.get('execution_error'):
        return {'outcome': 'execution_error', 'failures': [actual['execution_error']]}
    cid = spec['id']
    if cid == 'bundle.nonregular-path':
        accepted = not actual.get('rejected_export')
        if accepted:
            failures.append('Exporter accepted a symlink in supplied receipt files')
    elif cid.startswith('compare.'):
        same = actual.get('status') == 'SAME'
        if same != spec['expected']['equivalent'] or actual.get('status') == 'NOT_COMPARABLE':
            failures.append('Unexpected semantic comparison result')
        accepted = same
    elif cid == 'bundle.known-failure-visible':
        outcomes = [a.get('outcome') for a in actual.get('attempts', [])]
        accepted = actual.get('integrity') == 'VALID'
        if not accepted or actual.get('status') != 'NOT_ASSESSABLE' or 'FAILED' not in outcomes or 'INSUFFICIENT' not in outcomes:
            failures.append('Mixed supplied failures must remain intact, unassessable, and visible')
    elif cid == 'bundle.missing-reproduction-input':
        accepted = actual.get('reproducibility', {}).get('status') == 'READY_TO_RERUN'
        if accepted or not actual.get('reason_codes'):
            failures.append('Missing retained inputs need a non-reproducible result and reason')
    else:
        accepted = actual.get('integrity') == 'VALID'
        if accepted != valid:
            failures.append('Unexpected integrity acceptance')
        if valid:
            trust = json.dumps(actual.get('trust', {})).lower()
            if 'unsigned' not in trust or not any(s in trust for s in ['unknown', 'omitted', 'not establish']):
                failures.append('Unsigned authenticity/unknown completeness boundary absent')
    outcome = 'false_rejection' if valid and not accepted else 'false_acceptance' if not valid and accepted else 'assertion_failure' if failures else 'pass'
    return {'outcome': outcome, 'failures': failures}


def run(toolkit, app, receipts):
    toolkit, app = Path(toolkit).resolve(), Path(app).resolve()
    before = {'toolkit': inventory(toolkit, ['verify_toolkit']), 'app': inventory(app, ['src', 'package.json', 'package-lock.json'])}
    bundles = receipt_envelopes(receipts)
    selected = [s for s in load_spec()['cases'] if s['dimension'] in {'bundle', 'comparison'}]
    cases = []
    for spec in selected:
        cid = spec['id']
        unsupported = None
        if spec['classification'] == 'unsupported':
            unsupported = spec['rationale']
        if unsupported:
            cases.append({**spec, 'outcome': 'unsupported', 'unsupported_reason': unsupported, 'failures': []})
            continue
        op = 'compare' if cid.startswith('compare.') else 'verify'
        if cid == 'compare.equivalent':
            inputs = [bundles['rerun-a'], bundles['rerun-b']]
        elif cid == 'compare.irrelevant-run':
            inputs = [bundles['rerun-a'], bundles['mixed-controls']]
        elif cid == 'bundle.known-failure-visible':
            inputs = [bundles['mixed-controls']]
        elif cid.startswith('compare.changed-'):
            inputs = [bundles['rerun-a'], changed_semantics(bundles['rerun-a'], cid)]
        else:
            inputs = [mutate(bundles['rerun-a'], cid, bundles['mixed-controls'])]
        if cid == 'bundle.nonregular-path':
            with tempfile.TemporaryDirectory(prefix='n170-wave2-export-symlink-') as temp:
                clone = Path(temp) / 'receipt'
                shutil.copytree(Path(receipts) / 'rerun-a', clone)
                artifact = clone / bundles['rerun-a']['artifacts'][0]['path']
                outside = Path(temp) / 'outside.txt'
                outside.write_bytes(artifact.read_bytes())
                artifact.unlink()
                artifact.symlink_to(outside)
                repeats = [invoke(toolkit, app, 'export', [str(clone)]) for _ in range(2)]
        else:
            repeats = [invoke(toolkit, app, op, inputs) for _ in range(2)]
        surface_results = {name: evaluate(spec, actual) for name, actual in repeats[0].items()}
        failures = [{'surface': name, **r} for name, r in surface_results.items() if r['outcome'] not in {'pass', 'unsupported'}]
        if repeats[0] != repeats[1]:
            failures.append({'surface': 'reproducibility', 'outcome': 'assertion_failure', 'failures': ['Fresh process results differ']})
        cases.append({**spec, 'actual': repeats[0], 'surface_results': surface_results, 'outcome': 'pass' if not failures else 'failure', 'failures': failures, 'reproducibility': {'identical': repeats[0] == repeats[1], 'observation_sha256': [sha(encode(r)) for r in repeats]}})
    after = {'toolkit': inventory(toolkit, ['verify_toolkit']), 'app': inventory(app, ['src', 'package.json', 'package-lock.json'])}
    surface_summary = {}
    for surface in ['python', 'browser_module']:
        scored = [(c, c['surface_results'][surface]) for c in cases if 'surface_results' in c]
        supported = [(c, r) for c, r in scored if r['outcome'] not in {'execution_error', 'unsupported'}]
        surface_summary[surface] = {'executed_supported_cases': len(supported), 'passes': sum(r['outcome'] == 'pass' for _, r in supported), 'assertion_failures': sum(r['outcome'] == 'assertion_failure' for _, r in supported), 'execution_errors': sum(r['outcome'] == 'execution_error' for _, r in scored), 'unsupported_cases': sum(r['outcome'] == 'unsupported' for _, r in scored), 'false_acceptance': {'count': sum(r['outcome'] == 'false_acceptance' for _, r in supported), 'denominator': sum(c['classification'] == 'adversarial' for c, _ in supported)}, 'false_rejection': {'count': sum(r['outcome'] == 'false_rejection' for _, r in supported), 'denominator': sum(c['classification'] == 'valid' for c, _ in supported)}}
    return {'schema': 'n170.wave2.run-review-challenge.v1', 'external_audit': False, 'specification_sha256': SPEC_SHA, 'receipt_freeze_sha256': RECEIPT_SHA, 'candidate_identity': before, 'candidate_unchanged': before == after, 'cases': cases, 'summary': {'total_cases': len(cases), 'unsupported_cases': sum(c['outcome'] == 'unsupported' for c in cases), 'surfaces': surface_summary, 'failures': [{'id': c['id'], 'failures': c['failures']} for c in cases if c['failures']]}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolkit-root', required=True)
    parser.add_argument('--app', required=True)
    parser.add_argument('--receipts', type=Path, default=HERE / 'private-evidence/receipts')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = run(args.toolkit_root, args.app, args.receipts)
    with args.output.open('x') as file:
        json.dump(report, file, sort_keys=True, indent=2)
        file.write('\n')
    print(json.dumps(report['summary'], sort_keys=True, indent=2))
    return bool(report['summary']['failures']) or not report['candidate_unchanged']


if __name__ == '__main__':
    raise SystemExit(main())
